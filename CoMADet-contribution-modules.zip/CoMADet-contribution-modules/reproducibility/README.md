# Reproducibility Materials

This directory contains configuration snapshots and split-generation inputs for the reported CoMADet experiments.

## Configuration snapshots

- configs/soda_a contains the SODA-A base, SCENet-style 800-pixel recipe, and CMM plus cross-scale contrast recipe.
- configs/visdrone contains the 12-epoch VisDrone2019 recipe. The official dataset has train and validation splits only, so the evaluation configuration reuses validation as described in the file.
- configs/dronevehicle contains the three matched 12-epoch RGB recipes for seeds s245, s246, and s247.

These files are snapshots from the working MMRotate configuration tree. They use relative dataset roots and require the compatible upstream framework and the contribution modules in the archive.

## Split protocols

The SODA-A JSON files are inputs to the DOTA patch splitter. They define the source image and annotation directories, crop size, overlap, and output split directories. The original SODA-A images and annotations are not included.

VisDrone2019 and DroneVehicle use their official public train, validation, and test organization. The dataset-specific configuration files record the directory names, class order, image preprocessing, and evaluation split. No third-party dataset files are redistributed here.
