# Dataset split protocols

The public datasets are obtained from their original sources. This repository does not redistribute images or annotations.

## SODA-A

- Classes: 9, in the order airplane, helicopter, small-vehicle, large-vehicle, ship, container, storage-tank, swimming-pool, windmill.
- The paper uses the 800 x 800 patch protocol with 200-pixel overlap for the main SODA-A split files.
- The split-generation inputs are soda_a_train.json and soda_a_val.json.

## VisDrone2019

- The paper uses the official train and validation organization after conversion to the oriented DOTA-style format.
- The test evaluation reuses the official validation split because VisDrone2019-DET has no public test annotations in this setup.
- The reported image counts are 6471 train, 548 validation, and 1610 test-dev images.

## DroneVehicle

- The paper uses the official RGB train, validation, and test organization.
- The reported image counts are 17990 train, 1469 validation, and 8980 test images before the documented damaged-image filtering. The effective training count after filtering is 17974.
