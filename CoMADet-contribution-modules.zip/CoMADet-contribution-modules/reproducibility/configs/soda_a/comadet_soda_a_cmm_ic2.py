"""CMM-guided negative weighting for the SODA IC2 branch.

The initial head owns the online CMM miner.  ``MASENet`` publishes a detached
per-batch snapshot of its confusion/totals buffers to the refine head, where
IC2 adds ``log(1 + beta * confusion[i, j] / totals[i])`` only to negative
classes in the supervised contrastive denominator.  ``beta`` is the sole
experimental switch; inference is unchanged.
"""

_base_ = ['./ma_senet_soda_a.py']

custom_imports = dict(
    imports=[
        'mmrotate.models.dense_heads.ma_cross_scale_contrast_v2_head',
    ],
    allow_failed_imports=False)

model = dict(
    bbox_head_refine=[
        dict(
            type='MAS2AStableCrossScaleContrastRefineHead',
            num_classes=9,
            in_channels=256,
            stacked_convs=2,
            feat_channels=256,
            mid_cfg=dict(enabled=True, reduction=4),
            frm_cfg=dict(
                type='AlignConv',
                feat_channels=256,
                kernel_size=3,
                strides=[8, 16, 32, 64, 128]),
            anchor_generator=dict(
                type='PseudoRotatedAnchorGenerator',
                strides=[8, 16, 32, 64, 128]),
            bbox_coder=dict(
                type='DeltaXYWHTRBBoxCoder',
                angle_version='le135',
                norm_factor=1,
                edge_swap=False,
                proj_xy=True,
                target_means=(0., 0., 0., 0., 0.),
                target_stds=(1., 1., 1., 1., 1.)),
            loss_cls=dict(
                type='mmdet.FocalLoss',
                use_sigmoid=True,
                gamma=2.0,
                alpha=0.25,
                loss_weight=1.0),
            loss_bbox=dict(
                type='mmdet.SmoothL1Loss', beta=0.11, loss_weight=1.0),
            contrast_cfg=dict(
                enabled=True,
                levels=(0, 1, 2),
                roi_out_size=7,
                proj_dim=128,
                hidden_dim=256,
                temperature=0.1,
                loss_weight=0.1,
                max_per_class=32,
                scale_align_weight=0.25,
                confusion_beta=1.0),
        )
    ])

work_dir = 'work_dirs/ma_senet_soda_a_cmm_ic2_beta1'
