"""MA-SENet 在 SODA-A 上的配置（论文 4.1 / 4.2 主实验）。

SODA-A 必须先转换成 MMRotate 的旋转 DOTA 八点标注格式：
``data/soda_a/train/{annfiles,images}``、``data/soda_a/val/{annfiles,images}``。

重要：``classes`` 的顺序必须与转换脚本里用的顺序**完全一致**，否则标签会错位
（尤其是相似对 large-vehicle(3) / container(5)，M-SCA 依赖这两个下标）。
下面的顺序是原论文 SODA-A 的九类顺序：airplane, helicopter, small vehicle,
large vehicle, ship, container, storage tank, swimming pool, windmill。
"""

_base_ = [
    # The MA-SENet base already inherits DOTA's dataset, schedule and runtime.
    # MMEngine rejects multiple bases that define the same top-level keys, so
    # the SODA-A dataset and 12-epoch schedule are overridden below instead of
    # being added as sibling bases.
    './ma_senet/ma_senet-le135_r50_light_dota.py',
]

data_root = 'data/soda_a/'

# ---- 按你的转换脚本核对这两行 -------------------------------------------- #
num_classes = 9
classes = ('airplane', 'helicopter', 'small-vehicle', 'large-vehicle', 'ship',
           'container', 'storage-tank', 'swimming-pool', 'windmill')
# SODA-A 的已知相似对（large vehicle / container），仅用于消融对照 / 冒烟测试；
# 主实验请保持 confusion_pairs=[]，由 CMM 自动挖掘。
confusion_pairs = []

angle_version = 'le135'
# 与基类配置保持一致的损失权重符号（_base_ 只合并字典，不继承 Python 变量）。
lambda1_reg = 1.0
lambda2_focal = 1.0
lambda3_msca = 0.1
lambda4_align = 0.05
model = dict(
    bbox_head_init=dict(
        num_classes=num_classes,
        confusion_pairs=confusion_pairs,
        confusion_miner=dict(
            type='ConfusionMatrixMiner',
            num_classes=num_classes,
            threshold=0.15,
            momentum=0.9,
            warmup_epochs=5,
            max_pairs=16,
            mode='window',
            window_size=8)),
    bbox_head_refine=[
        # 注意：MMEngine 对 list 是整体替换而不是逐项合并，所以这里必须写全。
        dict(
            type='MAS2ARefineHead',
            num_classes=num_classes,
            in_channels=256,
            stacked_convs=2,
            feat_channels=256,
            mid_cfg=dict(enabled=True, reduction=4),
            frm_cfg=dict(
                type='AlignConv',
                feat_channels=256,
                kernel_size=3,
                strides=[8, 16, 32, 64, 128]),
            anchor_generator=dict(
                type='PseudoRotatedAnchorGenerator',
                strides=[8, 16, 32, 64, 128]),
            bbox_coder=dict(
                type='DeltaXYWHTRBBoxCoder',
                angle_version=angle_version,
                norm_factor=1,
                edge_swap=False,
                proj_xy=True,
                target_means=(0.0, 0.0, 0.0, 0.0, 0.0),
                target_stds=(1.0, 1.0, 1.0, 1.0, 1.0)),
            loss_cls=dict(
                type='mmdet.FocalLoss',
                use_sigmoid=True,
                gamma=2.0,
                alpha=0.25,
                loss_weight=lambda2_focal),
            loss_bbox=dict(
                type='mmdet.SmoothL1Loss', beta=0.11,
                loss_weight=lambda1_reg))
    ])

# MMRotate 的 DOTADataset 用 ``metainfo.classes`` 建标签映射，必须和上面一致。
metainfo = dict(classes=classes)

# SODA-A data pipeline.  This is intentionally explicit because the DOTA base
# has a different root/split and because sibling _base_ files would create
# duplicate top-level keys under MMEngine's config loader.
dataset_type = 'DOTADataset'
backend_args = None
train_pipeline = [
    dict(type='mmdet.LoadImageFromFile', backend_args=backend_args),
    dict(type='mmdet.LoadAnnotations', with_bbox=True, box_type='qbox'),
    dict(type='ConvertBoxType', box_type_mapping=dict(gt_bboxes='rbox')),
    dict(type='mmdet.Resize', scale=(1024, 1024), keep_ratio=True),
    dict(type='mmdet.RandomFlip', prob=0.75,
         direction=['horizontal', 'vertical', 'diagonal']),
    dict(type='mmdet.PackDetInputs')
]
val_pipeline = [
    dict(type='mmdet.LoadImageFromFile', backend_args=backend_args),
    dict(type='mmdet.LoadAnnotations', with_bbox=True, box_type='qbox'),
    dict(type='ConvertBoxType', box_type_mapping=dict(gt_bboxes='rbox')),
    dict(type='mmdet.Resize', scale=(1024, 1024), keep_ratio=True),
    dict(type='mmdet.PackDetInputs',
         meta_keys=('img_id', 'img_path', 'ori_shape', 'img_shape',
                    'scale_factor'))
]
train_dataloader = dict(dataset=dict(
    type=dataset_type,
    data_root=data_root,
    ann_file='train/annfiles/',
    data_prefix=dict(img_path='train/images/'),
    img_suffix='jpg',
    metainfo=metainfo, pipeline=train_pipeline,
    filter_cfg=dict(filter_empty_gt=True)))
val_dataloader = dict(dataset=dict(
    type=dataset_type,
    data_root=data_root,
    ann_file='val/annfiles/',
    data_prefix=dict(img_path='val/images/'),
    img_suffix='jpg',
    metainfo=metainfo, pipeline=val_pipeline, test_mode=True))
test_dataloader = val_dataloader

val_evaluator = dict(type='DOTAMetric', metric='mAP')
test_evaluator = val_evaluator

# Explicit 12-epoch recipe, overriding the inherited 1x schedule.
train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=12, val_interval=1)
val_cfg = dict(type='ValLoop')
test_cfg = dict(type='TestLoop')
param_scheduler = [
    dict(type='LinearLR', start_factor=1.0 / 3, by_epoch=False,
         begin=0, end=500),
    dict(type='MultiStepLR', begin=0, end=12, by_epoch=True,
         milestones=[8, 11], gamma=0.1)
]
optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='SGD', lr=0.0025, momentum=0.9,
                   weight_decay=0.0001),
    clip_grad=dict(max_norm=35, norm_type=2))
