"""SCENet-style SODA-A run on the paper-style 800x800 patches.

The dataset is prepared by ``soda_a_prepare.py`` with a 150-pixel overlap.
This keeps the full LSEFPN (LEM + SFM) and the original MA-SENet heads while
using the same three-way train/val/test split for a fair comparison.
"""

_base_ = ['./ma_senet_soda_a.py']

data_root = 'data/soda_a_scenet_800/'

model = dict(
    neck=dict(
        _delete_=True,
        type='LSEFPN',
        in_channels=[256, 512, 1024, 2048],
        out_channels=256,
        start_level=1,
        add_extra_convs='on_input',
        num_outs=5))

train_pipeline = [
    dict(type='mmdet.LoadImageFromFile', backend_args=None),
    dict(type='mmdet.LoadAnnotations', with_bbox=True, box_type='qbox'),
    dict(type='ConvertBoxType', box_type_mapping=dict(gt_bboxes='rbox')),
    dict(type='mmdet.RandomResize', scale=(800, 800),
         ratio_range=(0.75, 1.0), keep_ratio=True,
         resize_type='mmdet.Resize'),
    dict(type='mmdet.RandomFlip', prob=0.75,
         direction=['horizontal', 'vertical', 'diagonal']),
    dict(type='mmdet.PackDetInputs')
]

val_pipeline = [
    dict(type='mmdet.LoadImageFromFile', backend_args=None),
    dict(type='mmdet.LoadAnnotations', with_bbox=True, box_type='qbox'),
    dict(type='ConvertBoxType', box_type_mapping=dict(gt_bboxes='rbox')),
    dict(type='mmdet.Resize', scale=(800, 800), keep_ratio=True),
    dict(type='mmdet.PackDetInputs',
         meta_keys=('img_id', 'img_path', 'ori_shape', 'img_shape',
                    'scale_factor'))
]

train_dataloader = dict(
    batch_size=4,
    dataset=dict(data_root=data_root, pipeline=train_pipeline))
val_dataloader = dict(
    dataset=dict(data_root=data_root, pipeline=val_pipeline))
test_dataloader = dict(
    dataset=dict(data_root=data_root, ann_file='test/annfiles/',
                 data_prefix=dict(img_path='test/images/'),
                 pipeline=val_pipeline, test_mode=True))

train_cfg = dict(type='EpochBasedTrainLoop', max_epochs=12, val_interval=1)
param_scheduler = [
    dict(type='LinearLR', start_factor=1.0 / 3, by_epoch=False,
         begin=0, end=500),
    dict(type='MultiStepLR', begin=0, end=12, by_epoch=True,
         milestones=[8, 11], gamma=0.1),
]
optim_wrapper = dict(
    type='OptimWrapper',
    optimizer=dict(type='SGD', lr=0.0015, momentum=0.9,
                   weight_decay=0.0001),
    clip_grad=dict(max_norm=35, norm_type=2))
default_hooks = dict(
    checkpoint=dict(interval=1, max_keep_ckpts=2,
                    save_best='dota/mAP', rule='greater'),
    logger=dict(interval=50))
randomness = dict(seed=1324460243)
work_dir = 'work_dirs/ma_senet_soda_a_scenet_800_12e'
