"""V0_masenet_visdrone_12e -- VisDrone2019-DET

VisDrone2019-DET 上的 **MA-SENet 主方法**配置。

数据/类别之外的一切（模型结构、LSE-FPN、M-SCA、GWD 回归、AMP bf16、
12 epoch、lr 0.0025、bs 8、warmup 500、milestones [8, 11]、clip 35、输入 1024、
randomness / hooks / evaluator）**全部继承**主配方
``configs/E6_fromscratch_msca_on_12e.py``，不在此处重写。

相对 E6 只做「换数据 + 换类别」两类改动：
  1. 数据：data_root -> ``data/visdrone_obb/``，train/val 取各自划分，
     test 复用 val（VisDrone2019-DET 无 test 划分）。
  2. 类别：9 类 SODA-A -> 10 类 VisDrone，``num_classes`` 9 -> 10，
     ``metainfo.classes`` 换成 VisDrone 官方顺序。

⚠️ 关于 ClassAwareFocalLoss 的类别权重（必读）
  E6 的 ``positive_weights`` / ``negative_weights`` 是针对 SODA-A 9 类**逐类手工设定**的，
  与 VisDrone 的类别语义并不对应。本配置**不做任何重新调参**（否则就不是"同配方迁移"，
  主实验与基线之间也不再可比），只把向量补长到 10 维：**第 10 类 ``motor`` 补中性权重 1.0**，
  其余 9 位按位沿用 SODA-A 的值。
  这与 ``ClassAwareFocalLoss.forward`` 内部对短向量 ``F.pad(..., value=1.0)`` 的兜底
  **数值上完全等价**，但写成显式 10 维可避免"隐式填充"造成的口径不清。

⚠️ ``bbox_head_refine`` 必须整块给出
  mmengine 的文件继承对 **list 类型是整体替换**（``_merge_a_into_b`` 中
  ``allow_list_keys=False`` 时 list 走 ``else: b[k] = v``），不是逐元素合并。
  因此这里把 E6 解析后的 ``bbox_head_refine[0]``（MAS2ARefineHead）**完整**写出，
  只改 ``num_classes`` 与 loss_cls 的权重向量长度。若只写 ``[dict(num_classes=10)]``，
  整个 head 定义会被替换成一个只剩 num_classes 的 dict，构建必然失败。
"""
_base_ = ['../E6_fromscratch_msca_on_12e.py']

classes = ('pedestrian', 'people', 'bicycle', 'car', 'van',
           'truck', 'tricycle', 'awning-tricycle', 'bus', 'motor')
num_classes = 10

# MMRotate 的 DOTADataset 用 metainfo.classes 的顺序决定类别索引。
# 顺序必须与 VisDrone 官方一致（去掉 ignored-regions），否则标签全错。
metainfo = dict(classes=classes)

model = dict(
    bbox_head_init=dict(
        num_classes=10,
        confusion_miner=dict(num_classes=10),
        # 9 位沿用 SODA-A，第 10 类 motor 补中性 1.0（详见文件头说明）
        loss_cls=dict(
            positive_weights=(1.0, 1.25, 1.0, 1.2, 1.0, 1.1, 1.0, 1.0, 1.0, 1.0),
            negative_weights=(1.0, 0.5, 1.0, 0.5, 1.0, 0.5, 1.0, 1.0, 1.0, 1.0))),
    # list 是整体替换，必须整块给出（不能只写 num_classes）
    bbox_head_refine=[
        dict(
            type='MAS2ARefineHead',
            num_classes=10,
            in_channels=256,
            stacked_convs=2,
            feat_channels=256,
            mid_cfg=dict(enabled=True, reduction=4),
            frm_cfg=dict(
                type='AlignConv',
                feat_channels=256,
                kernel_size=3,
                strides=[8, 16, 32, 64, 128]),
            anchor_generator=dict(type='PseudoRotatedAnchorGenerator', strides=[8, 16, 32, 64, 128]),
            bbox_coder=dict(
                type='DeltaXYWHTRBBoxCoder',
                angle_version='le135',
                norm_factor=1,
                edge_swap=False,
                proj_xy=True,
                target_means=[0.0, 0.0, 0.0, 0.0, 0.0],
                target_stds=[1.0, 1.0, 1.0, 1.0, 1.0]),
            reg_decoded_bbox=True,
            loss_cls=dict(
                type='ClassAwareFocalLoss',
                use_sigmoid=True,
                gamma=2.0,
                alpha=0.25,
                positive_weights=[1.0, 1.25, 1.0, 1.2, 1.0, 1.1, 1.0, 1.0, 1.0, 1.0],
                negative_weights=[1.0, 0.5, 1.0, 0.5, 1.0, 0.5, 1.0, 1.0, 1.0, 1.0],
                loss_weight=1.0),
            loss_bbox=dict(type='GDLoss', loss_type='gwd', loss_weight=5.0),
        )
    ],
)
# ---------------------------------------------------------------------------
# 数据口径：VisDrone2019-DET（已完成 HBB -> OBB 的 DOTA 格式转换）
#   train 6471 张 / val 548 张；标注为轴对齐框（角度恒为 0）。
#   train 与 val 各含 annfiles/ 与 images/（images 为软链，勿复制）。
#   ⚠️ VisDrone2019-DET **没有 test 划分**，因此 test 直接复用 val：
#      ann_file='val/annfiles/'，data_prefix=dict(img_path='val/images/')。
#      test 上的指标与 val 完全相同，仅用于填表占位，不可当作独立测试集。
# ---------------------------------------------------------------------------
_S = 'data/visdrone_obb/'

# train：沿用主配方的 ClassBalancedDataset(oversample_thr=0.05) 包装器，
#        只替换最内层 DOTADataset 的 data_root / ann_file / data_prefix / metainfo。
#        ⚠️ 必须一次写完，切勿对同一变量二次赋值。
train_dataloader = dict(dataset=dict(dataset=dict(
    data_root=_S, ann_file='train/annfiles/',
    data_prefix=dict(img_path='train/images/'),
    metainfo=metainfo)))

val_dataloader = dict(dataset=dict(
    data_root=_S, ann_file='val/annfiles/',
    data_prefix=dict(img_path='val/images/'),
    metainfo=metainfo))

test_dataloader = dict(dataset=dict(
    data_root=_S, ann_file='val/annfiles/',
    data_prefix=dict(img_path='val/images/'),
    metainfo=metainfo))

data_root = _S

work_dir = 'work_dirs/V0_masenet_visdrone_12e'
