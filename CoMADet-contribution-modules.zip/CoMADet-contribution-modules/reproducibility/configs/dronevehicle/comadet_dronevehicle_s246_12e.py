# 2026-11-04 Claude Code mk_dv.py: PQ_s245_12e.py (md5 2b6cdfea) -> DroneVehicle RGB (5 classes, 640 x 512 not resized),
# 12 epochs MultiStep 8 / 11 as on SODA-A, seed 1324460246.
_S = 'data/dronevehicle/'
_V = 'data/soda_a_scenet_800_fullboxquad_iof70/'
angle_version = 'le135'
backend_args = None
balanced_cls = dict(
    alpha=0.25,
    gamma=2.0,
    loss_weight=1.0,
    negative_weights=[
        1.0,
        1.0,
        1.0,
        1.0,
        1.0,
    ],
    positive_weights=[
        1.0,
        1.0,
        1.0,
        1.0,
        1.0,
    ],
    type='ClassAwareFocalLoss',
    use_sigmoid=True)
class_aware_cls = dict(
    alpha=0.25,
    gamma=2.0,
    loss_weight=1.0,
    positive_weights=[
        1.0,
        1.0,
        1.0,
        1.0,
        1.0,
    ],
    type='ClassAwareFocalLoss',
    use_sigmoid=True)
classes = (
    'car',
    'truck',
    'bus',
    'van',
    'freight_car',
)
cmm_cfg = dict(
    max_pairs=16,
    mode='window',
    momentum=0.9,
    num_classes=15,
    threshold=0.15,
    type='ConfusionMatrixMiner',
    warmup_epochs=5,
    window_size=8)
confusion_pairs = []
custom_hooks = [
    dict(type='MASENetEpochHook'),
    dict(type='MASENetSparsityHook'),
]
custom_imports = dict(
    allow_failed_imports=False,
    imports=[
        'mmrotate.models.dense_heads.ma_contrast_cpd_head',
        'mmrotate.models.losses.class_aware_quality_focal_loss',
        'mmrotate.models.dense_heads.ma_contrast_cpd_qfl_head',
    ])
data_root = 'data/dronevehicle/'
dataset_type = 'DOTADataset'
default_hooks = dict(
    checkpoint=dict(interval=1, max_keep_ckpts=1, type='CheckpointHook'),
    logger=dict(interval=50, type='LoggerHook'),
    param_scheduler=dict(type='ParamSchedulerHook'),
    sampler_seed=dict(type='DistSamplerSeedHook'),
    timer=dict(type='IterTimerHook'),
    visualization=dict(type='mmdet.DetVisualizationHook'))
default_scope = 'mmrotate'
env_cfg = dict(
    cudnn_benchmark=True,
    dist_cfg=dict(backend='nccl'),
    mp_cfg=dict(mp_start_method='fork', opencv_num_threads=0))
gd_bbox_loss = dict(
    fun='log1p',
    loss_type='kld',
    loss_weight=5.0,
    representation='xy_wh_r',
    sqrt=False,
    tau=1.0,
    type='GDLoss')
gwd_bbox_loss = dict(loss_type='gwd', loss_weight=5.0, type='GDLoss')
lambda1_reg = 1.0
lambda2_focal = 1.0
lambda3_msca = 1.0
lambda4_align = 0.05
load_from = None
log_level = 'INFO'
log_processor = dict(by_epoch=True, type='LogProcessor', window_size=50)
metainfo = dict(classes=(
    'car',
    'truck',
    'bus',
    'van',
    'freight_car',
))
model = dict(
    backbone=dict(
        depth=50,
        frozen_stages=1,
        init_cfg=dict(checkpoint='torchvision://resnet50', type='Pretrained'),
        norm_cfg=dict(requires_grad=True, type='BN'),
        norm_eval=True,
        num_stages=4,
        out_indices=(
            0,
            1,
            2,
            3,
        ),
        style='pytorch',
        type='mmdet.ResNet',
        zero_init_residual=False),
    bbox_head_init=dict(
        anchor_generator=dict(
            angle_version='le135',
            ratios=[
                1.0,
            ],
            scales=[
                4,
            ],
            strides=[
                8,
                16,
                32,
                64,
                128,
            ],
            type='FakeRotatedAnchorGenerator'),
        bbox_coder=dict(
            angle_version='le135',
            edge_swap=False,
            norm_factor=1,
            proj_xy=True,
            target_means=(
                0.0,
                0.0,
                0.0,
                0.0,
                0.0,
            ),
            target_stds=(
                1.0,
                1.0,
                1.0,
                1.0,
                1.0,
            ),
            type='DeltaXYWHTRBBoxCoder',
            use_box_type=False),
        confusion_miner=dict(
            max_pairs=4,
            mode='window',
            momentum=0.9,
            num_classes=5,
            threshold=0.005,
            type='ConfusionMatrixMiner',
            warmup_epochs=0,
            window_size=8),
        confusion_pairs=[],
        feat_channels=256,
        in_channels=256,
        loss_bbox=dict(loss_type='gwd', loss_weight=5.0, type='GDLoss'),
        loss_cls=dict(
            alpha=0.25,
            gamma=2.0,
            loss_weight=1.0,
            negative_weights=[
                1.0,
                1.0,
                1.0,
                1.0,
                1.0,
            ],
            positive_weights=[
                1.0,
                1.0,
                1.0,
                1.0,
                1.0,
            ],
            type='ClassAwareFocalLoss',
            use_sigmoid=True),
        mid_cfg=dict(enabled=True, reduction=4),
        msca_levels=(0, ),
        msca_log_interval=50,
        msca_log_metric=False,
        msca_loss=dict(
            density_delta=40.0,
            lambda_align=0.05,
            loss_weight=1.0,
            topk=2000,
            type='MSCALoss'),
        msca_start_epoch=0,
        num_classes=5,
        reg_decoded_bbox=True,
        stacked_convs=2,
        type='MAS2AHead'),
    bbox_head_refine=[
        dict(
            anchor_generator=dict(
                strides=[
                    8,
                    16,
                    32,
                    64,
                    128,
                ],
                type='PseudoRotatedAnchorGenerator'),
            bbox_coder=dict(
                angle_version='le135',
                edge_swap=False,
                norm_factor=1,
                proj_xy=True,
                target_means=(
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                ),
                target_stds=(
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                    1.0,
                ),
                type='DeltaXYWHTRBBoxCoder'),
            contrast_cfg=dict(
                enabled=True,
                hidden_dim=256,
                levels=(
                    0,
                    1,
                    2,
                ),
                loss_weight=0.1,
                max_per_class=32,
                proj_dim=128,
                roi_out_size=7,
                scale_align_weight=0.25,
                temperature=0.1),
            cpd_cfg=dict(
                embedding_dim=128,
                enabled=True,
                hidden_dim=256,
                level=0,
                loss_weight=0.5,
                margin=0.4,
                max_age_steps=10000,
                max_per_class=32,
                min_observations=8,
                momentum=0.9,
                roi_out_size=7,
                temperature=0.1),
            feat_channels=256,
            frm_cfg=dict(
                feat_channels=256,
                kernel_size=3,
                strides=[
                    8,
                    16,
                    32,
                    64,
                    128,
                ],
                type='AlignConv'),
            in_channels=256,
            loss_bbox=dict(loss_type='gwd', loss_weight=5.0, type='GDLoss'),
            loss_cls=dict(
                beta=2.0,
                loss_weight=1.0,
                type='ClassAwareQualityFocalLoss',
                use_class_weights=False,
                use_sigmoid=True),
            mid_cfg=dict(enabled=True, reduction=4),
            num_classes=5,
            reg_decoded_bbox=True,
            stacked_convs=2,
            type='MAS2AStableContrastCPDQualityRefineHead'),
    ],
    data_preprocessor=dict(
        bgr_to_rgb=True,
        boxtype2tensor=False,
        mean=[
            123.675,
            116.28,
            103.53,
        ],
        pad_size_divisor=32,
        std=[
            58.395,
            57.12,
            57.375,
        ],
        type='mmdet.DetDataPreprocessor'),
    neck=dict(
        add_extra_convs='on_input',
        in_channels=[
            256,
            512,
            1024,
            2048,
        ],
        keep_edge_prior=True,
        num_outs=5,
        out_channels=256,
        start_level=1,
        type='LSEFPN'),
    test_cfg=dict(
        max_per_img=2000,
        min_bbox_size=0,
        nms=dict(iou_threshold=0.1, type='nms_rotated'),
        nms_pre=2000,
        score_thr=0.05),
    train_cfg=dict(
        init=dict(
            allowed_border=-1,
            assigner=dict(
                ignore_iof_thr=-1,
                iou_calculator=dict(type='RBboxOverlaps2D'),
                min_pos_iou=0,
                neg_iou_thr=0.4,
                pos_iou_thr=0.5,
                type='mmdet.MaxIoUAssigner'),
            debug=False,
            pos_weight=-1),
        refine=[
            dict(
                allowed_border=-1,
                assigner=dict(
                    ignore_iof_thr=-1,
                    iou_calculator=dict(type='RBboxOverlaps2D'),
                    min_pos_iou=0,
                    neg_iou_thr=0.4,
                    pos_iou_thr=0.5,
                    type='mmdet.MaxIoUAssigner'),
                debug=False,
                pos_weight=-1),
        ],
        stage_loss_weights=[
            1.0,
        ]),
    type='MASENet')
msca_start_epoch = 0
num_classes = 5
optim_wrapper = dict(
    clip_grad=dict(max_norm=35, norm_type=2),
    dtype='float32',
    loss_scale='dynamic',
    optimizer=dict(lr=0.0025, momentum=0.9, type='SGD', weight_decay=0.0001),
    type='AmpOptimWrapper')
param_scheduler = [
    dict(
        begin=0,
        by_epoch=False,
        end=500,
        start_factor=0.3333333333333333,
        type='LinearLR'),
    dict(
        begin=0,
        by_epoch=True,
        end=12,
        gamma=0.1,
        milestones=[
            8,
            11,
        ],
        type='MultiStepLR'),
]
randomness = dict(deterministic=False, seed=1324460246)
resume = False
rotated_iou_init = dict(
    _delete_=True, loss_weight=1.0, mode='linear', type='RotatedIoULoss')
rotated_iou_refine = dict(
    loss_weight=1.0, mode='linear', type='RotatedIoULoss')
test_cfg = dict(type='TestLoop')
test_dataloader = dict(
    batch_size=16,
    dataset=dict(
        ann_file='test/annfiles/',
        data_prefix=dict(img_path='test/images/'),
        data_root='data/dronevehicle/',
        img_suffix='jpg',
        metainfo=dict(classes=(
            'car',
            'truck',
            'bus',
            'van',
            'freight_car',
        )),
        pipeline=[
            dict(backend_args=None, type='mmdet.LoadImageFromFile'),
            dict(
                box_type='qbox', type='mmdet.LoadAnnotations', with_bbox=True),
            dict(
                box_type_mapping=dict(gt_bboxes='rbox'),
                type='ConvertBoxType'),
            dict(keep_ratio=True, scale=(
                640,
                512,
            ), type='mmdet.Resize'),
            dict(
                meta_keys=(
                    'img_id',
                    'img_path',
                    'ori_shape',
                    'img_shape',
                    'scale_factor',
                ),
                type='mmdet.PackDetInputs'),
        ],
        test_mode=True,
        type='DOTADataset'),
    drop_last=False,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
test_evaluator = dict(metric='mAP', type='DOTAMetric')
test_pipeline = [
    dict(backend_args=None, type='mmdet.LoadImageFromFile'),
    dict(keep_ratio=True, scale=(
        640,
        512,
    ), type='mmdet.Resize'),
    dict(
        meta_keys=(
            'img_id',
            'img_path',
            'ori_shape',
            'img_shape',
            'scale_factor',
        ),
        type='mmdet.PackDetInputs'),
]
train_cfg = dict(max_epochs=12, type='EpochBasedTrainLoop', val_interval=1)
train_dataloader = dict(
    batch_sampler=None,
    batch_size=8,
    dataset=dict(
        dataset=dict(
            ann_file='train/annfiles/',
            data_prefix=dict(img_path='train/images/'),
            data_root='data/dronevehicle/',
            filter_cfg=dict(filter_empty_gt=True),
            img_suffix='jpg',
            metainfo=dict(
                classes=(
                    'car',
                    'truck',
                    'bus',
                    'van',
                    'freight_car',
                )),
            pipeline=[
                dict(backend_args=None, type='mmdet.LoadImageFromFile'),
                dict(
                    box_type='qbox',
                    type='mmdet.LoadAnnotations',
                    with_bbox=True),
                dict(
                    box_type_mapping=dict(gt_bboxes='rbox'),
                    type='ConvertBoxType'),
                dict(angle_range=180, prob=0.5, type='mmrotate.RandomRotate'),
                dict(keep_ratio=True, scale=(
                    640,
                    512,
                ), type='mmdet.Resize'),
                dict(
                    direction=[
                        'horizontal',
                        'vertical',
                        'diagonal',
                    ],
                    prob=0.75,
                    type='mmdet.RandomFlip'),
                dict(type='mmdet.PackDetInputs'),
            ],
            type='DOTADataset'),
        oversample_thr=0.05,
        type='ClassBalancedDataset'),
    num_workers=2,
    persistent_workers=True,
    sampler=dict(shuffle=True, type='DefaultSampler'))
train_dataset = dict(
    _delete_=True,
    dataset=dict(
        ann_file='train/annfiles/',
        data_prefix=dict(img_path='train/images/'),
        data_root='data/dronevehicle/',
        filter_cfg=dict(filter_empty_gt=True),
        img_suffix='jpg',
        metainfo=dict(classes=(
            'car',
            'truck',
            'bus',
            'van',
            'freight_car',
        )),
        pipeline=[
            dict(backend_args=None, type='mmdet.LoadImageFromFile'),
            dict(
                box_type='qbox', type='mmdet.LoadAnnotations', with_bbox=True),
            dict(
                box_type_mapping=dict(gt_bboxes='rbox'),
                type='ConvertBoxType'),
            dict(keep_ratio=True, scale=(
                640,
                512,
            ), type='mmdet.Resize'),
            dict(
                direction=[
                    'horizontal',
                    'vertical',
                    'diagonal',
                ],
                prob=0.75,
                type='mmdet.RandomFlip'),
            dict(type='mmdet.PackDetInputs'),
        ],
        type='DOTADataset'),
    oversample_thr=0.05,
    type='ClassBalancedDataset')
train_pipeline = [
    dict(backend_args=None, type='mmdet.LoadImageFromFile'),
    dict(box_type='qbox', type='mmdet.LoadAnnotations', with_bbox=True),
    dict(box_type_mapping=dict(gt_bboxes='rbox'), type='ConvertBoxType'),
    dict(angle_range=180, prob=0.5, type='mmrotate.RandomRotate'),
    dict(keep_ratio=True, scale=(
        640,
        512,
    ), type='mmdet.Resize'),
    dict(
        direction=[
            'horizontal',
            'vertical',
            'diagonal',
        ],
        prob=0.75,
        type='mmdet.RandomFlip'),
    dict(type='mmdet.PackDetInputs'),
]
val_cfg = dict(type='ValLoop')
val_dataloader = dict(
    batch_size=16,
    dataset=dict(
        ann_file='val/annfiles/',
        data_prefix=dict(img_path='val/images/'),
        data_root='data/dronevehicle/',
        img_suffix='jpg',
        metainfo=dict(classes=(
            'car',
            'truck',
            'bus',
            'van',
            'freight_car',
        )),
        pipeline=[
            dict(backend_args=None, type='mmdet.LoadImageFromFile'),
            dict(
                box_type='qbox', type='mmdet.LoadAnnotations', with_bbox=True),
            dict(
                box_type_mapping=dict(gt_bboxes='rbox'),
                type='ConvertBoxType'),
            dict(keep_ratio=True, scale=(
                640,
                512,
            ), type='mmdet.Resize'),
            dict(
                meta_keys=(
                    'img_id',
                    'img_path',
                    'ori_shape',
                    'img_shape',
                    'scale_factor',
                ),
                type='mmdet.PackDetInputs'),
        ],
        test_mode=True,
        type='DOTADataset'),
    drop_last=False,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(shuffle=False, type='DefaultSampler'))
val_evaluator = dict(metric='mAP', type='DOTAMetric')
val_pipeline = [
    dict(backend_args=None, type='mmdet.LoadImageFromFile'),
    dict(box_type='qbox', type='mmdet.LoadAnnotations', with_bbox=True),
    dict(box_type_mapping=dict(gt_bboxes='rbox'), type='ConvertBoxType'),
    dict(keep_ratio=True, scale=(
        640,
        512,
    ), type='mmdet.Resize'),
    dict(
        meta_keys=(
            'img_id',
            'img_path',
            'ori_shape',
            'img_shape',
            'scale_factor',
        ),
        type='mmdet.PackDetInputs'),
]
vis_backends = [
    dict(type='LocalVisBackend'),
]
visualizer = dict(
    name='visualizer',
    type='RotLocalVisualizer',
    vis_backends=[
        dict(type='LocalVisBackend'),
    ])
work_dir = 'work_dirs/dronevehicle/DV_PQ_s246'
