#!/usr/bin/env python
"""The CMM pairs one checkpoint's own miner emits at the end of training (2026-11-03, CPU).

  python own_pairs.py CONFIG CKPT STATS      (from the mmrotate root) -> last line VARIANT p<a>-<b>_..._r<k>

Rule, fixed on 11-03 before any FAIR1M-AIR model finished training: the pairs are
active_pairs_from_confusion(confusion, totals, threshold, max_pairs) on the checkpoint's
bbox_head_init.confusion_miner buffers, with the threshold and max_pairs of the config's own miner (what the CMM
hands to the loss at that point); if that gives no pair, the max_pairs pairs with the highest ConfuseScore.  The
rare class (every one of its boxes is kept for the classifier) is the pair class with the fewest train instances
in STATS (the official FAIR1M-AIR statistics.txt).  The printed name is a ppspec variant (PPSPEC_VARIANT).
"""
import re
import sys

import torch
from mmengine.config import Config

sys.path.insert(0, '.')
from mmrotate.models.losses.msca_loss import active_pairs_from_confusion  # noqa: E402


def main():
    cfg_f, ck, stats = sys.argv[1:4]
    cfg = Config.fromfile(cfg_f, import_custom_modules=False).to_dict()
    head = cfg['model']['bbox_head_init']
    miner = head['confusion_miner']
    classes = list(cfg['test_dataloader']['dataset']['metainfo']['classes'])
    sd = torch.load(ck, map_location='cpu')
    st = sd['state_dict']
    M = st['bbox_head_init.confusion_miner.confusion'].float()
    T = st['bbox_head_init.confusion_miner.totals'].float()
    S = (M + M.t()) / (T[:, None] + T[None, :]).clamp_min(1e-6)
    pairs = active_pairs_from_confusion(M, T, float(miner['threshold']), miner['max_pairs'])
    how = 'active pairs (threshold %s, max_pairs %s)' % (miner['threshold'], miner['max_pairs'])
    if not pairs:
        n = S.shape[0]
        iu = torch.triu_indices(n, n, 1)
        sc = S[iu[0], iu[1]]
        top = sc.argsort(descending=True)[:int(miner['max_pairs'])]
        pairs = [(int(iu[0][i]), int(iu[1][i])) for i in top]
        how = 'no active pair; top %s by ConfuseScore' % miner['max_pairs']
    pairs = sorted(tuple(sorted((int(a), int(b)))) for a, b in pairs)
    block = open(stats, encoding='utf-8').read().split('-- TRAIN --')[1].split('--')[0]
    inst = {m.group(1): int(m.group(2)) for m in re.finditer(r'类别 (\S+): 图像 \d+, 实例 (\d+)', block)}
    union = sorted({c for p in pairs for c in p})
    rare = min(union, key=lambda c: (inst[classes[c]], c))
    print('checkpoint %s epoch %s; positives %.0f; %s' % (ck, sd.get('meta', {}).get('epoch'), T.sum(), how))
    for a, b in pairs:
        print('  pair (%d, %d) %s / %s ConfuseScore %.4f' % (a, b, classes[a], classes[b], S[a, b]))
    print('  rare class %d %s (%d train instances)' % (rare, classes[rare], inst[classes[rare]]))
    print('VARIANT p%s_r%d' % ('_'.join('%d-%d' % p for p in pairs), rare))


if __name__ == '__main__':
    main()
