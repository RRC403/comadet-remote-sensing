#!/usr/bin/env python
"""More ways to fuse the modules with native TTA, screened on the validation halves (2026-11-03, eval only).

  python native_screen.py screen --cache DIR --tag TAG [--kind pairclf|proto] --out OUT.json [--nproc 16]
  python native_screen.py decide --screens S.json [S.json ...] --out DECIDE.json
  python native_screen.py apply --cache DIR --tag TAG [--kind ..] --decide DECIDE.json --out OUT.json [--use DATASET]

Native TTA (the user's teacher, 11-03): the views (SODA-A / FAIR1M 0/90/180/270-degree rotations, VisDrone
flips) merged by per-class NMS 0.4, each cluster keeping its highest-scoring box with its own score
(tta_fusion_eval alpha 1, leader box).  The user does not use the fused TTA, which averages boxes and scores
across views.  Every structure below keeps the leader boxes and changes scores with a module's evidence only;
relabel also adds a copy of a leader under another class.
pairclf caches (pairclf_cache.py; q = the pair-class re-classifier's probabilities over the CMM pair classes and
background, on every pair-class box):
  pre      every view's pair-class boxes are rescored before the merge: own s' = s^(1-lam) q[own]^lam, fg
           s' = s^(1-lam) (1 - q[bg])^lam; dup adds a copy in the pair class q prefers (pairclf_screen.modify;
           own / lam 0.5 / no dup is the structure native_check.py checked)
  post     the merge runs on the detector scores; the leader of each pair-class cluster is rescored with qbar,
           the score-weighted mean of q over the cluster's members in all views (the cross-view consensus)
  relabel  post (own), and a pair-class leader whose qbar prefers another pair class is added once more under
           that class at s^(1-lam) qbar[that class]^lam, unless a leader of that class overlaps it (IoU > 0.4)
  arb      pre (own, lam 0.5, no dup), then two leaders that overlap (IoU > t) and whose classes form a CMM pair
           are arbitrated by the re-classifier: the score-weighted mean of q over the members of both clusters;
           the leader whose class gets less is multiplied by gamma (0 = removed)
  csup     the CMM pairs alone, no re-classifier: of two overlapping leaders (IoU > t) whose classes form a CMM
           pair, the lower-scoring one is multiplied by gamma
  arb and csup go in descending score; a leader is decayed at most once, and a decayed one decides nothing.
proto caches (../proto_tta_cache.py, SODA-A val only; per box the cosines to the CPD class prototypes and the
IC2 cross-scale agreement):
  cpd_pre / cpd_post  p = softmax(cos / 0.1)[class] (soft; 0.1 = the CPD training temperature) or
           (1 + cos[class]) / 2 (cos); s' = s^(1-lam) p^lam on every view before the merge (pre), or on the
           leader with the score-weighted cluster mean of p (post); scope pair = the CMM pair classes only
  ic2_pre / ic2_post  a = (1 + ic2) / 2: s' = s a^beta, per box before the merge or with the cluster mean
Boxes with detector score < 0.05 are dropped first, as in native_check.py.  Split: the 50/50 split by source
image / video of tta_fusion_eval (seed 0).  screen: native TTA and every setting on both halves of one model.
Rule, fixed 11-03 before any of these numbers: for each structure separately, the setting with the best mean
native-TTA gain over the dataset's models on val half A is taken; the structure is adopted on that dataset if on
half B every model gains >= +0.002 over native TTA; the adopted structure with the best half-A mean is the main
one.  apply: native TTA and the adopted structures (settings from val half A) on a test cache; nothing is
chosen there.  FAIR1M-AIR picks nothing: --use soda applies the structures adopted on SODA-A.
"""
import argparse
import collections
import json
import os
import pickle
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ppspec  # noqa: E402

THR = 0.05
TAU = 0.1
MIN_GAIN = 0.002
RULE = ('per structure, the setting with the best mean native-TTA gain over the models on val half A; adopted if on '
        'half B every model gains >= +0.002 over native TTA; main = the adopted one with the best half-A mean')
PAIRCLF = ([('pre', dict(f='own', lam=lam, dup=False)) for lam in (0.3, 0.5, 0.7, 1.0)]
           + [('pre', dict(f='fg', lam=lam, dup=False)) for lam in (0.5, 1.0)]
           + [('pre', dict(f='own', lam=0.5, dup=True))]
           + [('post', dict(f='own', lam=lam)) for lam in (0.3, 0.5, 0.7, 1.0)]
           + [('post', dict(f='fg', lam=lam)) for lam in (0.5, 1.0)]
           + [('relabel', dict(lam=lam)) for lam in (0.5, 1.0)]
           + [(st, dict(t=t, gamma=g)) for st in ('arb', 'csup') for t in (0.4, 0.6) for g in (0.0, 0.5)])
_CPD = [dict(p='soft', lam=lam, scope=sc) for lam in (0.15, 0.3) for sc in ('pair', 'all')] + \
       [dict(p='cos', lam=0.3, scope=sc) for sc in ('pair', 'all')]
PROTO = ([(st, dict(d)) for st in ('cpd_pre', 'cpd_post') for d in _CPD]
         + [(st, dict(beta=b)) for st in ('ic2_pre', 'ic2_post') for b in (0.5, 1.0)])
ARB_BASE = ('pre', 'own', 0.5, False)
EMPTY = (np.zeros((0, 5), np.float32), np.zeros(0, np.float32), np.zeros(0, np.int64))


def _libs():
    """torch / mmcv / the evaluators; decide runs without them."""
    global torch, box_iou_rotated, PS, TF
    import torch
    from mmcv.ops import box_iou_rotated
    import pairclf_screen as PS
    import tta_fusion_eval as TF


def key(st, p):
    return '%s(%s)' % (st, ','.join('%s=%s' % kv for kv in p.items()))


def ckey(st, p):
    """The views the merge runs on: the detector scores, or the views rescored before the merge."""
    if st == 'pre':
        return ('pre', p['f'], p['lam'], p['dup'])
    if st == 'arb':
        return ARB_BASE
    if st == 'cpd_pre':
        return ('cpd', p['p'], p['lam'], p['scope'])
    if st == 'ic2_pre':
        return ('ic2', p['beta'])
    return ('raw',)


def load(kind, d, limit=0):
    """-> spec, images; raw = per view (boxes, scores, labels, evidence) with score >= THR.  Evidence: q of the
    re-classifier (pairclf) or the 9 prototype cosines and the IC2 agreement (proto, SODA-A)."""
    if kind == 'pairclf':
        spec, imgs = PS.load(d)
        return spec, imgs[:limit or None]
    spec = ppspec.get('soda')
    views = [pickle.load(open(os.path.join(d, f), 'rb')) for f in spec.view_files]
    ids = [r['img_id'] for r in views[0]]
    if any([r['img_id'] for r in v] != ids for v in views[1:]):
        raise RuntimeError('image order differs between views')
    imgs = []
    for i, r0 in enumerate(views[0][:limit or None]):
        raw = []
        for v in views:
            r = v[i]
            s = np.asarray(r['scores'], np.float32).reshape(-1)
            k = s >= THR
            e = np.hstack([np.asarray(r['proto'], np.float32).reshape(-1, spec.k),
                           np.asarray(r['ic2'], np.float32).reshape(-1, 1)])
            raw.append((np.asarray(r['boxes'], np.float32).reshape(-1, 5)[k], s[k],
                        np.asarray(r['labels'], np.int64).reshape(-1)[k], e[k]))
        imgs.append(dict(img_id=str(r0['img_id']), raw=raw, gt_boxes=ppspec.gt_to_orig(r0['gt_boxes'], r0['scale_factor']),
                         gt_labels=np.asarray(r0['gt_labels'], np.int64).reshape(-1)))
    return spec, imgs


def kind_of(st):
    return 'proto' if st.startswith(('cpd', 'ic2')) else 'pairclf'


def proto_p(e, l, how, k):
    """Per box: prototype evidence for its own class."""
    cos = e[:, :k].astype(np.float64)
    n = np.arange(len(l))
    if how == 'cos':
        return (1 + cos[n, l]) / 2
    z = np.exp((cos - cos.max(1, keepdims=True)) / TAU)
    return z[n, l] / z.sum(1)


def views_for(img, ck, spec):
    """The views the merge runs on, each (boxes, scores, labels, evidence or None)."""
    out = []
    for b, s, l, e in img['raw']:
        if ck[0] == 'pre':
            b2, s2, l2 = PS.modify(b, s, l, e, ck[1:], spec)
            out.append((b2, s2, l2, e if len(s2) == len(s) else None))
            continue
        s2 = s.astype(np.float64)
        if ck[0] == 'cpd':
            sel = np.isin(l, spec.pair) if ck[3] == 'pair' else np.ones(len(l), bool)
            p = np.clip(proto_p(e, l, ck[1], spec.k), 1e-6, 1.0)
            s2[sel] = np.power(s2[sel], 1 - ck[2]) * np.power(p[sel], ck[2])
        elif ck[0] == 'ic2':
            s2 = s2 * np.power(np.clip((1 + e[:, spec.k].astype(np.float64)) / 2, 1e-6, 1.0), ck[1])
        out.append((b, s2.astype(np.float32), l, e))
    return out


def cluster(vs, dev):
    """Per-class NMS clusters of native TTA over all views, with every member's evidence in the same order."""
    cl = TF.cluster_image(dict(views=[v[:3] for v in vs]), len(vs), 0.0, dev)
    E = None
    if all(v[3] is not None for v in vs):
        E = np.concatenate([v[3] for v in vs])
        if len(E) != len(cl['S']):
            raise RuntimeError('evidence does not line up with the clustered boxes')
    return cl, E


def finish(b, s, l):
    k = s > 0
    b, s, l = b[k], s[k], l[k]
    o = np.argsort(-s, kind='stable')[:TF.MAX_PER_IMG]
    return b[o].astype(np.float32), s[o].astype(np.float32), l[o]


def cmean(X, w, pos, n):
    tot = np.maximum(np.bincount(pos, w, n), 1e-12)
    return np.stack([np.bincount(pos, w * X[:, j], n) for j in range(X.shape[1])], 1) / tot[:, None]


def iou(a, b, dev):
    return box_iou_rotated(torch.from_numpy(np.ascontiguousarray(a, np.float32)).to(dev),
                           torch.from_numpy(np.ascontiguousarray(b, np.float32)).to(dev),
                           aligned=False, clockwise=True).cpu().numpy()


def pair_overlaps(B, L, pairs, t, dev):
    """Leader index pairs (i, j) whose classes form a CMM pair and whose boxes overlap with IoU > t."""
    ii, jj = [], []
    for ca, cb in pairs:
        ia, ib = np.where(L == ca)[0], np.where(L == cb)[0]
        if len(ia) and len(ib):
            x, y = np.nonzero(iou(B[ia], B[ib], dev) > t)
            ii.append(ia[x])
            jj.append(ib[y])
    if not ii:
        return np.zeros(0, np.int64), np.zeros(0, np.int64)
    return np.concatenate(ii), np.concatenate(jj)


def decay(LB, LS, LL, pairs, t, gamma, arb, dev):
    """csup (arb None): the lower-scoring leader of an overlapping CMM pair is multiplied by gamma.  arb: the
    re-classifier's mean q over both clusters decides which one."""
    i, j = pair_overlaps(LB, LL, pairs, t, dev)
    s = LS.copy()
    if not len(i):
        return s
    if arb is None:
        up = LS[i] >= LS[j]
    else:
        Wq, tot, kk = arb
        u = (Wq[i] + Wq[j]) / np.maximum(tot[i] + tot[j], 1e-12)[:, None]
        r = np.arange(len(i))
        up = u[r, kk[i]] >= u[r, kk[j]]
    lo = np.where(up, j, i)
    dead = np.zeros(len(s), bool)
    for c in np.argsort(-np.maximum(LS[i], LS[j]), kind='stable'):
        if dead[i[c]] or dead[j[c]]:
            continue
        s[lo[c]] *= gamma
        dead[lo[c]] = True
    return s


def structure(cl, E, st, p, spec, dev):
    """Native-TTA leaders of one image (boxes unchanged), scored by structure st."""
    B, S, L, lead = cl['B'], cl['S'], cl['L'], cl['lead']
    m = lead >= 0
    ld = np.unique(lead[m])
    if not len(ld):
        return EMPTY
    n = len(ld)
    pos = np.searchsorted(ld, lead[m])
    LB, LS, LL = B[ld], S[ld].astype(np.float64), L[ld]
    if st in ('native', 'pre', 'cpd_pre', 'ic2_pre'):
        return finish(LB, LS, LL)
    if st == 'csup':
        return finish(LB, decay(LB, LS, LL, spec.pairs, p['t'], p['gamma'], None, dev), LL)
    w = S[m].astype(np.float64)
    tot = np.maximum(np.bincount(pos, w, n), 1e-12)
    isp = np.isin(LL, spec.pair)
    s2 = LS.copy()
    if st in ('cpd_post', 'ic2_post'):
        if st == 'cpd_post':
            f = np.bincount(pos, w * proto_p(E[m], L[m], p['p'], spec.k), n) / tot
            sel = isp if p['scope'] == 'pair' else np.ones(n, bool)
            s2[sel] = np.power(LS[sel], 1 - p['lam']) * np.power(np.clip(f[sel], 1e-6, 1.0), p['lam'])
        else:
            f = np.bincount(pos, w * (1 + E[m][:, spec.k].astype(np.float64)) / 2, n) / tot
            s2 = LS * np.power(np.clip(f, 1e-6, 1.0), p['beta'])
        return finish(LB, s2, LL)
    Em = E[m].astype(np.float64)
    if (Em[np.isin(L[m], spec.pair), 0] < 0).any():
        raise RuntimeError('a pair-class box without re-classifier probabilities')
    kk = np.minimum(np.searchsorted(spec.pair, LL), len(spec.pair) - 1)
    r = np.arange(n)
    if st == 'arb':
        Wq = np.zeros((n, spec.out))
        np.add.at(Wq, pos, Em * w[:, None])
        return finish(LB, decay(LB, LS, LL, spec.pairs, p['t'], p['gamma'], (Wq, tot, kk), dev), LL)
    qq = np.clip(cmean(Em, w, pos, n), 1e-6, 1.0)
    lam = p['lam']
    f = qq[r, kk] if p.get('f', 'own') == 'own' else np.clip(1 - qq[:, spec.bg], 1e-6, 1.0)
    s2[isp] = np.power(LS[isp], 1 - lam) * np.power(f[isp], lam)
    if st == 'post':
        return finish(LB, s2, LL)
    o = qq[:, :len(spec.pair)].copy()
    o[r, kk] = -1
    jb = o.argmax(1)
    cand = np.where(isp & (o[r, jb] > qq[r, kk]))[0]
    if len(cand):
        newc = spec.pair[jb[cand]]
        keep = np.ones(len(cand), bool)
        for c in np.unique(newc):
            sel = np.where(newc == c)[0]
            others = np.where(LL == c)[0]
            if len(others):
                keep[sel[iou(LB[cand[sel]], LB[others], dev).max(1) > TF.NMS_IOU]] = False
        cand, newc = cand[keep], newc[keep]
        LB = np.concatenate([LB, LB[cand]])
        s2 = np.concatenate([s2, np.power(LS[cand], 1 - lam) * np.power(qq[cand, jb[cand]], lam)])
        LL = np.concatenate([LL, newc])
    return finish(LB, s2, LL)


def run(imgs, halves, settings, spec, dev, nproc, log):
    """mAP of every (structure, setting) on every half; native TTA is checked against tta_fusion_eval.fuse."""
    groups = collections.OrderedDict()
    for st, p in settings:
        groups.setdefault(ckey(st, p), []).append((st, p))
    res, t0 = {}, time.time()
    for ck, items in groups.items():
        outs = collections.OrderedDict((key(st, p), []) for st, p in items)
        for img in imgs:
            vs = views_for(img, ck, spec)
            cl, E = cluster(vs, dev)
            for st, p in items:
                outs[key(st, p)].append(structure(cl, E, st, p, spec, dev))
            if ck == ('raw',):
                ref = TF.fuse(cl, len(vs), 1.0, 'leader', None, dev)
                got = outs['native()'][-1]
                if len(ref[1]) != len(got[1]) or not (np.array_equal(ref[1], got[1]) and np.array_equal(ref[2], got[2])):
                    raise RuntimeError('native TTA does not reproduce tta_fusion_eval on %s' % img['img_id'])
        for k, o in outs.items():
            res[k] = {h: TF.evaluate([imgs[i] for i in idx], [o[i] for i in idx], nproc, spec.k)
                      for h, idx in halves.items()}
            log('  %s %s (%.0fs)' % (k, ' '.join('%s %.4f' % (h, r[0]) for h, r in res[k].items()), time.time() - t0))
    return res


def pooled(caches, kind, limit):
    """One model, or several pooled per image (ensemble: every model's views, each with its own evidence)."""
    specs, data = [], []
    for x in caches:
        s, imgs = load(kind, x.split('=', 1)[1], limit)
        specs.append(s)
        data.append({i['img_id']: i for i in imgs})
    if len({s.name for s in specs}) != 1:
        raise SystemExit('caches of different datasets: %s' % [s.name for s in specs])
    ids = sorted(data[0])
    if any(set(d) != set(ids) for d in data):
        raise SystemExit('caches of different image sets')
    if len(data) == 1:
        return specs[0], [data[0][k] for k in ids]
    return specs[0], [dict(img_id=k, gt_boxes=data[0][k]['gt_boxes'], gt_labels=data[0][k]['gt_labels'],
                           raw=[v for d in data for v in d[k]['raw']]) for k in ids]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['screen', 'decide', 'apply'])
    ap.add_argument('--cache', nargs='+', help='TAG=DIR (apply: several = an ensemble)')
    ap.add_argument('--kind', choices=['pairclf', 'proto'], default='pairclf')
    ap.add_argument('--screens', nargs='+')
    ap.add_argument('--name', help='decide: name of the model group')
    ap.add_argument('--decide')
    ap.add_argument('--use', help='apply: take the structures of this group (default: the cache dataset)')
    ap.add_argument('--out', required=True)
    ap.add_argument('--nproc', type=int, default=16)
    ap.add_argument('--limit', type=int, default=0, help='first N images only (smoke tests)')
    a = ap.parse_args()
    t0 = time.time()

    def log(s):
        print(s, flush=True)

    if a.mode == 'decide':
        sc = [json.load(open(f)) for f in a.screens]
        if len({s['dataset'].split(':')[0] for s in sc}) != 1:
            raise SystemExit('screens of different datasets')
        out = dict(rule=RULE, name=a.name, dataset=sc[0]['dataset'].split(':')[0], screens=a.screens, structures={})
        for st in collections.OrderedDict.fromkeys(r['st'] for s in sc for r in s['settings'].values()):
            if st == 'native':
                continue
            ms = [s for s in sc if any(r['st'] == st for r in s['settings'].values())]
            ks = [k for k, r in ms[0]['settings'].items() if r['st'] == st]
            gain = {k: float(np.mean([s['settings'][k]['A'][0] - s['settings']['native()']['A'][0] for s in ms]))
                    for k in ks}
            best = max(ks, key=lambda k: (round(gain[k], 6), -ks.index(k)))
            gb = {s['tag']: round(s['settings'][best]['B'][0] - s['settings']['native()']['B'][0], 4) for s in ms}
            ok = len(ms) >= 2 and all(g >= MIN_GAIN for g in gb.values())
            out['structures'][st] = dict(key=best, setting=ms[0]['settings'][best]['p'], kind=ms[0]['kind'],
                                         A_mean=round(gain[best], 4), B=gb, adopt=bool(ok),
                                         native_B={s['tag']: s['settings']['native()']['B'][0] for s in ms})
            log('NSCREEN %s %s A-best %s (A mean %+.4f); B %s; adopt=%s' % (
                a.name, st, best, gain[best], ' '.join('%s %+.4f' % kv for kv in gb.items()), ok))
        ad = [st for st, r in out['structures'].items() if r['adopt']]
        out['adopted'] = ad
        out['main'] = max(ad, key=lambda st: out['structures'][st]['A_mean']) if ad else None
        json.dump(out, open(a.out, 'w'), indent=1)
        log('NSCREEN %s adopted %s; main %s (%s)' % (a.name, ad or 'none', out['main'], RULE))
        return

    tags = '+'.join(x.split('=', 1)[0] for x in a.cache)
    if a.mode == 'apply':
        dc = json.load(open(a.decide))
        if a.use and dc['dataset'] != a.use:
            raise SystemExit('%s holds the structures of %s, not %s' % (a.decide, dc['dataset'], a.use))
        sel = [(st, r['setting']) for st, r in dc['structures'].items() if r['adopt'] and r['kind'] == a.kind]
        if not sel:
            log('NAPPLY %s: no %s structure was adopted on %s, nothing to apply' % (tags, a.kind, dc['name']))
            return
    _libs()
    dev = 'cuda' if torch.cuda.is_available() else 'cpu'
    spec, imgs = pooled(a.cache, a.kind, a.limit)
    log('%s: %s (%s), %d images, %d views (%.0fs)' % (tags, spec.name, a.kind, len(imgs), len(imgs[0]['raw']),
                                                    time.time() - t0))
    if a.mode == 'screen':
        if len(a.cache) != 1:
            raise SystemExit('screen takes one model')
        A, Bh = TF.split_ids(imgs, spec.group)
        settings = [('native', {})] + (PAIRCLF if a.kind == 'pairclf' else PROTO)
        log('RULE ' + RULE)
        res = run(imgs, dict(A=A, B=Bh), settings, spec, dev, a.nproc, log)
        out = dict(tag=tags, dataset=spec.name, kind=a.kind, cache=a.cache[0], n_A=len(A), n_B=len(Bh),
                   settings={key(st, p): dict(st=st, p=p, **res[key(st, p)]) for st, p in settings})
        json.dump(out, open(a.out, 'w'), indent=1)
        nb = res['native()']
        log('NSCREEN-MODEL %s native A %.4f B %.4f; best A gain per structure: %s (%.0fs)' % (
            tags, nb['A'][0], nb['B'][0], ' '.join(
                '%s %+.4f' % (st, max(res[key(s2, p)]['A'][0] - nb['A'][0] for s2, p in settings if s2 == st))
                for st in collections.OrderedDict.fromkeys(s for s, _ in settings[1:])), time.time() - t0))
        return
    if not a.use and dc['dataset'] != spec.name.split(':')[0]:
        raise SystemExit('%s was decided on %s, the cache is %s' % (a.decide, dc['dataset'], spec.name))
    log('NOTE the settings were picked on val half A of %s; nothing is chosen here' % dc['name'])
    settings = [('native', {})] + sel
    res = run(imgs, dict(all=list(range(len(imgs)))), settings, spec, dev, a.nproc, log)
    out = dict(caches=a.cache, dataset=spec.name, kind=a.kind, decide=a.decide, main=dc['main'], n=len(imgs),
               results={key(st, p): dict(st=st, p=p, **res[key(st, p)]) for st, p in settings})
    json.dump(out, open(a.out, 'w'), indent=1)
    nat = res['native()']['all'][0]
    log('NAPPLY %s native TTA %.4f; %s (%.0fs)' % (tags, nat, '; '.join(
        '%s%s %.4f (%+.4f)' % (st, '*' if st == dc['main'] else '', res[key(st, p)]['all'][0],
                               res[key(st, p)]['all'][0] - nat) for st, p in sel) or 'no adopted structure',
        time.time() - t0))


if __name__ == '__main__':
    main()
