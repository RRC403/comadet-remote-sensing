#!/usr/bin/env python
"""Plain and fused rotation TTA on tta_rotated.py caches, any rot4 dataset of ppspec.py (2026-11-03, eval only).

  python tta_apply.py --caches TAG=DIR [TAG=DIR ...] --dataset fair1m --out OUT.json [--nproc 16]

The numbers of tta_fusion_eval.py apply --thr 0.05 --alpha 0.5 --box wavg (written for SODA-A's 9 classes),
with the dataset's class count.  Each DIR is a tta_rotated.py cache (angle_{0,90,180,270}.pkl, GT of the
0-degree view).  Boxes with score < 0.05 are dropped.  Per model: single view (per-class NMS 0.4 on the
0-degree view), plain TTA (the 4 views merged by per-class NMS) and fused TTA (alpha 0.5, score-weighted box
average, the setting picked on SODA-A val, not re-tuned).  With several models also their ensemble, as
pairclf_ens.py base: the views of all models pooled per image, for the 0-degree views (models x 1) and all
views (models x 4).  Nothing is chosen here.  Single view and plain TTA must equal the '角度子集 0' and
'0+90+180+270' lines of tta_rotated.py on the same cache.
"""
import argparse
import collections
import json
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ppspec  # noqa: E402
import tta_fusion_eval as TF  # noqa: E402

THR = 0.05


def run(imgs, n, alpha, box, dev, nproc, k):
    cl = [TF.cluster_image(i, n, THR, dev) for i in imgs]
    return TF.evaluate(imgs, [TF.fuse(c, n, alpha, box, None, dev, n_cls=k) for c in cl], nproc, k)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--caches', nargs='+', required=True)
    ap.add_argument('--dataset', required=True, choices=sorted(ppspec.SPECS))
    ap.add_argument('--out', required=True)
    ap.add_argument('--nproc', type=int, default=16)
    a = ap.parse_args()
    spec = ppspec.get(a.dataset)
    if spec.views != ppspec.VIEWS['rot4']:
        raise SystemExit('%s uses the views %s; tta_rotated.py caches hold rotations' % (spec.name, spec.view_files))
    dev = 'cuda' if torch.cuda.is_available() else 'cpu'
    t0 = time.time()
    models = collections.OrderedDict(x.split('=', 1) for x in a.caches)
    data = {t: TF.load_cache(d) for t, d in models.items()}
    for t, imgs in data.items():
        top = max((int(i['gt_labels'].max()) for i in imgs if len(i['gt_labels'])), default=-1)
        if top >= spec.k:
            raise SystemExit('%s: GT label %d, but %s has %d classes' % (t, top, spec.name, spec.k))
    res = dict(dataset=spec.name, caches=dict(models), thr=THR, alpha=0.5, box='wavg', results={}, ensemble={})
    for t, imgs in data.items():
        r = dict(single=run(imgs, 1, 1.0, 'leader', dev, a.nproc, spec.k),
                 plain=run(imgs, 4, 1.0, 'leader', dev, a.nproc, spec.k),
                 fused=run(imgs, 4, 0.5, 'wavg', dev, a.nproc, spec.k))
        res['results'][t] = r
        print('TTA-APPLY %s %d images: single %.4f  plain TTA %.4f  fused TTA %.4f (%.0fs)' % (
            t, len(imgs), r['single'][0], r['plain'][0], r['fused'][0], time.time() - t0), flush=True)
    if len(models) > 1:
        by_id = {t: {i['img_id']: i for i in imgs} for t, imgs in data.items()}
        first = by_id[next(iter(models))]
        ids = sorted(first)
        for t in models:
            if set(by_id[t]) != set(ids):
                raise SystemExit('%s was cached on different images' % t)
        for name, views in (('angle0', [0]), ('all4', list(range(len(spec.views))))):
            merged = [dict(img_id=k, gt_boxes=first[k]['gt_boxes'], gt_labels=first[k]['gt_labels'],
                           views=[by_id[t][k]['views'][v] for t in models for v in views]) for k in ids]
            n = len(models) * len(views)
            r = dict(plain=run(merged, n, 1.0, 'leader', dev, a.nproc, spec.k),
                     fused=run(merged, n, 0.5, 'wavg', dev, a.nproc, spec.k))
            res['ensemble'][name] = r
            print('TTA-APPLY ensemble %s %s views=%d: plain %.4f  fused %.4f (%.0fs)' % (
                '+'.join(models), name, n, r['plain'][0], r['fused'][0], time.time() - t0), flush=True)
    json.dump(res, open(a.out, 'w'), indent=1)
    print('TTA_APPLY_DONE (%.0fs)' % (time.time() - t0), flush=True)


if __name__ == '__main__':
    main()
