#!/usr/bin/env python
"""Multi-model ensemble on the re-classifier test caches, any dataset (2026-11-02, eval only).

  python pairclf_ens.py --caches TAG=DIR [TAG=DIR ...] --final FINAL.json --which base|best --out OUT.json
         [--nproc 24]

Each DIR comes from pairclf_cache.py (4 views; every pair-class box carries its own model's re-classifier
probabilities).  Boxes with detector score < 0.05 are dropped, each model's views are rescored with its own
re-classifier (best: the setting pairclf_screen.py final picked on val half A; base: unchanged), then the
views of all models are pooled per image and fused as in ens_eval.py: plain = per-class NMS over all views,
fused = alpha 0.5 with the score-weighted box average.  Reported for the 0-degree views (models x 1) and all
views (models x 4).  Nothing is chosen here; base reproduces ens_eval.py on the same models.
Generalized copy of ../pairclf_ens.py (same numbers on SODA-A): all caches must be of one dataset.
"""
import argparse
import collections
import json
import os
import sys
import time

import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pairclf_screen as PS  # noqa: E402
import tta_fusion_eval as TF  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--caches', nargs='+', required=True)
    ap.add_argument('--final', required=True)
    ap.add_argument('--which', choices=['base', 'best'], required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--nproc', type=int, default=24)
    ap.add_argument('--limit', type=int, default=0, help='first N tiles only (smoke tests)')
    a = ap.parse_args()
    dev = 'cuda' if torch.cuda.is_available() else 'cpu'
    t0 = time.time()
    setting = None if a.which == 'base' else tuple(json.load(open(a.final))['best'])
    print('NOTE setting %s was picked on val half A; nothing is chosen here' % (setting,), flush=True)
    models = collections.OrderedDict(x.split('=', 1) for x in a.caches)
    data, specs = {}, {}
    for t, d in models.items():
        specs[t], imgs = PS.load(d)
        data[t] = {i['img_id']: i for i in imgs}
        print('%s: %d tiles (%.0fs)' % (t, len(data[t]), time.time() - t0), flush=True)
    if len({s.name for s in specs.values()}) != 1:
        raise SystemExit('caches of different datasets: %s' % {t: s.name for t, s in specs.items()})
    spec = specs[next(iter(models))]
    first = data[next(iter(models))]
    ids = sorted(first)
    for t in models:
        if set(data[t]) != set(ids):
            raise SystemExit('%s was cached on a different image set' % t)
    ids = ids[:a.limit or None]
    res = dict(caches=dict(models), which=a.which, setting=setting and list(setting), n_images=len(ids),
               results={})
    if spec.name != 'soda':
        res['dataset'] = spec.name
    for name, views in (('angle0', [0]), ('all4', list(range(len(spec.views))))):
        merged = [dict(img_id=k, gt_boxes=first[k]['gt_boxes'], gt_labels=first[k]['gt_labels'],
                       views=[PS.modify(*data[t][k]['raw'][v], setting, spec) for t in models for v in views])
                  for k in ids]
        n = len(models) * len(views)
        cl = [TF.cluster_image(i, n, 0.0, dev) for i in merged]
        r = dict(plain=TF.evaluate(merged, [TF.fuse(c, n, 1.0, 'leader', None, dev) for c in cl], a.nproc, spec.k),
                 fused=TF.evaluate(merged, [TF.fuse(c, n, 0.5, 'wavg', None, dev) for c in cl], a.nproc, spec.k))
        res['results'][name] = r
        print('PAIRCLF-ENS %s %s %s views=%d plain=%.4f fused=%.4f (%.0fs)' % (
            '+'.join(models), a.which, name, n, r['plain'][0], r['fused'][0], time.time() - t0), flush=True)
    json.dump(res, open(a.out, 'w'), indent=1)
    print('PAIRCLF_ENS_DONE', flush=True)


if __name__ == '__main__':
    main()
