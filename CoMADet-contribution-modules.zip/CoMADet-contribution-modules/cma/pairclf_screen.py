#!/usr/bin/env python
"""Screen / apply the pair-class re-classifier on a TTA cache, any dataset (2026-11-02, eval only).

  python pairclf_screen.py grid --cache DIR --tag TAG --out TAG_grid.json [--nproc 32]
  python pairclf_screen.py final --grids G1.json G2.json --out FINAL.json [--nproc 32]
  python pairclf_screen.py apply --cache DIR --tag TAG --final FINAL.json --which base|best --out OUT.json
  python pairclf_screen.py report --base BASE.json --best BEST.json

Generalized copy of ../pairclf_screen.py (same numbers on SODA-A).  The dataset, its views and its pair
classes come from the cache (ppspec.for_cache).  Each DIR comes from pairclf_cache.py (4 views; every
pair-class box carries the re-classifier's probabilities q over the pair classes and background).  Boxes
with detector score < 0.05 are dropped first (the classifier was trained on detections >= 0.05), then every
pair-class box in every view is rescored
  own   s' = s^(1-lam) * q[own class]^lam
  fg    s' = s^(1-lam) * (1 - q[background])^lam
and with dup a copy of the box is added in the pair class the classifier prefers, when it prefers another
pair class, scored s^(1-lam) * q[that class]^lam.  The usual pipelines then run unchanged: single view =
per-class NMS 0.4 on the first (identity) view; fused TTA = tta_fusion_eval's clusters over the 4 views,
alpha 0.5, weighted-average box.
grid: baselines on both halves and every grid setting on half A only, for one model.  Halves split by
source image (SODA-A, FAIR1M) or video sequence (VisDrone), seed 0.
final: picks the setting with the best mean over models of min(single-view gain, fused-TTA gain) on half A,
then runs it on half B.
Rule, fixed before any number was seen: adopt if on half B every model gains >= +0.002 over its single model
AND >= +0.002 over its fused TTA.
apply: every image of the cache, without the rescoring (base) or with the setting FINAL.json picked on val
half A (best); nothing is chosen.  It also reports plain TTA (alpha 1, NMS merge of the views).  report: the
two side by side.
"""
import argparse
import json
import os
import pickle
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import ppspec  # noqa: E402
import tta_fusion_eval as TF  # noqa: E402

THR = 0.05
GRID = [(f, lam, dup) for f in ('own', 'fg') for lam in (0.5, 1.0) for dup in (False, True)]
RULE = 'adopt if on half B every model gains >= +0.002 over its single model and >= +0.002 over its fused TTA'


def load(d):
    """-> spec, images (each: raw = per view (boxes, scores, labels, q) with score >= THR, GT in the original
    frame)."""
    spec, files = ppspec.for_cache(d)
    spec.need_pairs()
    views = [pickle.load(open(os.path.join(d, f), 'rb')) for f in files]
    ids = [r['img_id'] for r in views[0]]
    for v in views[1:]:
        if [r['img_id'] for r in v] != ids:
            raise RuntimeError('image order differs between views')
    imgs = []
    for i, r0 in enumerate(views[0]):
        g = ppspec.gt_to_orig(r0['gt_boxes'], r0['scale_factor'])
        raw = []
        for v in views:
            r = v[i]
            s = np.asarray(r['scores'], np.float32).reshape(-1)
            k = s >= THR
            raw.append((np.asarray(r['boxes'], np.float32).reshape(-1, 5)[k], s[k],
                        np.asarray(r['labels'], np.int64).reshape(-1)[k],
                        np.asarray(r['clf'], np.float32).reshape(-1, spec.out)[k]))
        imgs.append(dict(img_id=str(r0['img_id']), raw=raw, gt_boxes=g,
                         gt_labels=np.asarray(r0['gt_labels'], np.int64).reshape(-1)))
    return spec, imgs


def modify(b, s, l, q, setting, spec):
    if setting is None:
        return b, s, l
    factor, lam, dup = setting
    i = np.where(q[:, 0] >= 0)[0]
    if not len(i):
        return b, s, l
    n = np.arange(len(i))
    k = np.searchsorted(spec.pair, l[i])
    qq = np.clip(q[i], 1e-6, 1.0)
    f = qq[n, k] if factor == 'own' else np.clip(1 - qq[:, spec.bg], 1e-6, 1.0)
    base = np.power(s[i], 1 - lam)
    s2 = s.copy()
    s2[i] = base * np.power(f, lam)
    if not dup:
        return b, s2, l
    o = qq[:, :len(spec.pair)].copy()
    o[n, k] = -1
    j = o.argmax(1)
    better = o[n, j] > qq[n, k]
    if not better.any():
        return b, s2, l
    ii, jj = i[better], j[better]
    return (np.concatenate([b, b[ii]]),
            np.concatenate([s2, (base[better] * np.power(qq[better, jj], lam)).astype(np.float32)]),
            np.concatenate([l, spec.pair[jj]]))


def run(imgs, idx, setting, dev, nproc, spec, plain=False):
    sub, one, four, flat = [], [], [], []
    for k in idx:
        img = imgs[k]
        d = dict(views=[modify(*v, setting, spec) for v in img['raw']], gt_boxes=img['gt_boxes'],
                 gt_labels=img['gt_labels'])
        sub.append(d)
        one.append(TF.fuse(TF.cluster_image(d, 1, 0.0, dev), 1, 1.0, 'leader', None, dev))
        n = len(d['views'])
        c = TF.cluster_image(d, n, 0.0, dev)
        four.append(TF.fuse(c, n, 0.5, 'wavg', None, dev))
        if plain:
            flat.append(TF.fuse(c, n, 1.0, 'leader', None, dev))
    r = (TF.evaluate(sub, one, nproc, spec.k), TF.evaluate(sub, four, nproc, spec.k))
    return r + (TF.evaluate(sub, flat, nproc, spec.k),) if plain else r


def key(g):
    return '%s_lam%.2f_%s' % (g[0], g[1], 'dup' if g[2] else 'nodup')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['grid', 'final', 'apply', 'report'])
    ap.add_argument('--cache')
    ap.add_argument('--tag')
    ap.add_argument('--grids', nargs='+')
    ap.add_argument('--final')
    ap.add_argument('--which', choices=['base', 'best'])
    ap.add_argument('--base')
    ap.add_argument('--best')
    ap.add_argument('--out')
    ap.add_argument('--nproc', type=int, default=32)
    a = ap.parse_args()
    dev = 'cuda' if torch.cuda.is_available() else 'cpu'
    t0 = time.time()
    if a.mode == 'report':
        b, s = json.load(open(a.base)), json.load(open(a.best))
        spec = ppspec.get(s.get('dataset', 'soda'))
        print('TEST %s %s: single %.4f -> %.4f (%+.4f)  fused %.4f -> %.4f (%+.4f)' % (
            s['tag'], key(s['setting']), b['single'][0], s['single'][0], s['single'][0] - b['single'][0],
            b['fused'][0], s['fused'][0], s['fused'][0] - b['fused'][0]), flush=True)
        print('TEST %s fused per class: %s' % (s['tag'], ' '.join(
            '%s %+.4f' % (n, y - x) for n, x, y in zip(spec.short, b['fused'][1], s['fused'][1]))), flush=True)
        if 'plain' in b and 'plain' in s:
            print('TEST %s plain TTA (alpha 1, NMS merge) %.4f -> %.4f (%+.4f)' % (
                s['tag'], b['plain'][0], s['plain'][0], s['plain'][0] - b['plain'][0]), flush=True)
        return
    if a.mode == 'apply':
        setting = None if a.which == 'base' else tuple(json.load(open(a.final))['best'])
        print('NOTE setting %s was picked on val half A; nothing is chosen here' % (setting,), flush=True)
        spec, imgs = load(a.cache)
        print('%s: %s, %d images (%.0fs)' % (a.tag, spec.name, len(imgs), time.time() - t0), flush=True)
        sv, fu, pl = run(imgs, range(len(imgs)), setting, dev, a.nproc, spec, plain=True)
        out = dict(tag=a.tag, cache=a.cache, which=a.which, setting=setting and list(setting), single=sv, fused=fu,
                   plain=pl)
        if spec.name != 'soda':
            out['dataset'] = spec.name
        json.dump(out, open(a.out, 'w'), indent=1)
        print('APPLY %s %s single=%.4f fused=%.4f plain=%.4f (%.0fs)' % (a.tag, a.which, sv[0], fu[0], pl[0],
                                                                       time.time() - t0), flush=True)
        return
    print('RULE ' + RULE, flush=True)
    if a.mode == 'grid':
        spec, imgs = load(a.cache)
        A, Bh = TF.split_ids(imgs, spec.group)
        print('%s: %s, %d images, split %d / %d (%.0fs)' % (a.tag, spec.name, len(imgs), len(A), len(Bh),
                                                           time.time() - t0), flush=True)
        res = dict(tag=a.tag, cache=a.cache, ids=[i['img_id'] for i in imgs], baseline={}, A={})
        if spec.name != 'soda':
            res['dataset'] = spec.name
        for name, idx in (('A', A), ('B', Bh)):
            sv, fu = run(imgs, idx, None, dev, a.nproc, spec)
            res['baseline'][name] = dict(single=sv, fused=fu)
            print('%s %s baseline single=%.4f fused=%.4f (%.0fs)' % (a.tag, name, sv[0], fu[0], time.time() - t0),
                  flush=True)
        for g in GRID:
            sv, fu = run(imgs, A, g, dev, a.nproc, spec)
            res['A'][key(g)] = dict(single=sv, fused=fu)
            print('  A %s %s single %+.4f fused %+.4f (%.0fs)' % (
                a.tag, g, sv[0] - res['baseline']['A']['single'][0], fu[0] - res['baseline']['A']['fused'][0],
                time.time() - t0), flush=True)
        json.dump(res, open(a.out, 'w'), indent=1)
        print('PAIRCLF_GRID_DONE %s (%.0fs)' % (a.tag, time.time() - t0), flush=True)
        return
    grids = [json.load(open(f)) for f in a.grids]
    # same image set; the order may differ between hosts (DOTADataset lists the annfiles with an unsorted glob)
    if any(sorted(g['ids']) != sorted(grids[0]['ids']) for g in grids):
        raise RuntimeError('models were cached on different images')
    if len({g.get('dataset', 'soda') for g in grids}) != 1:
        raise RuntimeError('grids of different datasets')
    crit = {}
    for g in GRID:
        crit[g] = float(np.mean([min(r['A'][key(g)]['single'][0] - r['baseline']['A']['single'][0],
                                     r['A'][key(g)]['fused'][0] - r['baseline']['A']['fused'][0]) for r in grids]))
        print('  A %s mean of min gains %+.4f' % (g, crit[g]), flush=True)
    best = max(GRID, key=lambda g: crit[g])
    print('A-best %s (%+.4f)' % (best, crit[best]), flush=True)
    res = dict(rule=RULE, best=list(best), A_criterion={key(g): v for g, v in crit.items()}, B={})
    if grids[0].get('dataset', 'soda') != 'soda':
        res['dataset'] = grids[0]['dataset']
    ok = True
    for r in grids:
        spec, imgs = load(r['cache'])
        A, Bh = TF.split_ids(imgs, spec.group)
        sv, fu = run(imgs, Bh, best, dev, a.nproc, spec)
        b0 = r['baseline']['B']
        ds, df = round(sv[0] - b0['single'][0], 4), round(fu[0] - b0['fused'][0], 4)
        ok = ok and ds >= 0.002 and df >= 0.002
        res['B'][r['tag']] = dict(single=sv, fused=fu, gain_single=ds, gain_fused=df, baseline=b0)
        print('B %s single %.4f -> %.4f (%+.4f)  fused %.4f -> %.4f (%+.4f)' % (
            r['tag'], b0['single'][0], sv[0], ds, b0['fused'][0], fu[0], df), flush=True)
        print('B %s per-class AP fused baseline %s' % (r['tag'], b0['fused'][1]), flush=True)
        print('B %s per-class AP fused best     %s' % (r['tag'], fu[1]), flush=True)
    res['adopt'] = bool(ok)
    json.dump(res, open(a.out, 'w'), indent=1)
    print('PAIRCLF_SCREEN_DONE adopt=%s (%.0fs)' % (ok, time.time() - t0), flush=True)


if __name__ == '__main__':
    main()
