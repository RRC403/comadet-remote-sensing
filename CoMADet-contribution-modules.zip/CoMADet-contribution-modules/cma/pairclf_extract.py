#!/usr/bin/env python
"""Training data for the pair-class re-classifier, any dataset with a ppspec entry (2026-11-02).

  python pairclf_extract.py CONFIG CKPT --out DIR [--stride 2] [--limit N]

Generalized copy of ../pairclf_extract.py (same output on SODA-A).  Runs the frozen detector on the train
split with the test pipeline (no augmentation) and the combo test_cfg (NMS 0.4, 4000 / 4000, score >= 0.05).
For every detection of a pair class it stores the two RoI features of pairclf_common (float16), the
scalars, the target and a sampling weight:
  target  the pair class of the max-IoU GT if IoU >= 0.5; background if the max IoU < 0.3 or the matched GT
          is not a pair class; boxes with max IoU in [0.3, 0.5) are not stored
  kept    every confusion (target is another pair class) and every box whose target is the rarest pair
          class (spec.rare); the rest at most CAP per (predicted class, target) per image (4 x CAP for boxes
          predicted as the rarest class), weight n / CAP
Every STRIDE-th image is used.  Batch size: 4 on SODA-A (as before), otherwise the config's test batch size
(mixed image sizes would be padded).  Output: DIR/shard_XXX.npz and DIR/meta.json (with the dataset name).
"""
import argparse
import json
import os
import os.path as osp
import sys
import time

import numpy as np
import torch
from mmcv.ops import box_iou_rotated
from mmengine.registry import DATASETS, init_default_scope
from torch.utils.data import DataLoader, Subset

sys.path.insert(0, osp.dirname(osp.abspath(__file__)))
import pairclf_common as PC  # noqa: E402

CAP = 4
SHARD = 2000


def label_boxes(b, lab, gt, gl, spec):
    """b: pair-class boxes [N, 5] (original frame, cuda); gt [M, 5] original frame -> pred index k, target t."""
    if len(gt):
        iou = box_iou_rotated(b, gt, aligned=False, clockwise=True).cpu().numpy()
        mx, gcls = iou.max(1), gl[iou.argmax(1)]
    else:
        mx, gcls = np.zeros(len(b)), np.full(len(b), -1)
    k = np.searchsorted(spec.pair, lab)
    t = np.full(len(b), -1)
    pos = (mx >= 0.5) & np.isin(gcls, spec.pair)
    t[pos] = np.searchsorted(spec.pair, gcls[pos])
    t[(mx < 0.3) | ((mx >= 0.5) & ~np.isin(gcls, spec.pair))] = spec.bg
    return k, t


def subsample(k, t, rng, spec):
    """Keep every confusion and every rare-class target; cap the rest per (predicted, target) cell
    (4x the cap for boxes predicted as the rare class)."""
    ok = t >= 0
    must = ok & (((t != k) & (t != spec.bg)) | (t == spec.rare))
    keep, w = must.copy(), np.ones(len(t), np.float32)
    for kk in range(len(spec.pair)):
        cap = CAP * 4 if kk == spec.rare else CAP
        for tt in range(spec.out):
            sel = np.where(ok & ~must & (k == kk) & (t == tt))[0]
            if len(sel) > cap:
                w[sel] = len(sel) / cap
                sel = rng.choice(sel, cap, replace=False)
            keep[sel] = True
    return keep, w


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('config')
    ap.add_argument('checkpoint')
    ap.add_argument('--out', required=True)
    ap.add_argument('--stride', type=int, default=2)
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--batch-size', type=int, default=0)
    ap.add_argument('--num-workers', type=int, default=4)
    a = ap.parse_args()
    init_default_scope('mmrotate')
    cfg, model, feats, spec = PC.build_detector(a.config, a.checkpoint, 'train', 0.05)
    spec.need_pairs()
    bs = a.batch_size or (4 if spec.name == 'soda' else int(cfg.test_dataloader.get('batch_size', 1)))
    roi = PC.RoIFeats()
    ds = DATASETS.build(PC.view_dl_cfg(cfg, spec.views[0])['dataset'])
    idx = list(range(0, len(ds), a.stride))[:a.limit or None]
    os.makedirs(a.out, exist_ok=True)
    loader = DataLoader(Subset(ds, idx), batch_size=bs, shuffle=False, num_workers=a.num_workers,
                        collate_fn=PC.TR.default_collate)
    rng = np.random.RandomState(0)
    P = len(spec.pair)
    buf = {n: [] for n in ('fb', 'fc', 's', 'y', 'w', 'k', 'img')}
    stats, kept = np.zeros((P, spec.out), np.int64), np.zeros((P, spec.out), np.int64)
    orig, shard, tiles, t0 = {}, 0, 0, time.time()
    print('START %s %s train images %d of %d, pair classes %s' % (
        spec.name, a.checkpoint, len(idx), len(ds), list(spec.pair_names)), flush=True)

    def flush():
        nonlocal shard
        if buf['y']:
            np.savez(osp.join(a.out, 'shard_%03d.npz' % shard), **{n: np.concatenate(v) for n, v in buf.items()})
            shard += 1
            for v in buf.values():
                v.clear()

    for bi, data in enumerate(loader):
        with torch.no_grad():
            samples = model.test_step(data)
            x = feats.pop('x')
            rois, meta = [], []
            for j, s in enumerate(samples):
                tiles += 1
                sf = PC.scale_xy(s)
                p = s.pred_instances
                lab, sc = p.labels.cpu().numpy(), p.scores.cpu().numpy()
                m = np.isin(lab, spec.pair)
                if not m.any():
                    continue
                b = PC.tensor_of(p.bboxes)[torch.from_numpy(m).to(p.labels.device)].float()
                lab, sc = lab[m], sc[m]
                gt = PC.to_orig(PC.tensor_of(s.gt_instances.bboxes).float().to(b.device), sf)
                k, t = label_boxes(b, lab, gt, s.gt_instances.labels.cpu().numpy(), spec)
                np.add.at(stats, (k[t >= 0], t[t >= 0]), 1)
                keep, w = subsample(k, t, rng, spec)
                if not keep.any():
                    continue
                np.add.at(kept, (k[keep], t[keep]), 1)
                bk = b[torch.from_numpy(keep).to(b.device)]
                r = PC.to_resized(bk, sf)
                rois.append(torch.cat([r.new_full((len(r), 1), j), r], 1))
                o = orig.setdefault(spec.orig(s.metainfo['img_id']), len(orig))
                meta.append((PC.scalars(bk.cpu().numpy(), sc[keep], lab[keep], spec), t[keep], w[keep], k[keep], o))
            if rois:
                fb, fc = roi(x, torch.cat(rois))
                fb, fc = fb.half().cpu().numpy(), fc.half().cpu().numpy()
                off = 0
                for sca, tt, ww, kk, o in meta:
                    n = len(tt)
                    for name, v in (('fb', fb[off:off + n]), ('fc', fc[off:off + n]), ('s', sca),
                                    ('y', tt.astype(np.int8)), ('w', ww), ('k', kk.astype(np.int8)),
                                    ('img', np.full(n, o, np.int32))):
                        buf[name].append(v)
                    off += n
        if tiles >= (shard + 1) * SHARD:
            flush()
        if bi % 250 == 0:
            print('  batch %d images %d stored %d (%.0fs)' % (bi, tiles, int(kept.sum()), time.time() - t0),
                  flush=True)
    flush()
    meta = dict(dataset=spec.name, pair=spec.pair.tolist(), config=osp.realpath(a.config),
                checkpoint=osp.realpath(a.checkpoint), stride=a.stride, cap=CAP, tiles=tiles, shards=shard,
                orig_images=len(orig), stats=stats.tolist(), kept=kept.tolist())
    json.dump(meta, open(osp.join(a.out, 'meta.json'), 'w'), indent=1)
    print('targets before subsampling (rows: predicted %s; cols: those and bg):\n%s'
          % ('/'.join(spec.pair_names), stats), flush=True)
    print('PAIRCLF_EXTRACT_DONE images %d stored %d shards %d (%.0fs)' % (tiles, int(kept.sum()), shard,
                                                                       time.time() - t0), flush=True)


if __name__ == '__main__':
    main()
