"""Cross-view box fusion for rotation TTA (eval only).

  python tta_fusion_eval.py screen --caches TAG=DIR [TAG=DIR ...] --out OUT.json
  python tta_fusion_eval.py reproduce --caches TAG=DIR --out OUT.json
  python tta_fusion_eval.py apply --caches TAG=DIR [...] --alpha A --box B [--vote L] --out OUT.json

Each DIR is a tta_rotated.py cache directory with angle_{0,90,180,270}.pkl:
per-view predictions mapped back to the tile frame (per-view NMS 0.4, nms_pre and
max_per_img 4000), GT of the 0-degree view in the resized frame (divided by
scale_factor here, as DOTAMetric does).

Plain rotation TTA (tta_rotated.py) merges the views with per-class NMS: each
cluster keeps its highest-scoring box unchanged and the other views' evidence is
dropped.  Fusion keeps exactly the same clusters (the NMS keep set are the
leaders; every suppressed box joins the first kept box that suppressed it) and
changes only
  score  alpha * max + (1 - alpha) * (sum over views of that view's best score) / V
  box    the leader, or the score-weighted mean of the members (width, height and
         angle aligned to the leader's representation first)
  vote   optional: leaders of two classes that form a CMM pair (FIXED4) and
         overlap (IoU > 0.5) are resolved by cross-view support: the weaker
         one's score is multiplied by L.
alpha = 1 with box = leader is plain TTA, so the baseline uses the same code.

screen: images are split 50/50 by original SODA-A image (all tiles of one image
fall in the same half, seed 0).  The fusion grid is ranked on half A by the mean
gain over plain TTA across all given models; the A-best setting is reported on
half B.  Pre-registered rule, checked on B for the view threshold 0.05: adopt if
the A-best setting beats plain TTA by >= +0.002 on the QFL model (tag
containing 'PQ').
Library use (pp/, 2026-11-02): fuse / evaluate / split_ids take the class count, the CMM pairs and the
image-group separator of another dataset; the defaults are SODA-A's (K = 9, FIXED4, '__').
reproduce: plain single-view and plain 4-view TTA only (to check this evaluator
against tta_rotated.py on caches whose numbers are already known).
"""
import argparse
import collections
import json
import os
import pickle
import time

import numpy as np
import torch
from mmcv.ops import box_iou_rotated, nms_rotated
from mmrotate.evaluation.functional import eval_rbbox_map

ANGLES = (0, 90, 180, 270)
K = 9
FIXED4 = [(3, 5), (2, 3), (2, 5), (3, 4)]
MAX_PER_IMG = 4000
NMS_IOU = 0.4


def load_cache(d, angles=ANGLES):
    views = []
    for a in angles:
        with open(os.path.join(d, 'angle_%d.pkl' % a), 'rb') as f:
            views.append(pickle.load(f))
    ids = [r['img_id'] for r in views[0]]
    for a, v in zip(angles, views):
        if [r['img_id'] for r in v] != ids:
            raise RuntimeError('%s: image order of angle %d differs from angle %d' % (d, a, angles[0]))
    imgs = []
    for i, r0 in enumerate(views[0]):
        sf = np.asarray(r0['scale_factor'], np.float32).reshape(-1)[:2]
        if abs(float(sf[0]) - float(sf[1])) > 1e-6:
            raise RuntimeError('non-uniform scale factor %s' % sf)
        g = np.asarray(r0['gt_boxes'], np.float32).reshape(-1, 5).copy()
        g[:, :4] /= sf[0]
        per_view = []
        for v in views:
            r = v[i]
            per_view.append((np.asarray(r['boxes'], np.float32).reshape(-1, 5),
                             np.asarray(r['scores'], np.float32).reshape(-1),
                             np.asarray(r['labels'], np.int64).reshape(-1)))
        imgs.append(dict(img_id=str(r0['img_id']), views=per_view, gt_boxes=g,
                         gt_labels=np.asarray(r0['gt_labels'], np.int64).reshape(-1)))
    return imgs


def wrap(d):
    return (d + np.pi / 2) % np.pi - np.pi / 2


def cluster_image(img, n_views, thr, dev):
    """Per-class NMS clusters over the first n_views views (score >= thr)."""
    bs, ss, ls, vs = [], [], [], []
    for v in range(n_views):
        b, s, l = img['views'][v]
        k = s >= thr
        bs.append(b[k]); ss.append(s[k]); ls.append(l[k]); vs.append(np.full(int(k.sum()), v))
    B, S, L, V = (np.concatenate(x) for x in (bs, ss, ls, vs))
    lead = np.full(len(S), -1, np.int64)
    unmatched = 0
    for c in np.unique(L):
        idx = np.where(L == c)[0]
        b = torch.from_numpy(B[idx]).to(dev)
        s = torch.from_numpy(S[idx]).to(dev)
        _, keep = nms_rotated(b, s, NMS_IOU)
        keep = keep.cpu().numpy()
        keep = keep[np.argsort(-S[idx][keep], kind='stable')]
        if len(idx) == len(keep):
            lead[idx] = idx
            continue
        iou = box_iou_rotated(b, b[torch.from_numpy(keep).to(dev)], aligned=False,
                              clockwise=True).cpu().numpy()
        hit = iou > NMS_IOU
        first = hit.argmax(1)
        ok = hit[np.arange(len(idx)), first]
        lead[idx[ok]] = idx[keep[first[ok]]]
        lead[idx[keep]] = idx[keep]
        unmatched += int((~ok).sum() - (~ok[keep]).sum())
    return dict(B=B, S=S, L=L, V=V, lead=lead, unmatched=unmatched)


def fuse(cl, n_views, alpha, box, vote, dev, pairs=FIXED4, n_cls=K):
    B, S, L, V, lead = cl['B'], cl['S'], cl['L'], cl['V'], cl['lead']
    m = lead >= 0
    leaders = np.unique(lead[m])
    if len(leaders) == 0:
        return np.zeros((0, 5), np.float32), np.zeros(0, np.float32), np.zeros(0, np.int64)
    pos = np.searchsorted(leaders, lead[m])
    best = np.zeros((len(leaders), n_views), np.float32)
    np.maximum.at(best, (pos, V[m]), S[m])
    score = alpha * S[leaders] + (1 - alpha) * best.sum(1) / n_views
    out_b = B[leaders].copy()
    if box == 'wavg':
        mb, w = B[m], S[m].astype(np.float64)
        lb = B[leaders][pos]
        d1 = wrap(mb[:, 4] - lb[:, 4])
        d2 = wrap(mb[:, 4] + np.pi / 2 - lb[:, 4])
        sw = np.abs(d2) < np.abs(d1)
        mw = np.where(sw, mb[:, 3], mb[:, 2])
        mh = np.where(sw, mb[:, 2], mb[:, 3])
        dd = np.where(sw, d2, d1)
        tot = np.bincount(pos, w, len(leaders))
        for j, val in ((0, mb[:, 0]), (1, mb[:, 1]), (2, mw), (3, mh)):
            out_b[:, j] = np.bincount(pos, w * val, len(leaders)) / tot
        out_b[:, 4] = B[leaders, 4] + np.bincount(pos, w * dd, len(leaders)) / tot
    out_l = L[leaders].copy()
    if vote is not None:
        support = best.sum(1) / n_views
        allowed = np.zeros((n_cls, n_cls), bool)
        for a, b in pairs:
            allowed[a, b] = allowed[b, a] = True
        cand = np.where(np.isin(out_l, [c for p in pairs for c in p]))[0]
        if len(cand) > 1:
            t = torch.from_numpy(out_b[cand].astype(np.float32)).to(dev)
            iou = box_iou_rotated(t, t, aligned=False, clockwise=True).cpu().numpy()
            np.fill_diagonal(iou, 0)
            ii, jj = np.nonzero((iou > 0.5) & allowed[out_l[cand][:, None], out_l[cand][None, :]])
            k = ii < jj
            ii, jj = cand[ii[k]], cand[jj[k]]
            up = support[ii] >= support[jj]
            hi, lo = np.where(up, ii, jj), np.where(up, jj, ii)
            dead = np.zeros(len(score), bool)
            for c in np.argsort(-support[hi], kind='stable'):
                if dead[hi[c]] or dead[lo[c]]:
                    continue
                score[lo[c]] *= vote
                dead[lo[c]] = True
    order = np.argsort(-score, kind='stable')[:MAX_PER_IMG]
    return out_b[order].astype(np.float32), score[order].astype(np.float32), out_l[order]


def evaluate(imgs, outs, nproc, n_cls=K):
    dets, anns = [], []
    for img, (b, s, l) in zip(imgs, outs):
        dets.append([np.hstack([b[l == c], s[l == c, None]]).astype(np.float32)
                     if (l == c).any() else np.zeros((0, 6), np.float32) for c in range(n_cls)])
        anns.append(dict(bboxes=img['gt_boxes'], labels=img['gt_labels'],
                         bboxes_ignore=np.zeros((0, 5), np.float32),
                         labels_ignore=np.zeros((0, ), np.int64)))
    m, res = eval_rbbox_map(dets, anns, iou_thr=0.5, use_07_metric=True, box_type='rbox',
                            nproc=nproc, logger='silent')
    return round(float(m), 4), [round(float(x['ap']), 4) for x in res]


def split_ids(imgs, sep='__'):
    orig = sorted({i['img_id'].split(sep)[0] for i in imgs})
    rng = np.random.RandomState(0)
    a = set(np.asarray(orig)[rng.permutation(len(orig))[:len(orig) // 2]].tolist())
    A = [k for k, i in enumerate(imgs) if i['img_id'].split(sep)[0] in a]
    Bh = [k for k, i in enumerate(imgs) if i['img_id'].split(sep)[0] not in a]
    return A, Bh


GRID = [(1.0, 'leader'), (1.0, 'wavg'), (0.5, 'leader'), (0.5, 'wavg'),
        (0.0, 'leader'), (0.0, 'wavg')]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['screen', 'reproduce', 'apply'])
    ap.add_argument('--caches', nargs='+', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--thr', type=float, nargs='+', default=[0.05, 0.01])
    ap.add_argument('--alpha', type=float)
    ap.add_argument('--box')
    ap.add_argument('--vote', type=float)
    ap.add_argument('--nproc', type=int, default=24)
    a = ap.parse_args()
    dev = 'cuda' if torch.cuda.is_available() else 'cpu'
    t0 = time.time()
    models = collections.OrderedDict(x.split('=', 1) for x in a.caches)
    data = {t: load_cache(d) for t, d in models.items()}
    for t, imgs in data.items():
        print('%s: %d images, boxes per view %s (%.0fs)' % (
            t, len(imgs), [int(np.mean([len(i['views'][v][1]) for i in imgs])) for v in range(4)],
            time.time() - t0), flush=True)
    res = dict(mode=a.mode, caches=dict(models), fixed_pairs=FIXED4, grid=GRID, results={})

    if a.mode == 'reproduce':
        for t, imgs in data.items():
            r = {}
            cl1 = [cluster_image(i, 1, 0.05, dev) for i in imgs]
            r['single_view'] = evaluate(imgs, [fuse(c, 1, 1.0, 'leader', None, dev) for c in cl1], a.nproc)
            cl4 = [cluster_image(i, 4, 0.05, dev) for i in imgs]
            r['plain_tta'] = evaluate(imgs, [fuse(c, 4, 1.0, 'leader', None, dev) for c in cl4], a.nproc)
            r['unmatched'] = int(sum(c['unmatched'] for c in cl4))
            res['results'][t] = r
            print('REPRODUCE %s single=%.4f plain4=%.4f unmatched=%d' % (
                t, r['single_view'][0], r['plain_tta'][0], r['unmatched']), flush=True)
        json.dump(res, open(a.out, 'w'), indent=1)
        return

    if a.mode == 'apply':
        for t, imgs in data.items():
            r = {}
            for thr in a.thr:
                cl1 = [cluster_image(i, 1, thr, dev) for i in imgs]
                cl4 = [cluster_image(i, 4, thr, dev) for i in imgs]
                r['thr%.2f' % thr] = dict(
                    single_view=evaluate(imgs, [fuse(c, 1, 1.0, 'leader', None, dev) for c in cl1], a.nproc),
                    plain_tta=evaluate(imgs, [fuse(c, 4, 1.0, 'leader', None, dev) for c in cl4], a.nproc),
                    fused=evaluate(imgs, [fuse(c, 4, a.alpha, a.box, None, dev) for c in cl4], a.nproc))
                if a.vote is not None:
                    r['thr%.2f' % thr]['fused_vote'] = evaluate(
                        imgs, [fuse(c, 4, a.alpha, a.box, a.vote, dev) for c in cl4], a.nproc)
                x = r['thr%.2f' % thr]
                print('APPLY %s thr=%.2f single=%.4f plain=%.4f fused(alpha=%s,box=%s)=%.4f vote(%s)=%s' % (
                    t, thr, x['single_view'][0], x['plain_tta'][0], a.alpha, a.box, x['fused'][0], a.vote,
                    x.get('fused_vote', [None])[0]), flush=True)
            res['results'][t] = r
        res.update(alpha=a.alpha, box=a.box, vote=a.vote)
        json.dump(res, open(a.out, 'w'), indent=1)
        return

    first = next(iter(data.values()))
    A, Bh = split_ids(first)
    for t, imgs in data.items():
        if [i['img_id'] for i in imgs] != [i['img_id'] for i in first]:
            raise RuntimeError('models were cached on different images')
    print('split: %d / %d tiles from %d original images' % (
        len(A), len(Bh), len({i['img_id'].split('__')[0] for i in first})), flush=True)
    for thr in a.thr:
        clusters = {}
        for t, imgs in data.items():
            clusters[t] = ([cluster_image(i, 1, thr, dev) for i in imgs],
                           [cluster_image(i, 4, thr, dev) for i in imgs])
        print('thr %.2f clustered (%.0fs)' % (thr, time.time() - t0), flush=True)
        block = {}
        for t, imgs in data.items():
            cl1, cl4 = clusters[t]
            row = {}
            for name, idx in (('A', A), ('B', Bh)):
                sub = [imgs[k] for k in idx]
                row[name] = dict(single_view=evaluate(sub, [fuse(cl1[k], 1, 1.0, 'leader', None, dev) for k in idx], a.nproc))
                for al, bx in GRID:
                    row[name]['a%.1f_%s' % (al, bx)] = evaluate(
                        sub, [fuse(cl4[k], 4, al, bx, None, dev) for k in idx], a.nproc)
                print('  %s thr=%.2f %s single=%.4f plain=%.4f %s' % (
                    t, thr, name, row[name]['single_view'][0], row[name]['a1.0_leader'][0],
                    {k: v[0] for k, v in row[name].items() if k not in ('single_view', 'a1.0_leader')}), flush=True)
            block[t] = row
        keys = ['a%.1f_%s' % g for g in GRID if g != (1.0, 'leader')]
        gain_a = {k: float(np.mean([block[t]['A'][k][0] - block[t]['A']['a1.0_leader'][0] for t in data])) for k in keys}
        best = max(keys, key=lambda k: gain_a[k])
        al, bx = float(best[1:4]), best.split('_', 1)[1]
        for t, imgs in data.items():
            cl4 = clusters[t][1]
            for name, idx in (('A', A), ('B', Bh)):
                sub = [imgs[k] for k in idx]
                block[t][name]['best_vote0.5'] = evaluate(sub, [fuse(cl4[k], 4, al, bx, 0.5, dev) for k in idx], a.nproc)
        summary = {t: dict(B_plain=block[t]['B']['a1.0_leader'][0], B_best=block[t]['B'][best][0],
                           B_gain=round(block[t]['B'][best][0] - block[t]['B']['a1.0_leader'][0], 4),
                           B_vote_gain=round(block[t]['B']['best_vote0.5'][0] - block[t]['B'][best][0], 4),
                           B_tta_gain=round(block[t]['B']['a1.0_leader'][0] - block[t]['B']['single_view'][0], 4))
                   for t in data}
        res['results']['thr%.2f' % thr] = dict(per_model=block, A_mean_gain=gain_a, A_best=best, summary=summary)
        print('thr %.2f A-best=%s summary=%s' % (thr, best, summary), flush=True)
    pq = [t for t in data if 'PQ' in t]
    s05 = res['results'].get('thr0.05', {}).get('summary', {})
    adopt = bool(pq) and all(s05.get(t, {}).get('B_gain', -1) >= 0.002 for t in pq)
    res['adopt'] = adopt
    json.dump(res, open(a.out, 'w'), indent=1)
    print('SCREEN_DONE adopt=%s (%.0fs)' % (adopt, time.time() - t0))


if __name__ == '__main__':
    main()
