#!/usr/bin/env python
"""TTA cache with the pair-class re-classifier's probabilities per box, any dataset (2026-11-02, eval only).

  python pairclf_cache.py CONFIG CKPT CLF.pth --cache-dir DIR [--split val|test] [--max-images 8000]
         [--limit K] [--score-thr 0.01] [--batch-size B]

Generalized copy of ../pairclf_cache.py (same files on SODA-A).  The views are the dataset's (ppspec):
SODA-A / FAIR1M the four rotations (angle_{0,90,180,270}.pkl, as tta_rotated.py), VisDrone the four flips
(flip_{none,h,v,d}.pkl).  Every box of a pair class gets clf = the re-classifier's softmax over the pair
classes and background (averaged over the 8 grid symmetries); boxes of other classes get -1.  Boxes are
mapped back to the original image; the first view also stores the GT (resized frame) and the scale factor.
--split names the folder under data_root (VisDrone: test = test-dev).  Batch size: 4 on SODA-A (all tiles
are 1024 x 1024), otherwise the config's test batch size, since mixed image sizes in a batch are padded and
would make the numbers differ from tools/test.py.  clf_meta.json records the dataset and the view files.
CLF = none (2026-11-03): no re-classifier, every box gets clf = -1; the cache then serves plain / fused TTA
(pairclf_screen.py apply --which base, pairclf_ens.py --which base) of a model without one, e.g. SCENet.
"""
import argparse
import json
import os
import os.path as osp
import pickle
import sys
import time

import numpy as np
import torch
from mmengine.registry import DATASETS, init_default_scope
from torch.utils.data import DataLoader, Subset

sys.path.insert(0, osp.dirname(osp.abspath(__file__)))
import pairclf_common as PC  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('config')
    ap.add_argument('checkpoint')
    ap.add_argument('clf')
    ap.add_argument('--cache-dir', required=True)
    ap.add_argument('--split', default='val', choices=['val', 'test'])
    ap.add_argument('--max-images', type=int, default=8000)
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--score-thr', type=float, default=0.01)
    ap.add_argument('--batch-size', type=int, default=0)
    ap.add_argument('--num-workers', type=int, default=4)
    a = ap.parse_args()
    init_default_scope('mmrotate')
    cfg, model, feats, spec = PC.build_detector(a.config, a.checkpoint, a.split, a.score_thr)
    if a.clf != 'none':
        spec.need_pairs()
    bs = a.batch_size or (4 if spec.name == 'soda' else int(cfg.test_dataloader.get('batch_size', 1)))
    roi = PC.RoIFeats()
    ck, clf = {}, None
    if a.clf != 'none':
        ck = torch.load(a.clf, map_location='cpu')
        if ck.get('dataset', 'soda') != spec.name or list(ck.get('pair', [2, 3, 4, 5])) != spec.pair.tolist():
            sys.exit('%s was trained for %s %s, not %s %s' % (a.clf, ck.get('dataset', 'soda'), ck.get('pair'),
                                                            spec.name, spec.pair.tolist()))
        clf = PC.PairReclassifier(n_scalar=spec.n_scalar, out=spec.out).cuda().eval()
        clf.load_state_dict(ck['state_dict'])
    os.makedirs(a.cache_dir, exist_ok=True)
    n_total = len(DATASETS.build(PC.view_dl_cfg(cfg, spec.views[0])['dataset']))
    idx = PC.TR.pick_indices(n_total, a.max_images, 'stride')
    idx = list(range(n_total)) if idx is None else idx
    if a.limit:
        idx = idx[:a.limit]
    meta = dict(config=osp.realpath(a.config), checkpoint=osp.realpath(a.checkpoint),
                clf=a.clf if clf is None else osp.realpath(a.clf),
                clf_epoch=ck.get('epoch'), split=a.split, n_total=n_total, n_used=len(idx),
                max_images=a.max_images, limit=a.limit, score_thr=a.score_thr)
    if spec.name != 'soda':  # SODA-A keeps the old meta, so old and new caches compare equal
        meta.update(dataset=spec.name, views=list(spec.view_files), batch_size=bs)
    mf = osp.join(a.cache_dir, 'clf_meta.json')
    if osp.exists(mf) and json.load(open(mf)) != meta:
        sys.exit('cache dir %s belongs to another run' % a.cache_dir)
    json.dump(meta, open(mf, 'w'), indent=1)
    print('START %s %s + %s split=%s images %d of %d, views %s, batch %d' % (
        spec.name, a.checkpoint, a.clf, a.split, len(idx), n_total, list(spec.view_files), bs), flush=True)
    for vi, (view, vf) in enumerate(zip(spec.views, spec.view_files)):
        f = osp.join(a.cache_dir, vf)
        if osp.exists(f):
            print('%s cached, skipped' % vf, flush=True)
            continue
        ds = Subset(DATASETS.build(PC.view_dl_cfg(cfg, view)['dataset']), idx)
        loader = DataLoader(ds, batch_size=bs, shuffle=False, num_workers=a.num_workers,
                            collate_fn=PC.TR.default_collate)
        recs, t0 = [], time.time()
        for bi, data in enumerate(loader):
            with torch.no_grad():
                samples = model.test_step(data)
                x = feats.pop('x')
                rois, sel, sca = [], [], []
                for j, s in enumerate(samples):
                    sf = PC.scale_xy(s)
                    p = s.pred_instances
                    lab, sc = p.labels.cpu().numpy(), p.scores.cpu().numpy()
                    m = np.isin(lab, spec.pair) if clf is not None else np.zeros(len(lab), bool)
                    sel.append(m)
                    if m.any():
                        b = PC.tensor_of(p.bboxes)[torch.from_numpy(m).to(p.labels.device)].float()
                        sca.append(PC.scalars(b.cpu().numpy(), sc[m], lab[m], spec))
                        r = PC.to_resized(b, sf)
                        rois.append(torch.cat([r.new_full((len(r), 1), j), r], 1))
                probs = np.zeros((0, spec.out), np.float32)
                if rois:
                    fb, fc = roi(x, torch.cat(rois))
                    probs = PC.predict_probs(clf, fb, fc, torch.from_numpy(np.concatenate(sca)).cuda()).cpu().numpy()
            off = 0
            for j, s in enumerate(samples):
                h, w = s.metainfo['ori_shape'][:2]
                pred = s.pred_instances
                m = sel[j]
                q = np.full((len(m), spec.out), -1, np.float16)
                q[m] = probs[off:off + int(m.sum())].astype(np.float16)
                off += int(m.sum())
                rec = dict(img_id=str(s.metainfo['img_id']), ori_shape=(int(h), int(w)),
                           boxes=PC.unview_boxes(PC.TR.boxes_to_numpy(pred.bboxes), view, h, w),
                           scores=np.asarray(pred.scores.detach().cpu().numpy(), np.float32).reshape(-1),
                           labels=np.asarray(pred.labels.detach().cpu().numpy(), np.int64).reshape(-1), clf=q)
                if vi == 0:
                    rec['gt_boxes'] = PC.TR.boxes_to_numpy(s.gt_instances.bboxes)
                    rec['gt_labels'] = np.asarray(s.gt_instances.labels.detach().cpu().numpy(), np.int64).reshape(-1)
                    rec['scale_factor'] = tuple(float(v) for v in np.asarray(s.metainfo['scale_factor']).reshape(-1)[:2])
                recs.append(rec)
            if bi % 200 == 0:
                print('  %s batch %d images %d %.0fs' % (vf, bi, len(recs), time.time() - t0), flush=True)
        tmp = f + '.part'
        with open(tmp, 'wb') as fh:
            pickle.dump(recs, fh, protocol=4)
        os.replace(tmp, f)
        print('%s done: %d images, %.0fs' % (vf, len(recs), time.time() - t0), flush=True)
    print('PAIRCLF_CACHE_DONE', flush=True)


if __name__ == '__main__':
    main()
