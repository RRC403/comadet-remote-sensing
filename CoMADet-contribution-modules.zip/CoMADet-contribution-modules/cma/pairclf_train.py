#!/usr/bin/env python
"""Train the pair-class re-classifier on the shards of pairclf_extract.py, any dataset (2026-11-02).

  python pairclf_train.py DATA_DIR --out CLF.pth [--epochs 8]

10% of the original images are held out to pick the epoch (lowest held-out loss).  The loss is
cross-entropy weighted by sqrt(w): w restores the per-tile counts removed by subsampling, and the square
root keeps dense small-vehicle tiles from dominating.  Generalized copy of ../pairclf_train.py (same result
on SODA-A): the pair classes come from DATA_DIR/meta.json ('dataset', SODA-A if absent), and the
checkpoint records them so pairclf_cache.py can check it was given the matching classifier.
"""
import argparse
import glob
import json
import os.path as osp
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, osp.dirname(osp.abspath(__file__)))
import pairclf_common as PC  # noqa: E402
import ppspec  # noqa: E402


def load(d):
    parts = {n: [] for n in ('fb', 'fc', 's', 'y', 'w', 'k', 'img')}
    for f in sorted(glob.glob(osp.join(d, 'shard_*.npz'))):
        z = np.load(f)
        for n in parts:
            parts[n].append(z[n])
    return {n: np.concatenate(v) for n, v in parts.items()}


def chan_stats(a, idx):
    x = a[idx].astype(np.float32)
    return x.mean((0, 2, 3)), x.std((0, 2, 3)) + 1e-3


def run(model, D, idx, dev, bs=2048, opt=None, sched=None):
    model.train(opt is not None)
    tot, wsum, preds = 0.0, 0.0, []
    order = np.random.permutation(idx) if opt is not None else idx
    for i in range(0, len(order), bs):
        j = np.sort(order[i:i + bs])
        fb, fc, s = (torch.from_numpy(D[n][j]).to(dev, non_blocking=True) for n in ('fb', 'fc', 's'))
        if opt is not None:
            fb, fc = PC.dihedral(fb, fc, torch.randint(0, 8, (len(j),), device=dev))
        y = torch.from_numpy(D['y'][j].astype(np.int64)).to(dev)
        w = torch.from_numpy(np.sqrt(D['w'][j])).to(dev)
        with torch.set_grad_enabled(opt is not None):
            out = model(fb, fc, s)
            loss = (F.cross_entropy(out, y, reduction='none') * w).sum() / w.sum()
        if opt is not None:
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            sched.step()
        else:
            preds.append(out.argmax(1).cpu().numpy())
        tot += float(loss) * float(w.sum())
        wsum += float(w.sum())
    return tot / max(wsum, 1e-9), (np.concatenate(preds) if preds else None)


def report(D, idx, pred, spec):
    k, y = D['k'][idx].astype(int), D['y'][idx].astype(int)
    P, O, BG = len(spec.pair), spec.out, spec.bg
    cm = np.zeros((P, O, O), np.int64)
    np.add.at(cm, (k, y, pred), 1)
    conf = (y != k) & (y != BG)
    lines = ['held-out accuracy %.3f; confusions (target is another pair class) right %d/%d; background '
             'right %d/%d; own class kept %d/%d' % (
                 (pred == y).mean(), (pred[conf] == y[conf]).sum(), conf.sum(),
                 (pred[y == BG] == BG).sum(), (y == BG).sum(), (pred[y == k] == y[y == k]).sum(),
                 (y == k).sum())]
    for kk in range(P):
        lines.append('  predicted %-13s rows = target %s/bg, cols = classifier:\n%s'
                     % (spec.pair_names[kk], '/'.join(spec.pair_names), cm[kk]))
    return '\n'.join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('data')
    ap.add_argument('--out', required=True)
    ap.add_argument('--epochs', type=int, default=8)
    ap.add_argument('--lr', type=float, default=1e-3)
    a = ap.parse_args()
    torch.manual_seed(0)
    np.random.seed(0)
    dev = 'cuda'
    t0 = time.time()
    mf = osp.join(a.data, 'meta.json')
    spec = ppspec.get(json.load(open(mf)).get('dataset', 'soda') if osp.exists(mf) else 'soda').need_pairs()
    D = load(a.data)
    n = len(D['y'])
    imgs = np.unique(D['img'])
    rng = np.random.RandomState(0)
    held = set(rng.choice(imgs, max(1, len(imgs) // 10), replace=False).tolist())
    hmask = np.isin(D['img'], list(held))
    tr, ho = np.where(~hmask)[0], np.where(hmask)[0]
    print('%d examples (%d train / %d held out, %d original images), loaded in %.0fs; targets %s' % (
        n, len(tr), len(ho), len(imgs), time.time() - t0, np.bincount(D['y'].astype(int), minlength=spec.out)),
        flush=True)
    model = PC.PairReclassifier(n_scalar=spec.n_scalar, out=spec.out).to(dev)
    sub = rng.choice(tr, min(len(tr), 50000), replace=False)
    for name, key in (('box', 'fb'), ('ctx', 'fc')):
        m, s = chan_stats(D[key], np.sort(sub))
        getattr(model, 'mean_' + name).copy_(torch.from_numpy(m))
        getattr(model, 'std_' + name).copy_(torch.from_numpy(s))
    model.mean_s.copy_(torch.from_numpy(D['s'][sub].mean(0)))
    model.std_s.copy_(torch.from_numpy(D['s'][sub].std(0) + 1e-3))
    steps = a.epochs * ((len(tr) + 2047) // 2048)
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=a.lr, total_steps=steps, pct_start=0.1)
    best, best_ep, best_pred = 1e9, -1, None
    for ep in range(a.epochs):
        tl, _ = run(model, D, tr, dev, opt=opt, sched=sched)
        hl, pred = run(model, D, ho, dev)
        print('epoch %d train loss %.4f held-out loss %.4f acc %.3f (%.0fs)' % (
            ep + 1, tl, hl, (pred == D['y'][ho]).mean(), time.time() - t0), flush=True)
        if hl < best:
            best, best_ep, best_pred = hl, ep + 1, pred
            torch.save(dict(state_dict=model.state_dict(), epoch=ep + 1, held_out_loss=hl, data=a.data,
                            dataset=spec.name, pair=spec.pair.tolist()), a.out)
    print('best epoch %d held-out loss %.4f' % (best_ep, best), flush=True)
    print(report(D, ho, best_pred, spec), flush=True)
    print('PAIRCLF_TRAIN_DONE %s (%.0fs)' % (a.out, time.time() - t0), flush=True)


if __name__ == '__main__':
    main()
