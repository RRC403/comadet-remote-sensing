"""Dataset specs for the pair-class re-classifier and the TTA fusion (2026-11-02, numpy only).

The SODA-A scripts hard-coded the class list, the CMM pairs, the rarest pair class, the rotation views and
the tile-to-image grouping.  A spec holds these per dataset.  Scripts that build a model pick the spec from
the config's class tuple; the others read the 'dataset' key of their inputs (inputs without it are SODA-A).
  classes  the config's class tuple, in order; short = names for reports
  pairs    the CMM pairs, fixed before any re-classifier number on that dataset.  SODA-A: FIXED4, the most
           frequent end-of-training pairs over 6 seed-252/254 checkpoints.  VisDrone: the frozen pairs both
           VDPQ seeds (s246, s247) end training with, [[6, 7], [1, 9]].  FAIR1M (fixed 11-03 by a rule
           written down before the buffers were read): the 4 pairs the CMMs of the three PQ24 checkpoints
           (s245, s246, s247) emit most often at the end of training, ties broken by the mean ConfuseScore
           over the three: (9, 14) Small_Car / Van 3 of 3, (25, 29) A220 / other-airplane 2 of 3, then of
           the pairs emitted once (21, 22) Boeing777 / Boeing787 (mean 0.389) and (1, 2) Motorboat /
           Fishing_Boat (0.212)
  pair     the classes the re-classifier covers = the union of the pairs, sorted (SODA-A: 2, 3, 4, 5)
  rare     the rarest pair class in the train annotations (SODA-A large vehicle 15828, VisDrone
           awning-tricycle 3246, FAIR1M Boeing777 23): every box of it is kept for training and its
           subsampling cap is 4x
  views    rot4 = 0 / 90 / 180 / 270-degree rotations (square images; the SODA-A and FAIR1M models train
           with RandomRotate).  flip4 = identity / horizontal / vertical / both flips: lossless on any
           aspect ratio, and the VisDrone training augmentation (RandomFlip h / v / diagonal).  A 90-degree
           mmrotate.Rotate keeps the canvas, so it would cut the sides off VisDrone's 16:9 images
  group    separator whose first field names the source image or video: the val halves and the
           classifier's held-out images keep a group together (SODA-A 'IMG__tile', VisDrone 'SEQ_FRAME_..')
Class-set ablation (2026-11-03): with PPSPEC_VARIANT=<v> in the environment, from_classes() returns the spec
'<dataset>:<v>', whose pairs and rare class come from VARIANTS; the name is recorded in every meta, checkpoint
and result file, so later steps pick the variant up without the variable.  Only the union of the pairs
matters to the re-classifier (pair / rare / out); the variants were fixed before any of them was run:
  fair1m rand0-2  frequency-matched random 8-class sets without the CMM classes: the CMM classes in a seeded
                  random order (random.Random(seed), seed 0 / 1 / 2), each replaced by one of the 3 remaining
                  classes nearest in log train count
  fair1m hand     the SCENet paper's hand-picked FAIR1M-AIR pairs Boeing777-A330, Boeing777-A350, Boeing787-A330
  soda hand       SCENet's own SODA-A pair, large-vehicle / container
  soda rand0      the same draw on SODA-A (seed 0): helicopter, storage-tank, swimming-pool, windmill
  fair1m_air hand the paper's FAIR1M-AIR pairs 777-A330, 777-A350, 787-A330 in the AIR class order (rare A350)
Own pairs (2026-11-03, FAIR1M-AIR): a variant 'p<a>-<b>_<c>-<d>..._r<k>' carries the pairs and the rare class in
its name (pp/own_pairs.py writes it from a checkpoint's CMM buffers), so each model can use the pairs its own CMM
mined at the end of training.
DroneVehicle (2026-11-04, PREREG_DV_1104.md): RGB half, 640 x 512, flip4 views (non-square, as VisDrone); each
image is its own group (no tiles); pairs come from each model's own CMM (own_pairs variant), as on FAIR1M-AIR.
Variant 'sce' = SCENet's DroneVehicle pair (truck, freight_car); it only sizes the empty classifier field of the
SCENet TTA caches (no re-classifier is applied to SCENet).
DOTA-v1.5 and the FAIR1M vehicle subset (2026-11-10, PREREG_ABL_ALL_1109 C / 修订 4): square tiles (1024 / 800) from
img_split, rot4 views (both train with the SODA-A recipe's RandomRotate), tiles grouped by source image ('__');
pairs from each model's own CMM (own_pairs variant), as on FAIR1M-AIR.  Variant 'sce' = SCENet's pair on each,
(small-vehicle, large-vehicle) and (small-car, van); it only sizes the empty classifier field of the SCENet caches.
"""
import json
import os
import re

import numpy as np

SPECS = {
    'soda': dict(
        classes=('airplane', 'helicopter', 'small-vehicle', 'large-vehicle', 'ship', 'container',
                 'storage-tank', 'swimming-pool', 'windmill'),
        short=('plane', 'heli', 'SV', 'LV', 'ship', 'CT', 'tank', 'pool', 'mill'),
        pairs=((3, 5), (2, 3), (2, 5), (3, 4)), rare=3, views='rot4', group='__'),
    'visdrone': dict(
        classes=('pedestrian', 'people', 'bicycle', 'car', 'van', 'truck', 'tricycle', 'awning-tricycle',
                 'bus', 'motor'),
        short=('ped', 'people', 'bike', 'car', 'van', 'truck', 'tri', 'awn-tri', 'bus', 'motor'),
        pairs=((6, 7), (1, 9)), rare=7, views='flip4', group='_'),
    'fair1m': dict(
        classes=('Passenger_Ship', 'Motorboat', 'Fishing_Boat', 'Tugboat', 'other-ship', 'Engineering_Ship',
                 'Liquid_Cargo_Ship', 'Dry_Cargo_Ship', 'Warship', 'Small_Car', 'Bus', 'Cargo_Truck',
                 'Dump_Truck', 'other-vehicle', 'Van', 'Trailer', 'Tractor', 'Excavator', 'Truck_Tractor',
                 'Boeing737', 'Boeing747', 'Boeing777', 'Boeing787', 'ARJ21', 'C919', 'A220', 'A321', 'A330',
                 'A350', 'other-airplane', 'Baseball_Field', 'Basketball_Court', 'Football_Field',
                 'Tennis_Court', 'Roundabout', 'Intersection', 'Bridge'),
        short=None, pairs=((9, 14), (25, 29), (21, 22), (1, 2)), rare=21, views='rot4', group='__'),
    'fair1m_air': dict(
        classes=('A220', 'A321', 'Boeing737', 'Boeing777', 'ARJ21', 'A330', 'Boeing747', 'A350', 'Boeing787', 'C919',
                 'other-airplane'),
        short=('A220', 'A321', 'B737', 'B777', 'ARJ21', 'A330', 'B747', 'A350', 'B787', 'C919', 'other'),
        pairs=None, rare=None, views='rot4', group='__'),
    'dronevehicle': dict(
        classes=('car', 'truck', 'bus', 'van', 'freight_car'),
        short=('car', 'truck', 'bus', 'van', 'freight'),
        pairs=None, rare=None, views='flip4', group='__'),
    'dota15': dict(
        classes=('plane', 'baseball-diamond', 'bridge', 'small-vehicle', 'ground-track-field', 'large-vehicle', 'ship',
                 'tennis-court', 'basketball-court', 'storage-tank', 'soccer-ball-field', 'roundabout', 'harbor',
                 'swimming-pool', 'helicopter', 'container-crane'),
        short=('plane', 'BD', 'bridge', 'SV', 'GTF', 'LV', 'ship', 'TC', 'BC', 'ST', 'SBF', 'RA', 'harbor', 'SP',
               'heli', 'CC'),
        pairs=None, rare=None, views='rot4', group='__'),
    'f1mveh': dict(
        classes=('dump-truck', 'cargo-truck', 'bus', 'small-car', 'truck-tractor', 'van', 'trailer', 'tractor',
                 'excavator', 'other-vehicle'),
        short=('dump', 'cargo', 'bus', 'car', 'trk-tractor', 'van', 'trailer', 'tractor', 'excav', 'other'),
        pairs=None, rare=None, views='rot4', group='__'),
}
VIEWS = {
    'rot4': (('rot', 0), ('rot', 90), ('rot', 180), ('rot', 270)),
    'flip4': (('flip', None), ('flip', 'horizontal'), ('flip', 'vertical'), ('flip', 'diagonal')),
}
FLIP_TAG = {None: 'none', 'horizontal': 'h', 'vertical': 'v', 'diagonal': 'd'}
VARIANTS = {
    'fair1m': {
        'rand0': dict(pairs=((13, 20), (11, 31), (4, 12), (6, 19)), rare=20),
        'rand1': dict(pairs=((11, 19), (13, 27), (4, 7), (23, 35)), rare=23),
        'rand2': dict(pairs=((7, 31), (23, 35), (12, 19), (13, 33)), rare=23),
        'hand': dict(pairs=((21, 27), (21, 28), (22, 27)), rare=28),
    },
    'fair1m_air': {
        'hand': dict(pairs=((3, 5), (3, 7), (5, 8)), rare=7),
    },
    'dronevehicle': {
        'sce': dict(pairs=((1, 4),), rare=4),
    },
    'dota15': {
        'sce': dict(pairs=((3, 5),), rare=5),
    },
    'f1mveh': {
        'sce': dict(pairs=((3, 5),), rare=5),
    },
    'soda': {
        'hand': dict(pairs=((3, 5),), rare=3),
        'rand0': dict(pairs=((7, 8), (1, 6)), rare=1),
    },
}


def view_file(v):
    return 'angle_%d.pkl' % v[1] if v[0] == 'rot' else 'flip_%s.pkl' % FLIP_TAG[v[1]]


class Spec:
    def __init__(self, name):
        base, _, var = name.partition(':')
        s = dict(SPECS[base])
        own = re.fullmatch(r'p((?:\d+-\d+_)+)r(\d+)', var)
        if own:
            s.update(pairs=tuple(tuple(int(c) for c in p.split('-')) for p in own.group(1).strip('_').split('_')),
                     rare=int(own.group(2)))
        elif var:
            s.update(VARIANTS[base][var])
        self.name = name
        self.classes = tuple(s['classes'])
        self.k = len(self.classes)
        self.short = tuple(s['short'] or self.classes)
        self.group = s['group']
        self.views = VIEWS[s['views']]
        self.view_files = tuple(view_file(v) for v in self.views)
        self.pairs = s['pairs']
        if self.pairs is None:
            self.pair = None
            return
        self.pair = np.array(sorted({c for p in self.pairs for c in p}))
        self.out = len(self.pair) + 1
        self.bg = len(self.pair)
        self.n_scalar = len(self.pair) + 4
        self.rare = int(np.searchsorted(self.pair, s['rare']))
        assert self.pair[self.rare] == s['rare']
        self.pair_names = tuple(self.short[c] for c in self.pair)

    def need_pairs(self):
        if self.pair is None:
            raise SystemExit('%s: CMM pairs not fixed yet (ppspec.SPECS)' % self.name)
        return self

    def orig(self, img_id):
        return str(img_id).split(self.group)[0]


def get(name):
    return Spec(name)


def from_classes(classes):
    t = tuple(classes)
    for name, s in SPECS.items():
        if tuple(s['classes']) == t:
            var = os.environ.get('PPSPEC_VARIANT', '')
            return Spec('%s:%s' % (name, var) if var else name)
    raise SystemExit('no dataset spec for classes %s' % (t,))


def for_cache(d):
    """Spec and view files of a pairclf_cache.py directory (old SODA-A caches carry neither)."""
    mf = os.path.join(d, 'clf_meta.json')
    meta = json.load(open(mf)) if os.path.exists(mf) else {}
    spec = Spec(meta.get('dataset', 'soda'))
    return spec, tuple(meta.get('views', spec.view_files))


def gt_to_orig(g, sf):
    """GT of the first view (resized frame) -> original frame, as DOTAMetric does.  Uniform scale factors
    (every SODA-A tile) take the old division path, bit for bit; VisDrone's rounded resize gives slightly
    different x / y factors, which RotatedBoxes.rescale_ handles as DOTAMetric does."""
    sf = np.asarray(sf, np.float32).reshape(-1)[:2]
    g = np.asarray(g, np.float32).reshape(-1, 5).copy()
    if abs(float(sf[0]) - float(sf[1])) <= 1e-6:
        g[:, :4] /= sf[0]
        return g
    import torch
    from mmrotate.structures.bbox import RotatedBoxes
    rb = RotatedBoxes(torch.from_numpy(g))
    rb.rescale_((1.0 / float(sf[0]), 1.0 / float(sf[1])))
    return rb.tensor.numpy().astype(np.float32)
