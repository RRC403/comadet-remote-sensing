"""Shared pieces of the pair-class re-classifier, for any dataset with a ppspec entry (2026-11-02).

Generalized copy of ../pairclf_common.py; on SODA-A it computes exactly what that file computes.  A frozen
detector's detections of the CMM pair classes are re-classified by a small separate network that reads two
RoIs of the detector's own FPN features:
  box      the predicted rotated box on P3 (stride 8), 5 x 5
  context  the same box enlarged 2.5x (at least 48 px per side in the resized frame) on P4 (stride 16)
plus scalars: predicted pair class (one-hot), detector score, log of the long side, short side and area in
original-image pixels.  Output: the pair classes and background.  The dataset spec (pair classes, views,
image groups) is picked from the config's class tuple (ppspec.py).
"""
import copy
import os
import os.path as osp
import sys
from types import SimpleNamespace

import numpy as np
import torch
import torch.nn as nn
from mmcv.ops import RoIAlignRotated

sys.path.insert(0, osp.dirname(osp.abspath(__file__)))
sys.path.append('/hy-tmp/masenet/project/mmrotate/tools/analysis_tools')
import ppspec  # noqa: E402
import tta_rotated as TR  # noqa: E402
from mmdet.structures.bbox import BaseBoxes  # noqa: E402
from mmrotate.structures.bbox import RotatedBoxes  # noqa: E402

POOL = 5
CTX_SCALE = 2.5
CTX_MIN = 48.0


def tensor_of(b):
    return b.tensor if isinstance(b, BaseBoxes) else b


class RoIFeats:
    def __init__(self):
        self.box = RoIAlignRotated(POOL, 1 / 8., sampling_ratio=2, aligned=True, clockwise=True)
        self.ctx = RoIAlignRotated(POOL, 1 / 16., sampling_ratio=2, aligned=True, clockwise=True)

    def __call__(self, x, rois):
        """x: neck outputs P3..P7; rois [N, 6] = (batch index, cx, cy, w, h, angle), resized frame."""
        r = rois.float()
        c = r.clone()
        c[:, 3] = torch.clamp(r[:, 3] * CTX_SCALE, min=CTX_MIN)
        c[:, 4] = torch.clamp(r[:, 4] * CTX_SCALE, min=CTX_MIN)
        return self.box(x[0].float(), r), self.ctx(x[1].float(), c)


def scalars(boxes, scores, labels, spec):
    """boxes [N, 5] in the original image frame, labels in spec.pair -> [N, len(pair) + 4] float32."""
    k = np.searchsorted(spec.pair, labels)
    w, h = boxes[:, 2].astype(np.float64), boxes[:, 3].astype(np.float64)
    return np.concatenate([np.eye(len(spec.pair), dtype=np.float32)[k], scores.reshape(-1, 1),
                           np.log1p(np.maximum(w, h)).reshape(-1, 1), np.log1p(np.minimum(w, h)).reshape(-1, 1),
                           np.log1p(w * h).reshape(-1, 1)], 1).astype(np.float32)


class PairReclassifier(nn.Module):
    def __init__(self, c=256, r=64, hidden=512, n_scalar=8, out=5):
        super().__init__()
        for n, d in (('box', c), ('ctx', c), ('s', n_scalar)):
            self.register_buffer('mean_' + n, torch.zeros(d))
            self.register_buffer('std_' + n, torch.ones(d))
        self.box = nn.Sequential(nn.Conv2d(c, r, 1), nn.ReLU(inplace=True))
        self.ctx = nn.Sequential(nn.Conv2d(c, r, 1), nn.ReLU(inplace=True))
        d = 2 * r * POOL * POOL + n_scalar
        self.mlp = nn.Sequential(nn.LayerNorm(d), nn.Linear(d, hidden), nn.ReLU(inplace=True), nn.Dropout(0.2),
                                 nn.Linear(hidden, hidden), nn.ReLU(inplace=True), nn.Dropout(0.2),
                                 nn.Linear(hidden, out))

    def forward(self, fb, fc, s):
        fb = (fb.float() - self.mean_box[None, :, None, None]) / self.std_box[None, :, None, None]
        fc = (fc.float() - self.mean_ctx[None, :, None, None]) / self.std_ctx[None, :, None, None]
        s = (s.float() - self.mean_s) / self.std_s
        return self.mlp(torch.cat([self.box(fb).flatten(1), self.ctx(fc).flatten(1), s], 1))


def build_detector(config, checkpoint, split, score_thr):
    """tta_rotated's model build and combo test_cfg (NMS 0.4, 4000 / 4000); hooks the neck output.

    split = the folder under data_root ('train', 'val' or 'test'; SODA-A's and VisDrone's test = test-dev).
    Numerics follow tools/test.py: MASENetEpochHook (SODA-A, FAIR1M configs) turns TF32 on in before_run,
    the VisDrone configs leave torch's defaults.  Returns cfg, model, the neck-output dict and the spec.
    """
    opts = {'model.test_cfg.score_thr': score_thr,
            'test_dataloader.dataset.ann_file': '%s/annfiles/' % split,
            'test_dataloader.dataset.data_prefix.img_path': '%s/images/' % split}
    cfg = TR.build_cfg(SimpleNamespace(config=config, cfg_options=opts))
    ds = cfg.test_dataloader['dataset']
    d = osp.join(ds.get('data_root', ''), '%s/images/' % split)
    if ds.get('img_suffix') and osp.isdir(d):
        # FAIR1M-AIR keeps train crops as .jpg and val / test crops as .png, and the test loader names the png
        # suffix; every other dataset has the configured suffix in each split, so nothing changes there.
        ext = {os.path.splitext(f)[1].lstrip('.') for f in os.listdir(d)}
        if ds['img_suffix'] not in ext and len(ext) == 1:
            ds['img_suffix'] = ext.pop()
    cfg = TR.apply_test_cfg(cfg, 'combo', per_view_iou=None, merge_iou=0.4)
    if any(h.get('type') == 'MASENetEpochHook' for h in cfg.get('custom_hooks', [])):
        TR._set_numerics(cfg)
    else:
        torch.backends.cudnn.benchmark = bool(cfg.get('env_cfg', {}).get('cudnn_benchmark', False))
    spec = ppspec.from_classes(cfg.test_dataloader['dataset']['metainfo']['classes'])
    model = TR.build_model(cfg, checkpoint, 'cuda:0')
    sd = torch.load(checkpoint, map_location='cpu')['state_dict']
    own = model.state_dict()
    keys = [k for k in own if k in sd]
    for k in (keys[0], keys[len(keys) // 2], keys[-1], 'bbox_head_refine.0.retina_cls.weight'):
        assert torch.equal(sd[k], own[k].cpu()), '%s not loaded from %s' % (k, checkpoint)
    del sd, own
    feats = {}
    model.neck.register_forward_hook(lambda m, i, o: feats.__setitem__('x', o))
    return cfg, model, feats, spec


def view_dl_cfg(cfg, view):
    """Test dataloader of one view.  ('rot', a): tta_rotated's Rotate after ConvertBoxType (unchanged for
    a = 0).  ('flip', d): mmdet.RandomFlip(prob 1, direction d) right after the Resize, where training
    flips too; d = None is the plain pipeline."""
    if view[0] == 'rot':
        return TR.make_rotated_dl_cfg(cfg, view[1])
    dl = copy.deepcopy(cfg.test_dataloader)
    if view[1] is None:
        return dl
    pipe, out, done = dl['dataset']['pipeline'], [], False
    for t in pipe:
        out.append(t)
        if not done and str(t.get('type', '')).endswith('Resize'):
            out.append(dict(type='mmdet.RandomFlip', prob=1.0, direction=view[1]))
            done = True
    if not done:
        raise RuntimeError('no Resize in the test pipeline: %s' % [t.get('type') for t in pipe])
    dl['dataset']['pipeline'] = out
    return dl


def unview_boxes(b, view, h, w):
    """Predictions of one view (original frame of the transformed image) -> original image, le135."""
    if view[0] == 'rot' or view[1] is None:
        return TR.unrotate_boxes(b, (w * 0.5, h * 0.5), view[1] if view[0] == 'rot' else 0)
    if len(b) == 0:
        return b
    rb = RotatedBoxes(torch.from_numpy(np.asarray(b, np.float32)).clone())
    rb.flip_((int(h), int(w)), view[1])
    rb.regularize_boxes(pattern=TR.ANGLE_VESION)
    return rb.tensor.numpy().astype(np.float32)


def scale_xy(s):
    sf = np.asarray(s.metainfo['scale_factor'], np.float64).reshape(-1)
    return float(sf[0]), float(sf[1])


def to_resized(b, sf):
    """Rotated boxes [N, 5] (torch) original frame -> resized frame.  Uniform scale factors (every SODA-A
    tile) take the old multiply, bit for bit; VisDrone's rounded resize uses RotatedBoxes.rescale_."""
    r = b.clone()
    if abs(sf[0] - sf[1]) <= 1e-6:
        r[:, :4] *= sf[0]
        return r
    rb = RotatedBoxes(r)
    rb.rescale_(sf)
    return rb.tensor


def to_orig(b, sf):
    """Inverse of to_resized (GT of a data sample -> original frame, as DOTAMetric does)."""
    r = b.clone()
    if abs(sf[0] - sf[1]) <= 1e-6:
        r[:, :4] /= sf[0]
        return r
    rb = RotatedBoxes(r)
    rb.rescale_((1.0 / sf[0], 1.0 / sf[1]))
    return rb.tensor


def dihedral(fb, fc, code):
    """code [B] in 0..7: bit 0 transpose, bit 1 flip rows, bit 2 flip columns of both 5 x 5 grids.

    The grids follow the box's own axes, and le135 may swap a box's width and height between views, so
    the classifier is trained and evaluated on all 8 symmetries.
    """
    t = code[:, None, None, None]
    out = []
    for f in (fb, fc):
        f = torch.where((t & 1).bool(), f.transpose(2, 3), f)
        f = torch.where((t & 2).bool(), f.flip(2), f)
        f = torch.where((t & 4).bool(), f.flip(3), f)
        out.append(f)
    return out


@torch.no_grad()
def predict_probs(clf, fb, fc, s):
    """Softmax over the pair classes and background, averaged over the 8 grid symmetries."""
    p = 0
    for c in range(8):
        a, b = dihedral(fb, fc, torch.full((len(s),), c, dtype=torch.long, device=s.device))
        p = p + torch.softmax(clf(a, b, s), 1)
    return p / 8


assert osp.isdir('/hy-tmp/masenet/project/mmrotate'), 'run on a GPU host'
