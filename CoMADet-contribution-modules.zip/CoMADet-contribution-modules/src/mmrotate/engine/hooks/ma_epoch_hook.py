from mmengine.hooks import Hook

from mmrotate.registry import HOOKS


@HOOKS.register_module()
class MASENetEpochHook(Hook):
    """Propagate the MMEngine epoch to MA-SENet's optional CMM modules.

    ``ConfusionMatrixMiner`` 用 ``current_epoch`` 决定是否已经过了预热期
    （论文 3.3），因此每个 epoch 开始时必须把 runner 的 epoch 写进模型。
    模型没实现该接口时（例如直接用基类 S2A-Net 配置）本钩子自动降级为 no-op。
    """

    priority = 'NORMAL'

    def before_train_epoch(self, runner) -> None:
        model = runner.model
        # MMEngine wraps distributed models; unwrap only for this small API.
        model = getattr(model, 'module', model)
        setter = getattr(model, 'set_current_epoch', None)
        if setter is not None:
            setter(runner.epoch)


@HOOKS.register_module()
class MASENetSparsityHook(Hook):
    """Re-apply Light-LSE-FPN's hard sparsity constraint after every step.

    ``_SparseEdge`` 用 ``register_hook`` 把边缘算子零位置的梯度清零，但**反向
    清零并不等于参数不动**：只要优化器带 momentum / weight decay（或用了
    Adam 之类的自适应优化器），零位置仍会在 ``optimizer.step()`` 里被推离 0，
    几十步之后“稀疏核”就退化成普通 3x3 深度卷积，论文 3.5 的硬约束随之失效。

    本钩子在每次 ``optimizer.step()`` 之后把零位置权重重新置零，是论文
    “只有算子非零位置参与学习”这一约束在训练循环层面的兜底。梯度清零
    （反传）+ 本钩子（更新后）两者缺一不可。

    模型 neck 没有 ``enforce_sparsity`` 方法时自动降级为 no-op，因此在 DOTA /
    SODA-A 之外的、未启用 LightLSEFPN 的配置里挂上它也不会报错。
    """

    priority = 'NORMAL'

    def after_train_iter(self, runner, batch_idx=None, data_batch=None,
                         outputs=None) -> None:
        model = getattr(runner.model, 'module', runner.model)
        neck = getattr(model, 'neck', None)
        enforce = getattr(neck, 'enforce_sparsity', None)
        if enforce is not None:
            enforce()
