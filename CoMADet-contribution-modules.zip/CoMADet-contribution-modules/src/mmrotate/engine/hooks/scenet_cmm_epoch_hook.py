"""Epoch-level provenance logging for the SCENet CMM/M-SCA ablation."""

from mmengine.hooks import Hook

from mmrotate.registry import HOOKS


@HOOKS.register_module()
class SCENetCMMEpochHook(Hook):
    """Log online-pair activity without affecting optimization or data flow."""

    priority = 'LOW'

    def before_train_epoch(self, runner) -> None:
        model = getattr(runner.model, 'module', runner.model)
        setter = getattr(model, 'set_current_epoch', None)
        if setter is not None:
            setter(runner.epoch)
            return
        head = getattr(model, 'bbox_head_init', None)
        setter = getattr(head, 'set_current_epoch', None)
        if setter is not None:
            setter(runner.epoch)

    def after_train_epoch(self, runner) -> None:
        model = getattr(runner.model, 'module', runner.model)
        head = getattr(model, 'bbox_head_init', None)
        summary = getattr(head, 'cmm_epoch_summary', None)
        if summary is None:
            return
        stats = summary()
        runner.logger.info(
            'visdrone-cmm ep%d: steps=%d active_steps=%d empty_steps=%d '
            'window_pair_hits=%d '
            'loss_nonzero=%d loss_mean_nonzero=%.6g pairs=%s',
            runner.epoch + 1,
            stats['steps'], stats['active_steps'], stats['empty_steps'],
            stats['window_pair_hits'],
            stats['loss_nonzero_steps'], stats['loss_mean_nonzero_only'],
            stats['pair_hits'])
