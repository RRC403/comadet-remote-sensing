from mmengine.hooks import Hook
from mmrotate.registry import HOOKS


@HOOKS.register_module()
class CMMInjectHook(Hook):
    """Wire the initial-head miner into CMM-aware refine heads."""
    priority = 'NORMAL'

    def before_run(self, runner):
        model = getattr(runner.model, 'module', runner.model)
        init_head = getattr(model, 'bbox_head_init', None)
        miner = getattr(init_head, 'confusion_miner', None)
        if miner is None:
            return
        for head in getattr(model, 'bbox_head_refine', []):
            setter = getattr(head, 'set_miner', None)
            if setter is not None:
                setter(miner)
