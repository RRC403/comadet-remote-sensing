"""Lightweight VisDrone neck: the SCENet LSE-FPN with LEM/SFM removed.

Why this file exists
--------------------
On VisDrone the neck (``SCENetOfficialLSEFPN``) costs 21.48M parameters, and
63% of that sits in two edge-enhancement stacks::

    sfm_modules   9.8624 M
    lem_modules   3.6224 M
    fpn_convs     7.0792 M
    lateral_convs 0.9183 M

Those two stacks are exactly what the SODA ``LightLSEFPN`` gives up, so the
VisDrone efficiency ablation should give up the same thing.

Why not reuse ``LightLSEFPN`` directly
--------------------------------------
``LightLSEFPN`` builds on VisDrone (49.93M -> 31.96M total) but the first training
iteration dies in ``S2ARefineHead.forward_single`` -> ``orconv.rotate_arf`` ->
``active_rotated_filter`` with ``CUDA error: an illegal memory access``: the
oriented convolution in the S2A refine head is incompatible with that neck's
output layout.

How this version differs
------------------------
The FPN topology, channel widths and output level count are untouched; only the
LEM/SFM stacks are replaced.  LEM is a *transform* on the lateral features, so it
becomes ``nn.Identity``.  SFM is a *residual* add, so it becomes a zero module
(an identity there would double the features).  Shapes are therefore identical to
the baseline neck at every level, which is what keeps ``S2ARefineHead``'s oriented
convolution happy.
"""
from __future__ import annotations

import torch
from torch import nn

from mmrotate.registry import MODELS
from .scenet_official_lse_fpn import SCENetOfficialLSEFPN


class _ZeroLike(nn.Module):
    """Returns zeros with the same shape as the input (a true residual no-op)."""

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.zeros_like(x)


@MODELS.register_module()
class LightSCENetLSEFPN(SCENetOfficialLSEFPN):
    """``SCENetOfficialLSEFPN`` without the LEM/SFM edge-enhancement stacks.

    Parameter effect (VisDrone, out_channels=256): neck 21.4822M -> 8.0022M,
    total 49.9278M -> 36.4478M (-27.0%).
    """

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        for i in range(len(self.lem_modules)):
            self.lem_modules[i] = nn.Identity()
        for i in range(len(self.sfm_modules)):
            self.sfm_modules[i] = _ZeroLike()


__all__ = ['LightSCENetLSEFPN']
