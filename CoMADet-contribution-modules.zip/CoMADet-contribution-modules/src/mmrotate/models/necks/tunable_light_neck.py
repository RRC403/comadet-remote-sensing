"""Dataset-agnostic lightweight neck with tunable compression strength.

Failure history that motivates the knobs here
----------------------------------------------
1. ``LightLSEFPN`` swapped in wholesale  -> VisDrone dies (S2ARefineHead's oriented
   convolution cannot consume that neck's output layout).
2. ``LightSCENetLSEFPN`` replaced LEM/SFM with Identity/zeros -> val collapses ~20x.
   Post-mortem: LEM/SFM carry a residual **and** a LayerNorm, so deleting them
   changes the scale of what feeds ``fpn_convs``.
3. ``LightEdgeNeck(groups='dw')`` kept the graph but depthwise-separated every 3x3
   inside LEM/SFM -> SODA -0.0085, VisDrone -0.0126.  Functional, but too aggressive:
   depthwise convolution removes almost all cross-channel mixing in the very layers
   that build the edge response, and small objects are what VisDrone scores on.

So the remaining question is not *whether* structural lightening can run (it can),
but *how much* is free.  This module exposes that as two knobs:

* ``targets``: ``'both'`` | ``'sfm'`` | ``'lem'``.
  LEM performs edge extraction (``conv3x3 + conv1x1->conv3x3 + edge_l``) and SFM
  performs multi-branch aggregation.  Hypothesis: edge extraction is the part that
  matters for small objects, so ``targets='sfm'`` should cost less than ``'both'``
  at a similar parameter saving.
* ``groups``: ``1`` (no change) ... ``C`` (depthwise).  ``groups=4`` halves the
  parameter cut relative to depthwise while keeping cross-channel mixing.

Parameter effect per 3x3 C->C conv (C=256)::

    groups=1     9*C*C          = 589,824
    groups=4     9*C*(C/4)      = 147,456     4.0x smaller
    groups=8     9*C*(C/8)      =  73,728     8.0x smaller
    'dw'         9*C + C*C      =  67,840     8.7x smaller  (depthwise + 1x1)

The module keeps every output shape and the LayerNorm/residual structure, which is
what made attempt (3) trainable at all.
"""
from __future__ import annotations

import torch.nn as nn

from mmrotate.registry import MODELS


class GroupedConv3x3(nn.Module):
    """Drop-in replacement for a 3x3 C->C conv with a configurable group count."""

    def __init__(self, channels: int, groups: int = 4, bias: bool = True) -> None:
        super().__init__()
        g = int(groups) if groups not in ('dw', 'depthwise') else int(channels)
        g = max(1, min(int(channels), g))
        # channels must be divisible by groups
        while int(channels) % g != 0 and g > 1:
            g -= 1
        self.groups = g
        self.conv = nn.Conv2d(channels, channels, 3, stride=1, padding=1,
                              groups=g, bias=bias)

    def forward(self, x):
        return self.conv(x)


class DepthwiseSeparableConv3x3(nn.Module):
    """depthwise 3x3 + pointwise 1x1, the most aggressive option."""

    def __init__(self, channels: int, bias: bool = True) -> None:
        super().__init__()
        self.dw = nn.Conv2d(channels, channels, 3, stride=1, padding=1,
                            groups=channels, bias=False)
        self.pw = nn.Conv2d(channels, channels, 1, stride=1, padding=0, bias=bias)

    def forward(self, x):
        return self.pw(self.dw(x))


def _replacement(channels: int, groups, bias: bool):
    if groups in ('dw', 'depthwise'):
        return DepthwiseSeparableConv3x3(channels, bias=bias)
    if int(groups) <= 1:
        return None
    return GroupedConv3x3(channels, groups=groups, bias=bias)


def lighten_edge_conv3x3(module, groups=4, targets='both', verbose=False) -> int:
    """Replace 3x3 full convs inside ``LEM`` / ``SFM`` children.

    Args:
        module: the neck to modify in place.
        groups: int >= 2, or ``'dw'`` for depthwise-separable.
        targets: ``'both'`` | ``'sfm'`` | ``'lem'``.
    """
    if targets not in ('both', 'sfm', 'lem'):
        raise ValueError("targets must be 'both', 'sfm' or 'lem'")
    replaced = 0
    for name, child in module.named_modules():
        cls = type(child).__name__
        if cls not in ('LEM', 'SFM'):
            continue
        if targets == 'sfm' and cls != 'SFM':
            continue
        if targets == 'lem' and cls != 'LEM':
            continue
        # NOTE: nn.Module keeps submodules in ``_modules``; ``vars()`` does not see
        # them, so named_children() is required here.
        for attr, sub in list(child.named_children()):
            if (isinstance(sub, nn.Conv2d)
                    and tuple(sub.kernel_size) == (3, 3)
                    and sub.groups == 1
                    and sub.in_channels == sub.out_channels):
                new = _replacement(sub.in_channels, groups, sub.bias is not None)
                if new is None:
                    continue
                setattr(child, attr, new)
                replaced += 1
                if verbose:
                    print('        %s.%s: 3x3 %dch groups=%s' % (
                        name, attr, sub.in_channels, groups))
    return replaced



class LowRankConv(nn.Module):
    """Low-rank factorisation of a kxk conv: 1x1(in->rank) then 3x3(rank->out).

    Motivation (measured, not assumed): ``TunableLightNeck`` only ever replaced
    convs whose ``in_channels == out_channels``, so the SFM edge-fusion conv
    (``in=2*C, out=C`` -- 1,179,904 params each on SODA's LSEFPN) was never
    touched by any earlier lightweighting experiment.  This is therefore the one
    lever the negative results do not cover.

    No activation between the two layers on purpose: the pair is a pure rank
    constraint on the original kernel, so the module stays in the same function
    class as the conv it replaces (only lower rank).
    """

    def __init__(self, in_channels: int, out_channels: int, rank: int,
                 bias: bool = True) -> None:
        super().__init__()
        rank = int(rank)
        if rank <= 0 or rank >= min(int(in_channels), int(out_channels)):
            raise ValueError('rank must be in (0, min(in, out))')
        self.reduce = nn.Conv2d(int(in_channels), rank, 1, bias=False)
        self.expand = nn.Conv2d(rank, int(out_channels), 3, stride=1, padding=1,
                                bias=bias)

    def forward(self, x):
        return self.expand(self.reduce(x))


def lowrank_edge_conv(module, rank: int, levels=None, verbose: bool = False) -> int:
    """Replace ``edge_conv`` (2C->C 3x3) inside SFM modules with a low-rank pair.

    Args:
        module: the neck to modify in place.
        rank: bottleneck width.
        levels: optional iterable of SFM indices to modify (e.g. ``(1, 2)`` for
            P4/P5 only). ``None`` means every SFM.
    """
    keep = None if levels is None else {int(x) for x in levels}
    replaced = 0
    for name, child in module.named_modules():
        if type(child).__name__ != 'SFM':
            continue
        if keep is not None:
            tail = name.rsplit('.', 1)[-1]
            try:
                idx = int(tail)
            except ValueError:
                idx = None
            if idx is None or idx not in keep:
                continue
        for attr, sub in list(child.named_children()):
            if not isinstance(sub, nn.Conv2d):
                continue
            if tuple(sub.kernel_size) != (3, 3) or sub.groups != 1:
                continue
            if sub.in_channels != 2 * sub.out_channels:
                continue
            setattr(child, attr, LowRankConv(sub.in_channels, sub.out_channels,
                                             rank, bias=sub.bias is not None))
            replaced += 1
            if verbose:
                print('        %s.%s: 3x3 %d->%d lowrank r=%d' % (
                    name, attr, sub.in_channels, sub.out_channels, rank))
    return replaced


@MODELS.register_module()
class TunableLightNeck(nn.Module):
    """Wrap any LSE-family neck with tunable edge-module compression.

    Args:
        base_cfg (dict): the neck to wrap (``SCENetOfficialLSEFPN`` on VisDrone,
            ``LSEFPN`` on SODA).
        groups (int | str): 2/4/8 or ``'dw'``. ``1`` disables the change.
        targets (str): ``'both'`` | ``'sfm'`` | ``'lem'``.
    """

    def __init__(self, base_cfg: dict, groups=4, targets: str = 'both',
                 edge_rank=None, edge_levels=None,
                 verbose: bool = False) -> None:
        super().__init__()
        self.base = MODELS.build(base_cfg)
        self.groups = groups
        self.targets = targets
        self.edge_rank = edge_rank
        self.edge_levels = edge_levels
        self.num_replaced = 0
        self.num_lowrank = 0
        if edge_rank is not None:
            # Independent lever: works even when ``groups`` leaves the 3x3 convs
            # untouched (``groups=1``), because it edits ``edge_conv`` instead.
            self.num_lowrank = lowrank_edge_conv(
                self.base, int(edge_rank), levels=edge_levels, verbose=verbose)
        if not (isinstance(groups, str) or int(groups) > 1):
            return
        self.num_replaced = lighten_edge_conv3x3(
            self.base, groups=groups, targets=targets, verbose=verbose)

    def forward(self, x):
        return self.base(x)


__all__ = ['GroupedConv3x3', 'DepthwiseSeparableConv3x3', 'LowRankConv',
           'TunableLightNeck', 'lighten_edge_conv3x3', 'lowrank_edge_conv']
