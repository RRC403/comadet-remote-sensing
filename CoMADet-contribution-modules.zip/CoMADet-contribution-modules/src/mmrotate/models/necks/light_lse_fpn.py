"""Light-LSE-FPN: 稀疏可学习边缘增强 FPN（论文 3.5）.

与原 LSE-FPN 的区别（论文 3.5）：
1) **稀疏可学习边缘核**：深度卷积核用拉普拉斯 / Sobel 算子初始化，**只有算子
   非零位置**参与学习，其余位置被永久置零并冻结（梯度掩码 + 硬约束 + 权重回写）；
2) **分支裁剪**：去掉原 LEM/SFM 中冗余的并行 3x3 分支，先用 1x1 卷积做通道
   压缩再送入边缘算子；
3) **模块复用**：仅对浅层 ``shallow_levels`` 个尺度（小目标对应的高分辨率层）
   部署完整 LEM+SFM，高层只保留轻量 1x1/3x3 卷积。

原实现的 bug（本次修复）
------------------------
* 掩码只冻结了中心 ``(1,1)``，而不是算子真正的零位置，因此"稀疏核"名不副实：
  - Sobel-X 的零位置是整列 ``(0,1),(1,1),(2,1)``；
  - Sobel-Y 的零位置是整行 ``(1,0),(1,1),(1,2)``；
  - Laplacian 的零位置是四个角 ``(0,0),(0,2),(2,0),(2,2)``（原掩码是全 1，等于没有稀疏化）。
* ``forward`` 里用 ``weight.data.mul_(mask)`` 原地改写参数，在 ``torch.compile`` /
  AMP / DDP 下不安全，且会破坏 ``init_weights`` 的一致性。

修复后三条机制共同保证零位置永远为零：
* ``register_buffer('sparse_mask', keep)`` 记录可学习位置；
* ``param.register_hook`` 在反传时把零位置梯度清零；
* ``_enforce_sparsity()`` 在 ``init_weights`` 后与每步 ``optimizer.step`` 后把零位置
  权重硬置零（防御性，即使 optimizer 有 weight decay / 自定义更新也不会漂移）。
"""

from typing import Dict, List, Sequence, Tuple, Union

import torch


def _interp_amp(x, size=None, scale_factor=None, mode='nearest'):
    """AMP 兼容的 interpolate（torch 2.0.0 的 upsample 未实现 BFloat16）。

    先转 fp32 计算再转回原 dtype，数值与直接计算等价。
    """
    import torch.nn.functional as _F
    if x.dtype in (torch.bfloat16, torch.float16):
        return _F.interpolate(x.float(), size=size, scale_factor=scale_factor,
                              mode=mode).to(x.dtype)
    return _F.interpolate(x, size=size, scale_factor=scale_factor, mode=mode)

import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import ConvModule
from mmengine.model import BaseModule
from torch import Tensor

from mmrotate.registry import MODELS

#: 边缘算子初始化核（论文式 (8) 的 W_Lap、SFM 的 Sobel-X/Y）。
_EDGE_KERNELS: Dict[str, List[List[float]]] = {
    'x': [[-1., 0., 1.], [-2., 0., 2.], [-1., 0., 1.]],   # Sobel-X
    'y': [[-1., -2., -1.], [0., 0., 0.], [1., 2., 1.]],   # Sobel-Y
    'l': [[0., 1., 0.], [1., -4., 1.], [0., 1., 0.]],     # Laplacian
}

# Enhancement branches must start close to identity.  A zero logit gives a
# 0.1 residual scale with the 0.2 cap, which is already large enough to change
# the feature distribution before the detector has learned anything.
_DEFAULT_RES_SCALE_LOGIT = -6.0
_EDGE_FEATURE_CLIP = 4.0
_EDGE_ADAPTER_WEIGHT_CLIP = 0.05

class _SparseEdge(nn.Module):
    """深度可分离的稀疏边缘算子：只有核的非零位置可学习。

    Args:
        channels (int): 通道数（深度卷积 ``groups=channels``）。
        kind (str): ``'x'`` / ``'y'`` / ``'l'``，决定初始化核与稀疏掩码。
    """

    def __init__(self, channels: int, kind: str) -> None:
        super().__init__()
        if kind not in _EDGE_KERNELS:
            raise ValueError(f"kind must be one of {sorted(_EDGE_KERNELS)}, "
                             f"got '{kind}'")
        self.kind = kind
        self.channels = int(channels)
        self.conv = nn.Conv2d(channels, channels, 3, padding=1,
                              groups=channels, bias=False)
        self.mix = nn.Conv2d(channels, channels, 1)
        kernel = torch.tensor(_EDGE_KERNELS[kind],
                              dtype=torch.float32)[None, None]
        self.register_buffer('_edge_kernel', kernel)
        with torch.no_grad():
            self.conv.weight.copy_(kernel.repeat(channels, 1, 1, 1))
        # ``keep`` = 允许学习的非零位置；零位置永久冻结为 0。
        keep = (kernel != 0).repeat(channels, 1, 1, 1)
        self.register_buffer('sparse_mask', keep)
        self.conv.weight.register_hook(self._mask_grad)
        self._enforce_sparsity()

    def _mask_grad(self, grad: Tensor) -> Tensor:
        return grad * self.sparse_mask.to(device=grad.device,
                                          dtype=grad.dtype)

    @torch.no_grad()
    def _enforce_sparsity(self) -> None:
        """Zero the frozen positions of the depthwise kernel (hard constraint)."""
        self.conv.weight.mul_(self.sparse_mask.to(self.conv.weight.dtype))

    @torch.no_grad()
    def restore_kernel(self) -> None:
        """Restore the intended Sobel/Laplacian initialization."""
        self.conv.weight.copy_(self._edge_kernel.to(
            device=self.conv.weight.device, dtype=self.conv.weight.dtype
        ).repeat(self.channels, 1, 1, 1))
        self._enforce_sparsity()

    @property
    def num_trainable_positions(self) -> int:
        return int(self.sparse_mask[0, 0].sum().item())

    def forward(self, x: Tensor) -> Tensor:
        # Keep the fixed Sobel/Laplacian response bounded before it reaches
        # the learned 1x1 mixer.  This prevents a large first update from
        # amplifying the edge branch and destabilizing the detector head.
        response = self.conv(x)
        response = _EDGE_FEATURE_CLIP * torch.tanh(
            response / _EDGE_FEATURE_CLIP)
        return self.mix(response)

class _LEM(nn.Module):
    """Laplacian Edge Module（论文式 (9)：二阶边缘增强）."""

    def __init__(self, channels: int,
                 res_scale_logit_init: float = _DEFAULT_RES_SCALE_LOGIT) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 1)
        self.conv3 = nn.Conv2d(channels, channels, 3, padding=1)
        self.conv3_from_1x1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.edge = _SparseEdge(channels, 'l')
        # LayerNorm over channels matches the paper and preserves each
        # spatial location's local edge response better than GroupNorm(1, C).
        self.norm = nn.LayerNorm(channels)
        self.out_proj = nn.Conv2d(channels, channels, 1)
        # Bounded residual strength, initialized close to zero so the neck
        # starts as the ordinary FPN and learns the enhancement gradually.
        self.res_scale_logit = nn.Parameter(
            torch.tensor(float(res_scale_logit_init)))

    def forward(self, x: Tensor) -> Tensor:
        # F_LEM(X) = LayerNorm(X + Conv3x3(X) + Conv3x3(Conv1x1(X)) + F_Lap(X))
        feat = self.conv1(x)
        enhanced = x + self.conv3(x) + self.conv3_from_1x1(feat)
        enhanced = enhanced + self.edge(feat)
        enhanced = _EDGE_FEATURE_CLIP * torch.tanh(
            enhanced / _EDGE_FEATURE_CLIP)
        enhanced = self.norm(enhanced.permute(0, 2, 3, 1))
        enhanced = enhanced.permute(0, 3, 1, 2).contiguous()
        scale = 0.2 * torch.sigmoid(self.res_scale_logit)
        # Bound the learned adapter before adding it to the detector feature.
        # The edge response can be large during the first optimizer steps;
        # gradient clipping alone does not prevent a destructive feature jump.
        return x + scale * torch.tanh(self.out_proj(enhanced))

    @torch.no_grad()
    def zero_init_output(self) -> None:
        """Start near identity while giving the edge path a gradient signal."""
        # Exact zero makes the edge path learn only through a very slow
        # second-order effect: the adapter must move first before its input
        # branch receives any useful gradient.  A tiny projection keeps the
        # initial perturbation negligible but makes LEM/SFM trainable from the
        # first iteration.
        self.out_proj.weight.normal_(mean=0.0, std=1e-3)
        self.out_proj.bias.zero_()

    def enforce_sparsity(self) -> None:
        self.edge._enforce_sparsity()
        self._clip_adapter()

    @torch.no_grad()
    def _clip_adapter(self) -> None:
        self.out_proj.weight.clamp_(-_EDGE_ADAPTER_WEIGHT_CLIP,
                                    _EDGE_ADAPTER_WEIGHT_CLIP)
        self.out_proj.bias.clamp_(-_EDGE_ADAPTER_WEIGHT_CLIP,
                                  _EDGE_ADAPTER_WEIGHT_CLIP)

class _SFM(nn.Module):
    """Sobel Fusion Module（论文 3.5：一阶 Sobel 抑制 LEM 引入的噪声）."""

    def __init__(self, channels: int,
                 res_scale_logit_init: float = _DEFAULT_RES_SCALE_LOGIT) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 1)
        self.conv3 = nn.Conv2d(channels, channels, 3, padding=1)
        self.conv3_from_1x1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.edge_x = _SparseEdge(channels, 'x')
        self.edge_y = _SparseEdge(channels, 'y')
        self.fuse = nn.Conv2d(channels * 2, channels, 3, padding=1)
        self.norm = nn.LayerNorm(channels)
        self.out_proj = nn.Conv2d(channels, channels, 1)
        self.res_scale_logit = nn.Parameter(
            torch.tensor(float(res_scale_logit_init)))

    def forward(self, x: Tensor) -> Tensor:
        feat = self.conv1(x)
        edge = self.fuse(torch.cat([self.edge_x(feat), self.edge_y(feat)],
                                   dim=1))
        enhanced = x + self.conv3(x) + self.conv3_from_1x1(feat) + edge
        enhanced = _EDGE_FEATURE_CLIP * torch.tanh(
            enhanced / _EDGE_FEATURE_CLIP)
        enhanced = self.norm(enhanced.permute(0, 2, 3, 1))
        enhanced = enhanced.permute(0, 3, 1, 2).contiguous()
        scale = 0.2 * torch.sigmoid(self.res_scale_logit)
        return x + scale * torch.tanh(self.out_proj(enhanced))

    @torch.no_grad()
    def zero_init_output(self) -> None:
        """Start near identity while giving the edge path a gradient signal."""
        self.out_proj.weight.normal_(mean=0.0, std=1e-3)
        self.out_proj.bias.zero_()

    def enforce_sparsity(self) -> None:
        self.edge_x._enforce_sparsity()
        self.edge_y._enforce_sparsity()
        self._clip_adapter()

    @torch.no_grad()
    def _clip_adapter(self) -> None:
        self.out_proj.weight.clamp_(-_EDGE_ADAPTER_WEIGHT_CLIP,
                                    _EDGE_ADAPTER_WEIGHT_CLIP)
        self.out_proj.bias.clamp_(-_EDGE_ADAPTER_WEIGHT_CLIP,
                                  _EDGE_ADAPTER_WEIGHT_CLIP)


def _group_count(channels: int, preferred: int = 32) -> int:
    """Choose a GroupNorm group count that divides ``channels``."""
    groups = min(preferred, channels)
    while groups > 1 and channels % groups:
        groups -= 1
    return groups


class _SemanticRefine(nn.Module):
    """Low-cost semantic refinement for the deep FPN levels.

    Deep levels already contain the strongest semantic context after the
    top-down fusion.  They therefore use a bottleneck pointwise projection
    and a depthwise 3x3 context filter instead of the expensive LEM/SFM pair.
    The residual scale keeps the initial feature distribution close to FPN.
    """

    def __init__(self, channels: int, reduction: int = 4,
                 res_scale_logit_init: float = _DEFAULT_RES_SCALE_LOGIT) -> None:
        super().__init__()
        hidden = max(32, channels // reduction)
        self.reduce = nn.Conv2d(channels, hidden, 1, bias=False)
        self.norm1 = nn.GroupNorm(_group_count(hidden), hidden)
        self.depthwise = nn.Conv2d(hidden, hidden, 3, padding=1,
                                   groups=hidden, bias=False)
        self.norm2 = nn.GroupNorm(_group_count(hidden), hidden)
        self.expand = nn.Conv2d(hidden, channels, 1, bias=False)
        self.res_scale_logit = nn.Parameter(
            torch.tensor(float(res_scale_logit_init)))

    @torch.no_grad()
    def zero_init_output(self) -> None:
        """Start as an exact identity while keeping the branch trainable."""
        self.expand.weight.zero_()

    def forward(self, x: Tensor) -> Tensor:
        y = F.relu(self.norm1(self.reduce(x)), inplace=True)
        y = F.relu(self.norm2(self.depthwise(y)), inplace=True)
        scale = 0.2 * torch.sigmoid(self.res_scale_logit)
        # Keep the semantic adapter bounded for the same reason as LEM/SFM:
        # a zero-initialized projection can still receive a very large first
        # update on a tiny dataset and then corrupt every FPN level.
        return x + scale * torch.tanh(self.expand(y))

@MODELS.register_module()
class LightLSEFPN(BaseModule):
    """FPN-compatible neck with full edge enhancement on the shallow levels.

    Args:
        in_channels (list[int]): Backbone feature channels.
        out_channels (int): FPN channel width.
        num_outs (int): Number of output levels (extra levels use strided convs).
        start_level (int): First backbone level used as an FPN input.
        end_level (int): Last backbone level used (``-1`` = all).
        add_extra_convs (bool | str): Kept for FPN-config compatibility.
        shallow_levels (int): Number of shallow levels carrying LEM+SFM.
        semantic_reduction (int): Bottleneck ratio for deep semantic levels.
        enable_edge (bool): Enable the shallow LEM+SFM enhancement path.
        enable_semantic (bool): Enable semantic refinement on deep/extra levels.
        res_scale_logit_init (float): Initial logit for all residual gates.
        semantic_res_scale_logit_init (float): Initial logit for semantic gates.
        extra_conv_kernel (int | Sequence[int]): Kernel size(s) for the
            strided extra FPN convolutions. A scalar applies to every
            extra level; a sequence gives one kernel per extra level.
            Defaults to 3, reproducing the original LightLSEFPN exactly.
            Use ``(1, 3)`` to change only the expensive C5->P6 projection
            while keeping the P6->P7 convolution at 3x3.
        init_cfg (dict, optional): MMEngine init config.
    """

    def __init__(self, in_channels: List[int], out_channels: int,
                 num_outs: int, start_level: int = 0, end_level: int = -1,
                 add_extra_convs=False, shallow_levels: int = 2,
                 semantic_reduction: int = 4,
                 enable_edge: bool = True,
                 enable_semantic: bool = True,
                 use_p2_fusion: bool = False,
                 extra_conv_kernel: Union[int, Sequence[int]] = 3,
                 res_scale_logit_init: float = _DEFAULT_RES_SCALE_LOGIT,
                 semantic_res_scale_logit_init: float = _DEFAULT_RES_SCALE_LOGIT,
                 relu_before_extra_convs: bool = False,
                 no_norm_on_lateral: bool = False,
                 conv_cfg=None, norm_cfg=None, act_cfg=None,
                 upsample_cfg: dict = dict(mode='nearest'),
                 init_cfg: dict = dict(type='Xavier', layer='Conv2d',
                                       distribution='uniform'),
                 **kwargs) -> None:
        super().__init__(init_cfg=init_cfg)
        if not isinstance(in_channels, list):
            raise TypeError('in_channels must be a list')
        if not 0 <= start_level < len(in_channels):
            raise ValueError(f'invalid start_level={start_level}')
        if end_level == -1 or end_level == len(in_channels) - 1:
            backbone_end_level = len(in_channels)
        else:
            if not start_level <= end_level < len(in_channels):
                raise ValueError(f'invalid end_level={end_level}')
            backbone_end_level = end_level + 1
        used = backbone_end_level - start_level
        if num_outs < used:
            raise ValueError(f'num_outs ({num_outs}) must be >= used levels ({used})')
        if isinstance(add_extra_convs, bool):
            add_extra_convs = 'on_input' if add_extra_convs else False
        if add_extra_convs not in (False, 'on_input', 'on_lateral', 'on_output'):
            raise ValueError("add_extra_convs must be False, True, 'on_input', "
                             "'on_lateral', or 'on_output'")

        self.in_channels, self.out_channels = in_channels, out_channels
        self.start_level = start_level
        self.backbone_end_level = backbone_end_level
        self.num_outs = num_outs
        self.shallow_levels = max(0, min(int(shallow_levels), used))
        self.enable_edge = bool(enable_edge)
        self.enable_semantic = bool(enable_semantic)
        self.use_p2_fusion = bool(use_p2_fusion)
        if semantic_reduction < 1:
            raise ValueError('semantic_reduction must be >= 1')
        self.semantic_reduction = int(semantic_reduction)
        self.add_extra_convs = add_extra_convs
        self.relu_before_extra_convs = relu_before_extra_convs
        self.upsample_cfg = dict(upsample_cfg)
        self.lateral_convs = nn.ModuleList([
            ConvModule(
                in_channels[i], out_channels, 1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg if not no_norm_on_lateral else None,
                act_cfg=act_cfg,
                inplace=False)
            for i in range(start_level, self.backbone_end_level)])
        self.p2_fusion = (nn.Conv2d(in_channels[0], out_channels, 3,
                                    stride=2, padding=1)
                          if self.use_p2_fusion and start_level > 0
                          else None)
        self.p2_gate = (nn.Parameter(torch.zeros(1))
                        if self.p2_fusion is not None else None)
        self.fpn_convs = nn.ModuleList([
            ConvModule(out_channels, out_channels, 3, padding=1,
                       conv_cfg=conv_cfg, norm_cfg=norm_cfg,
                       act_cfg=act_cfg, inplace=False)
            for _ in range(used)])
        self.lem = nn.ModuleList([
            _LEM(out_channels, res_scale_logit_init)
            if self.enable_edge and i < self.shallow_levels else nn.Identity()
            for i in range(used)])
        self.sfm = nn.ModuleList([
            _SFM(out_channels, res_scale_logit_init)
            if self.enable_edge and i < self.shallow_levels else nn.Identity()
            for i in range(used)])
        self.semantic = nn.ModuleList([
            _SemanticRefine(out_channels, self.semantic_reduction,
                            semantic_res_scale_logit_init)
            if self.enable_semantic and i >= self.shallow_levels
            else nn.Identity()
            for i in range(used)])
        extra = num_outs - used
        if isinstance(extra_conv_kernel, int):
            extra_conv_kernels = [extra_conv_kernel] * extra
        else:
            extra_conv_kernels = list(extra_conv_kernel)
            if len(extra_conv_kernels) != extra:
                raise ValueError(
                    'extra_conv_kernel sequence must have one value per '
                    f'extra level ({extra}), got {len(extra_conv_kernels)}')
        if any(not isinstance(k, int) or k < 1 or k % 2 == 0
               for k in extra_conv_kernels):
            raise ValueError(
                'extra_conv_kernel values must be positive odd integers')
        self.extra_convs = nn.ModuleList()
        self.extra_semantic = nn.ModuleList()
        if add_extra_convs:
            for i in range(extra):
                extra_in = (in_channels[self.backbone_end_level - 1]
                            if i == 0 and add_extra_convs == 'on_input'
                            else out_channels)
                self.extra_convs.append(
                    ConvModule(extra_in, out_channels, extra_conv_kernels[i],
                               stride=2,
                               padding=extra_conv_kernels[i] // 2,
                               conv_cfg=conv_cfg,
                               norm_cfg=norm_cfg, act_cfg=act_cfg,
                               inplace=False))
                # Extra P6/P7 levels also belong to the semantic path; keep
                # them lightweight instead of applying LEM/SFM at low scale.
                self.extra_semantic.append(
                    _SemanticRefine(out_channels, self.semantic_reduction,
                                    semantic_res_scale_logit_init)
                    if self.enable_semantic else nn.Identity())
        elif extra:
            self.extra_semantic = nn.ModuleList([
                _SemanticRefine(out_channels, self.semantic_reduction,
                                semantic_res_scale_logit_init)
                if self.enable_semantic else nn.Identity()
                for _ in range(extra)])

    def init_weights(self) -> None:
        """Run MMEngine initialization, then restore edge kernels."""
        super().init_weights()
        if self.p2_fusion is not None:
            nn.init.zeros_(self.p2_fusion.weight)
            nn.init.zeros_(self.p2_fusion.bias)
        for module in self.modules():
            if isinstance(module, _SparseEdge):
                module.restore_kernel()
            elif isinstance(module, (_LEM, _SFM, _SemanticRefine)):
                # MMEngine initializes Conv2d layers from init_cfg; restore
                # the identity-preserving adapter after that initialization.
                module.zero_init_output()

    @torch.no_grad()
    def enforce_sparsity(self) -> None:
        """Re-zero every frozen position of every sparse edge kernel."""
        for module in self.modules():
            if isinstance(module, _SparseEdge):
                module._enforce_sparsity()
            elif isinstance(module, (_LEM, _SFM)):
                module.enforce_sparsity()

    def forward(self, inputs: Tuple[Tensor, ...]) -> Tuple[Tensor, ...]:
        if len(inputs) != len(self.in_channels):
            raise ValueError(
                f'expected {len(self.in_channels)} inputs, got {len(inputs)}')
        laterals = [conv(inputs[i + self.start_level])
                    for i, conv in enumerate(self.lateral_convs)]
        for i in range(len(laterals) - 1, 0, -1):
            if 'scale_factor' in self.upsample_cfg:
                laterals[i - 1] = laterals[i - 1] + _interp_amp(
                    laterals[i], **self.upsample_cfg)
            else:
                laterals[i - 1] = laterals[i - 1] + _interp_amp(
                    laterals[i], size=laterals[i - 1].shape[-2:],
                    **self.upsample_cfg)
        if self.p2_fusion is not None:
            p2 = self.p2_fusion(inputs[0])
            if p2.shape[-2:] != laterals[0].shape[-2:]:
                p2 = _interp_amp(p2, size=laterals[0].shape[-2:],
                                   mode='nearest')
            laterals[0] = laterals[0] + self.p2_gate * p2
        outs = []
        for i in range(len(laterals)):
            # Keep the ordinary FPN output as the base representation.  The
            # enhancement modules are residual refinements on top of it.
            feat = self.fpn_convs[i](laterals[i])
            if i < self.shallow_levels:
                # Shallow path: preserve the requested LEM -> SFM design.
                feat = self.sfm[i](self.lem[i](feat))
            else:
                # Deep path: semantic bottleneck, without edge branches.
                feat = self.semantic[i](feat)
            outs.append(feat)
        if self.num_outs > len(outs):
            if not self.add_extra_convs:
                for i in range(self.num_outs - len(outs)):
                    pooled = F.max_pool2d(outs[-1], 1, stride=2)
                    outs.append(self.extra_semantic[i](pooled))
            else:
                if self.add_extra_convs == 'on_input':
                    extra_source = inputs[self.backbone_end_level - 1]
                elif self.add_extra_convs == 'on_lateral':
                    extra_source = laterals[-1]
                else:
                    extra_source = outs[-1]
                for i, conv in enumerate(self.extra_convs):
                    if i > 0:
                        extra_source = outs[-1]
                    if self.relu_before_extra_convs:
                        extra_source = F.relu(extra_source)
                    outs.append(self.extra_semantic[i](conv(extra_source)))
        return tuple(outs)

__all__ = ['LightLSEFPN']
