"""Multi-confusion-pair Similar Category Angle (M-SCA) loss and metric.

论文对应关系
------------
=====================================  ==========================================
:func:`calc_pair_sca`                  论文 Algorithm 1 式 (1)-(4)：单对 SCA 角
:func:`calc_msca_metric`               论文式 (5) + 冲突调和系数 Conflict_coef(k)
:class:`ConfusionMatrixMiner`          论文 3.3：CMM 混淆对自动挖掘
:class:`MSCALoss`                      论文 3.6：密度自适应 M-SCA-Loss + 对齐正则
=====================================  ==========================================

两种数据形态（务必区分）
------------------------
* **指标**（:func:`calc_msca_metric`）按论文 Algorithm 1 工作在**整图密集预测分数**
  ``[H*W, C]`` 上：每张图取分数最高的 top-k 个位置、抽取混淆对两列、线性回归求夹角，
  因此**不需要 GT 标签**，只需要每张图的混淆目标实例数 :math:`\\theta_m`（式 (5) 的
  加权系数，同时用于 Algorithm 1 的密度门限）。
* **损失**（:class:`MSCALoss`）工作在**检测头 anchor 级分类分数** ``[N, C]`` 上，
  ``labels`` 为 anchor 的分配标签（背景/ignore 用负值表示），可直接对接 MMRotate 的
  旋转 anchor 检测头。

密度自适应权重 :math:`\\gamma_m`（论文 3.6.1）
--------------------------------------------
.. math::  \\gamma_m = \\min\\left(1, \\frac{N^{conf}_m}{\\delta}\\right)

其中 :math:`N^{conf}_m` 是第 ``m`` 张图中**属于当前激活混淆对的目标实例数**
（GT 目标数，**不是 anchor 数**，也不是候选框数）。检测头通过
``image_confusion_counts`` 传入该统计量；若未传入则退化为 anchor 计数（消融模式，
会明显高估密度，故正式训练必须在 head 中传入 GT 目标数）。

参考文献实现差异（已在代码中标注）
----------------------------------
* 原型 ``density_delta=40``（论文稀疏子集定义为 "混淆目标数 < 40"），本模块默认 40。
* 原型 ``calc_msca_metric`` 把所有图拼成一个大矩阵再回归；论文式 (5) 是**逐图 SCA
  再按** :math:`\\theta_m` 加权平均。二者都保留：``pool='image'``（默认，论文口径）
  与 ``pool='concat'``（原型口径），便于论文中做口径一致性说明。
* 原型 ``L_align`` 用 ``autograd.grad`` 的梯度平方范数，属于工程近似；本模块改为
  **可微 SCA 代理**（对两条回归线夹角直接求导），与 "缩小代理损失-M-SCA 指标鸿沟"
  的目标一致，且不需要 ``create_graph``。
"""

from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Union

import torch
from torch import Tensor, nn
from torch.nn import functional as F

from mmrotate.registry import MODELS

Pair = Tuple[int, int]

# --------------------------------------------------------------------------- #
# 基础工具
# --------------------------------------------------------------------------- #
def active_pairs_from_confusion(confusion: Tensor,
                                totals: Optional[Tensor] = None,
                                threshold: float = 0.05,
                                max_pairs: Optional[int] = None
                                ) -> List[Pair]:
    """Select active confusion pairs from a confusion matrix (论文 3.3).

    Confusion score of a pair ``(i, j)`` is

    .. math::
        s_{ij} = \\frac{M_{ij} + M_{ji}}{T_i + T_j}

    where ``M`` is the (EMA/window) ``gt -> pred`` count matrix and ``T`` the
    per-class total.

    Args:
        confusion (Tensor): ``[C, C]`` confusion counts.
        totals (Tensor, optional): ``[C]`` per-class totals. Defaults to the
            row sums of ``confusion``.
        threshold (float): Activation threshold :math:`\\tau`.
        max_pairs (int, optional): Keep at most this many pairs.

    Returns:
        list[tuple[int, int]]: Active pairs ``(i, j)`` with ``i < j``.
    """
    confusion = confusion.detach().to(torch.float32, copy=True).cpu()
    if totals is None:
        totals = confusion.sum(dim=1)
    else:
        totals = totals.detach().to(torch.float32, copy=True).cpu()
    denom = totals[:, None] + totals[None, :]
    score = (confusion + confusion.t()) / denom.clamp_min(1e-6)
    tri = torch.triu(torch.ones_like(score, dtype=torch.bool), diagonal=1)
    indices = torch.nonzero(tri & (score >= float(threshold)), as_tuple=False)
    if indices.numel() == 0:
        return []
    values = score[indices[:, 0], indices[:, 1]]
    order = values.argsort(descending=True)
    if max_pairs is not None and max_pairs > 0:
        order = order[:int(max_pairs)]
    return [(int(indices[i, 0]), int(indices[i, 1])) for i in order]

def conflict_coefficients(pairs: Sequence[Pair]) -> List[float]:
    """Gradient-conflict harmonisation coefficient (论文 3.2).

    .. math::
        Conflict\\_coef(k) = \\frac{1}{1 + n_k}

    where :math:`n_k` is the number of *other* pairs sharing at least one class
    with pair :math:`P_k`.  Pairs that overlap with many others get a smaller
    weight so that the joint optimisation does not cancel out.

    Args:
        pairs (Sequence[tuple[int, int]]): Active confusion pairs.

    Returns:
        list[float]: One coefficient per pair, in the same order.
    """
    pairs = [tuple(int(c) for c in p) for p in pairs]
    coefs: List[float] = []
    for i, pk in enumerate(pairs):
        shared = set(pk)
        count = 0
        for j, pj in enumerate(pairs):
            if i == j:
                continue
            if shared & set(pj):
                count += 1
        coefs.append(1.0 / (1.0 + count))
    return coefs

def _pair_slopes(scores: Tensor, eps: float = 1e-8) -> Optional[Tensor]:
    """Slopes of the two temporary-label regression lines (式 (2)-(3)).

    Args:
        scores (Tensor): ``[N, 2]`` scores of one class pair.

    Returns:
        Tensor | None: ``[k_l, k_c]`` or ``None`` when the regression is
        ill-defined (fewer than two samples in a temporary set / zero variance).
    """
    # 式 (1): temporary label by comparing the two scores.
    temp = (scores[:, 0] > scores[:, 1]).to(torch.long)
    slopes = []
    for group in (0, 1):
        sample = scores[temp == group]
        if sample.size(0) < 2:
            return None
        x, y = sample[:, 0], sample[:, 1]
        dx, dy = x - x.mean(), y - y.mean()
        var = dx.square().sum()
        if float(var.detach()) <= eps:
            return None
        slopes.append((dx * dy).sum() / var)
    return torch.stack(slopes)

def calc_pair_sca(scores: Tensor,
                  topk: Optional[int] = None,
                  eps: float = 1e-8) -> Tensor:
    """SCA angle (degree) of one class pair (论文 Algorithm 1, 式 (1)-(4)).

    Args:
        scores (Tensor): ``[N, 2]`` score matrix of the pair, columns ordered as
            ``(c1, c2)``.
        topk (int, optional): Keep the ``topk`` rows with the largest
            ``max(score)`` first.  This mirrors the paper's "top-2000 highest
            scoring samples" (Algorithm 1, step 3-4), which selects *positions
            of the image*, not per-column maxima.
        eps (float): Numerical floor.

    Returns:
        Tensor: Scalar SCA angle in ``[0, 90]`` degrees.  ``0.`` when the angle
        is undefined (a temporary set has fewer than two samples, or one of the
        regressions has zero variance).
    """
    if scores.ndim != 2 or scores.size(1) != 2:
        raise ValueError(f'scores must be [N,2], got {tuple(scores.shape)}')
    scores = scores.detach().to(torch.float32)
    zero = scores.new_tensor(0.)
    if scores.size(0) < 2:
        return zero
    if topk is not None and 0 < int(topk) < scores.size(0):
        keep = scores.max(dim=1).values.topk(int(topk)).indices
        scores = scores[keep]
    slopes = _pair_slopes(scores, eps=eps)
    if slopes is None:
        return zero
    k_l, k_c = slopes
    # 式 (4): SCA = arctan(|k_c - k_l| / (1 + k_l * k_c))，用 atan2 等价实现，
    # 天然落在 [0, 90°] 且不会出现除零。
    return torch.rad2deg(
        torch.atan2((k_c - k_l).abs(), (1. + k_l * k_c).abs().clamp_min(eps)))

def calc_pair_sca_from_anchors(scores: Tensor,
                               labels: Tensor,
                               pair: Pair,
                               topk: int = 2000) -> Tensor:
    """Anchor-level variant of :func:`calc_pair_sca` (training diagnostic).

    Only anchors whose assigned ground-truth class is one of the pair classes
    are kept.  The reported dataset metric should use
    :func:`calc_msca_metric`, which follows Algorithm 1 and selects the top-k
    positions of the whole image.

    Args:
        scores (Tensor): ``[N, C]`` class scores (probabilities or logits).
        labels (Tensor): ``[N]`` anchor labels, ``< 0`` for background/ignore.
        pair (tuple[int, int]): Class pair.
        topk (int): Number of highest scoring anchors kept.

    Returns:
        Tensor: Scalar SCA angle in degrees.
    """
    if scores.ndim != 2:
        raise ValueError(f'scores must be [N,C], got {tuple(scores.shape)}')
    if labels.ndim != 1 or labels.numel() != scores.size(0):
        raise ValueError('labels must be [N] and match scores')
    a, b = int(pair[0]), int(pair[1])
    if a == b or min(a, b) < 0 or max(a, b) >= scores.size(1):
        return scores.new_tensor(0.)
    valid = (labels == a) | (labels == b)
    if not valid.any():
        return scores.new_tensor(0.)
    return calc_pair_sca(scores[valid][:, [a, b]], topk=topk)

def calc_msca_metric(image_scores: Sequence[Tensor],
                     confusion_pairs: Sequence[Pair],
                     image_confusion_counts: Optional[Sequence] = None,
                     topk: int = 2000,
                     density_threshold: float = 0.0,
                     conflict_weight: bool = True,
                     pool: str = 'image',
                     eps: float = 1e-8
                     ) -> Tuple[Tensor, Dict[Pair, float]]:
    """M-SCA metric: 论文 Algorithm 1 + 式 (5) + 梯度冲突调和.

    Args:
        image_scores (Sequence[Tensor]): Per-image dense prediction scores with
            shape ``[H*W, C]`` (**sigmoid/softmax 概率**, not logits; the
            caller applies the activation matching the detection head).
        confusion_pairs (Sequence[tuple[int, int]]): Active confusion pairs from
            the CMM (or from manual priors).
        image_confusion_counts (Sequence, optional): :math:`\\theta_m`, the
            number of confusing-category objects in image ``m`` (式 (5) 的权重,
            同时用于 Algorithm 1 的密度门限).  ``None`` means "count every
            image once".
        topk (int): Number of highest scoring positions per image (paper: 2000).
        density_threshold (float): Algorithm 1 的 :math:`\\theta`：混淆目标数少
            于该值的图像不参与指标计算。论文默认值按数据集设置（SODA-A 为 70）。
            ``0`` 表示全部图像参与（测量稀疏混淆场景时必须设为 0）。
        conflict_weight (bool): Apply :math:`Conflict\\_coef(k)`.  ``False``
            reproduces the original single-pair aSCA averaging.
        pool (str): ``'image'`` = 逐图 SCA 后按 :math:`\\theta_m` 加权（论文式
            (5)，默认）；``'concat'`` = 先拼接全部图的 top-k 再回归一次（原型
            工程实现口径）。
        eps (float): Numerical floor.

    Returns:
        tuple: ``(msca, per_pair)`` where ``msca`` is a scalar tensor and
        ``per_pair`` maps each pair to its (weighted) SCA value in degrees.
    """
    if pool not in ('image', 'concat'):
        raise ValueError(f"pool must be 'image' or 'concat', got {pool}")
    pairs = [(int(p[0]), int(p[1])) for p in confusion_pairs]
    per_pair: Dict[Pair, float] = {}
    # 返回值必须和输入分数同设备：训练期这个 metric 会被当作 tensor 记录进日志
    # （MSCALoss 里还会 `.to(logits.device)`），若这里硬编码 CPU 张量，在 GPU /
    # MPS 上就会报 "found at least two devices"。
    device = (image_scores[0].device if len(image_scores) else
              torch.device('cpu'))
    if not pairs:
        return torch.zeros((), device=device), per_pair
    coefs = conflict_coefficients(pairs) if conflict_weight else [1.] * len(pairs)

    pair_weight: Dict[Pair, float] = {}
    for pair, coef in zip(pairs, coefs):
        c1, c2 = pair
        num_mass, scas, weights = 0., [], []
        for img_idx, score_map in enumerate(image_scores):
            count = (1. if image_confusion_counts is None else
                     float(image_confusion_counts[img_idx]))
            if count <= 0 or count < float(density_threshold):
                continue
            scores = score_map.detach().reshape(-1, score_map.size(-1))
            if max(c1, c2) >= scores.size(1):
                continue
            pair_scores = scores[:, [c1, c2]].to(torch.float32)
            if pair_scores.size(0) < 2:
                continue
            if pool == 'image':
                # 论文式 (5)：逐图算 SCA_i，再按 θ_i 加权平均。
                scas.append(calc_pair_sca(pair_scores, topk=topk, eps=eps))
                weights.append(count)
                num_mass += count
            else:
                # 原型口径：先逐列取 top-k，再全数据集拼接回归一次。
                k = min(int(topk), pair_scores.size(0))
                scas.append(pair_scores.topk(k, dim=0).values)
                num_mass += count
        if pool == 'concat' and scas:
            per_pair[pair] = float(calc_pair_sca(torch.cat(scas, 0), topk=topk,
                                                 eps=eps))
        elif pool == 'image' and scas:
            v = torch.stack(scas)
            # 权重张量必须和 ``v`` 同设备，否则 GPU/MPS 上会报混合设备错误。
            w = torch.tensor(weights, dtype=torch.float32, device=v.device)
            per_pair[pair] = float((w * v).sum() / w.sum().clamp_min(eps))
        else:
            per_pair[pair] = 0.
        pair_weight[pair] = num_mass * float(coef)

    total_weight = sum(pair_weight.values())
    if total_weight <= 0:
        return torch.zeros((), device=device), per_pair
    value = sum(w * per_pair[p] for p, w in pair_weight.items()) / total_weight
    return torch.tensor(value, dtype=torch.float32, device=device), per_pair

# --------------------------------------------------------------------------- #
# CMM：混淆对自动挖掘（论文 3.3）
# --------------------------------------------------------------------------- #
@MODELS.register_module()
class ConfusionMatrixMiner(nn.Module):
    """CMM: on-line confusion-pair miner (论文 3.3).

    The matrix counts ``ground-truth class -> predicted class`` on the positive
    anchors of the detector.  Two update modes are provided:

    * ``mode='window'``：滑动窗口（论文图 3）—— 统计最近 ``window_size`` 个
      batch 的混淆矩阵；
    * ``mode='ema'``：指数滑动平均（工程默认，显存恒定）。

    混淆矩阵与类别计数以 buffer 形式保存在 checkpoint 中，因此评估阶段可以用
    与训练**完全一致**的混淆对集合复现 M-SCA 指标。
    """

    def __init__(self,
                 num_classes: int,
                 threshold: float = 0.05,
                 momentum: float = 0.9,
                 warmup_epochs: int = 1,
                 max_pairs: Optional[int] = 16,
                 mode: str = 'ema',
                 window_size: int = 8,
                 fixed_pairs: Optional[Sequence[Pair]] = None,
                 memory_enabled: bool = False,
                 memory_decay: float = 0.95,
                 memory_min_support: int = 2,
                 memory_max_age: int = 64) -> None:
        super().__init__()
        if num_classes < 2:
            raise ValueError('num_classes must be at least 2')
        if mode not in ('ema', 'window', 'fixed'):
            raise ValueError(f"mode must be 'ema', 'window' or 'fixed', got {mode}")
        self.num_classes = int(num_classes)
        self.threshold = float(threshold)
        self.momentum = float(momentum)
        self.warmup_epochs = int(warmup_epochs)
        self.max_pairs = max_pairs
        self.mode = mode
        self.window_size = int(window_size)
        self.fixed_pairs = [tuple(map(int, p)) for p in (fixed_pairs or [])]
        self.memory_enabled = bool(memory_enabled)
        self.memory_decay = float(memory_decay)
        self.memory_min_support = int(memory_min_support)
        self.memory_max_age = int(memory_max_age)
        if not 0.0 < self.memory_decay <= 1.0:
            raise ValueError('memory_decay must be in (0, 1]')
        self.register_buffer('confusion', torch.zeros(num_classes, num_classes))
        self.register_buffer('totals', torch.zeros(num_classes))
        # Pair-level memory is deliberately separate from the normal window:
        # a pair observed in a sparse batch can survive later batches with no
        # member of either class.  This is the replacement for the ineffective
        # density-delta sweep; it changes pair availability, not a normalised
        # scalar weight.
        self.register_buffer('memory_scores', torch.zeros(num_classes, num_classes))
        self.register_buffer('memory_support', torch.zeros(num_classes, num_classes))
        self.register_buffer('memory_age', torch.zeros(num_classes, num_classes))
        #: sliding window of per-batch matrices (not part of the checkpoint)
        self._queue: List[Tensor] = []
        self.current_epoch = 0
        self.last_pair_sources: Dict[str, int] = {
            'current': 0, 'history': 0, 'empty': 0}

    def set_epoch(self, epoch: int) -> None:
        self.current_epoch = int(epoch)

    @torch.no_grad()
    def update(self, logits: Tensor, labels: Tensor) -> None:
        """Accumulate one batch of predictions.

        Args:
            logits (Tensor): ``[N, C]`` classification scores (logits or
                probabilities, only ``argmax`` is used).
            labels (Tensor): ``[N]`` anchor labels, ``< 0`` for background /
                ignore.
        """
        if not self.training or logits.numel() == 0:
            return
        labels = labels.reshape(-1).to(logits.device, torch.long)
        pred = logits.detach().argmax(dim=-1).reshape(-1)
        valid = (labels >= 0) & (labels < self.num_classes)
        if not valid.any():
            return
        labels, pred = labels[valid], pred[valid].clamp(0, self.num_classes - 1)
        counts = torch.zeros_like(self.confusion)
        flat = labels * self.num_classes + pred
        counts.view(-1).index_add_(
            0, flat, torch.ones_like(flat, dtype=counts.dtype))
        totals = torch.bincount(labels, minlength=self.num_classes).to(counts)
        # Keep statistics consistent under DDP. No-op in single-process runs.
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            torch.distributed.all_reduce(counts)
            torch.distributed.all_reduce(totals)
        if self.mode == 'window':
            self._queue.append(counts)
            if len(self._queue) > self.window_size:
                self._queue = self._queue[-self.window_size:]
            self.confusion.copy_(
                torch.stack(self._queue, dim=0).sum(dim=0))
            self.totals.copy_(self.confusion.sum(dim=1))
        else:
            self.confusion.mul_(self.momentum).add_(counts,
                                                    alpha=1. - self.momentum)
            self.totals.mul_(self.momentum).add_(totals, alpha=1. - self.momentum)
        if self.memory_enabled:
            denom = totals[:, None] + totals[None, :]
            score = ((counts + counts.t()) / denom.clamp_min(1e-6)).triu(1)
            self.memory_scores.mul_(self.memory_decay)
            self.memory_scores.copy_(torch.maximum(self.memory_scores, score))
            self.memory_support.add_((score >= self.threshold).to(self.memory_support))
            self.memory_age.add_(1.)
            self.memory_age.masked_fill_(score >= self.threshold, 0.)

    @torch.no_grad()
    def active_pairs(self) -> List[Pair]:
        """Active pairs; empty during the warm-up epochs (论文 3.3)."""
        if self.current_epoch < self.warmup_epochs:
            return []
        if self.mode == 'fixed':
            return list(self.fixed_pairs[:self.max_pairs] if self.max_pairs else
                        self.fixed_pairs)
        current = active_pairs_from_confusion(self.confusion, self.totals,
                                               self.threshold, None)
        if not self.memory_enabled:
            self.last_pair_sources = {
                'current': len(current), 'history': 0, 'empty': int(not current)}
            return (current[:self.max_pairs] if self.max_pairs else current)
        scores = {}
        source = {}
        denom = self.totals[:, None] + self.totals[None, :]
        current_score = ((self.confusion + self.confusion.t()) /
                         denom.clamp_min(1e-6)).triu(1)
        for pair in current:
            scores[pair] = float(current_score[pair[0], pair[1]])
            source[pair] = 'current'
        tri = torch.triu(self.memory_scores, diagonal=1)
        inds = torch.nonzero(
            (tri >= self.threshold) &
            (self.memory_support >= self.memory_min_support) &
            (self.memory_age <= self.memory_max_age), as_tuple=False)
        for i, j in inds:
            pair = (int(i), int(j))
            scores[pair] = max(scores.get(pair, 0.), float(tri[pair[0], pair[1]]))
            source.setdefault(pair, 'history')
        out = sorted(scores, key=lambda p: scores[p], reverse=True)
        self.last_pair_sources = {
            'current': sum(source[p] == 'current' for p in out),
            'history': sum(source[p] == 'history' for p in out),
            'empty': int(not out),
        }
        return out[:self.max_pairs] if self.max_pairs else out

# --------------------------------------------------------------------------- #
# 密度自适应 M-SCA-Loss（论文 3.6）
# --------------------------------------------------------------------------- #
@MODELS.register_module()
class MSCALoss(nn.Module):
    """Density-adaptive M-SCA loss + metric-alignment regulariser (论文 3.6).

    训练目标（每个 batch，:math:`\\lambda_3` = ``loss_weight``，
    :math:`\\lambda_4` = ``lambda_align``）::

        L = lambda3 * sum_{b,k} w_bk * (L_proxy(b,k) + lambda4 * L_align(b,k))
                       / sum_{b,k} w_bk

        w_bk = gamma_b * Conflict_coef(k),
        gamma_b = min(1, N_conf(b) / delta)

    * ``L_proxy``                  = 原 SCA-Loss 式 (6)：
      :math:`w_i (1 - cos(s_i, t_i)) (1 - \\|s_i\\|)`，``t_i`` 为 one-hot 目标
      （全零 = 负样本，权重 ``neg_weight``）；
    * ``L_align``                  = 可微 SCA 代理（两条回归线夹角），用于弥合
      代理损失与不可微 M-SCA 指标之间的鸿沟；
    * :math:`\\gamma_b`            = 密度自适应权重，``N_conf(b)`` 为第 ``b`` 张图中
      **属于当前激活混淆对的目标实例数**（GT 目标数，非 anchor 数）。

    Args:
        density_delta (float): :math:`\\delta`，密度阈值（论文/原型 40，即稀疏场景
            定义 "混淆目标数 < 40"）。
        loss_weight (float): :math:`\\lambda_3`.
        lambda_align (float): :math:`\\lambda_4`.
        topk (int): 指标计算时每张图保留的样本数（诊断用）。
        use_conflict_weight (bool): 是否使用梯度冲突调和系数。
        pos_weight (float): 式 (6) 的 ``w_pos``.
        neg_weight (float): 式 (6) 的 ``w_neg``.
        score_act (str): ``'sigmoid'``（FocalLoss/anchor 检测头）或 ``'none'``。
        align_mode (str): ``'sca'``（可微 SCA 代理，默认）或 ``'cosine'``。
        eps (float): 数值下限。
    """

    def __init__(self,
                 density_delta: float = 40.0,
                 loss_weight: float = 0.1,
                 lambda_align: float = 0.05,
                 topk: int = 2000,
                 use_conflict_weight: bool = True,
                 pos_weight: float = 0.9,
                 neg_weight: float = 0.1,
                 score_act: str = 'sigmoid',
                 align_mode: str = 'sca',
                 eps: float = 1e-6) -> None:
        super().__init__()
        if density_delta <= 0:
            raise ValueError('density_delta must be positive')
        if score_act not in ('sigmoid', 'none'):
            raise ValueError(f"unsupported score_act '{score_act}'")
        if align_mode not in ('sca', 'cosine'):
            raise ValueError(f"unsupported align_mode '{align_mode}'")
        self.density_delta = float(density_delta)
        self.loss_weight = float(loss_weight)
        self.lambda_align = float(lambda_align)
        self.topk = int(topk)
        self.use_conflict_weight = bool(use_conflict_weight)
        self.pos_weight = float(pos_weight)
        self.neg_weight = float(neg_weight)
        self.score_act = score_act
        self.align_mode = align_mode
        self.eps = float(eps)
        #: last forward statistics, for logging / debugging
        self.last_stats: Dict[str, Union[int, float, list]] = {}

    # ------------------------------------------------------------------ #
    # loss terms
    # ------------------------------------------------------------------ #
    def _act(self, logits: Tensor) -> Tensor:
        if self.score_act == 'sigmoid':
            return logits.sigmoid()
        return logits

    def _proxy_pair(self, logits: Tensor, labels: Tensor, pair: Pair) -> Tensor:
        """SCA-Loss 式 (6) of one class pair over all anchors of one image."""
        a, b = pair
        if labels.numel() == 0:
            return logits.sum() * 0.
        scores = self._act(logits)[:, [a, b]]
        target = F.one_hot((labels == b).to(torch.long), 2).to(scores)
        positive = (labels == a) | (labels == b)
        target = target * positive.unsqueeze(-1)
        weight = torch.where(positive,
                             torch.full_like(scores[:, 0], self.pos_weight),
                             torch.full_like(scores[:, 0], self.neg_weight))
        # 式 (7)：cosine similarity；全零目标向量的相似度定义为 0。
        t_norm = target.norm(dim=-1)
        sim = (scores * target).sum(dim=-1) / (
            scores.norm(dim=-1).clamp_min(self.eps) * t_norm.clamp_min(self.eps))
        sim = sim * (t_norm > 0).to(sim)
        # 式 (6)：w_i * (1 - similarity) * (1 - ||s_i||)
        return (weight * (1. - sim) * (1. - scores.norm(dim=-1))).mean()

    def _align_pair(self, logits: Tensor, labels: Tensor, pair: Pair) -> Tensor:
        """Differentiable surrogate of the (non-differentiable) SCA angle."""
        a, b = pair
        if self.align_mode == 'cosine':
            mask = (labels == a) | (labels == b)
            if mask.sum() < 2:
                return logits.sum() * 0.
            pair_prob = self._act(logits[mask])[:, [a, b]]
            target = F.one_hot((labels[mask] == b).to(torch.long), 2).to(
                pair_prob)
            cosine = F.cosine_similarity(pair_prob, target, dim=-1).clamp(
                -1., 1.)
            return (1. - cosine).mean()
        # 'sca': 直接对式 (1)-(4) 的夹角求导。
        mask = (labels == a) | (labels == b)
        if mask.sum() < 4:
            return logits.sum() * 0.
        scores = self._act(logits[mask])[:, [a, b]]
        temp = (scores[:, 0] > scores[:, 1]).to(torch.long)
        if temp.sum() < 2 or (1 - temp).sum() < 2:
            return logits.sum() * 0.
        slopes = []
        for group in (0, 1):
            sample = scores[temp == group]
            dx = sample[:, 0] - sample[:, 0].mean()
            var = dx.square().sum()
            if float(var.detach()) <= self.eps:
                return logits.sum() * 0.
            slopes.append((dx * (sample[:, 1] - sample[:, 1].mean())).sum()
                          / var.clamp_min(self.eps))
        k_l, k_c = slopes
        angle = torch.atan2((k_c - k_l).abs(),
                            (1. + k_l * k_c).abs().clamp_min(self.eps))
        # 夹角越接近 90°（M-SCA 越大）损失越小。
        return (0.5 * torch.pi - angle) / (0.5 * torch.pi)

    # ------------------------------------------------------------------ #
    # helpers
    # ------------------------------------------------------------------ #
    def _filter_pairs(self, pairs: Sequence[Pair], labels: Tensor,
                      num_classes: int) -> List[Pair]:
        active: List[Pair] = []
        for pair in pairs or []:
            a, b = int(pair[0]), int(pair[1])
            if a == b or not (0 <= a < num_classes and 0 <= b < num_classes):
                continue
            if ((labels == a) | (labels == b)).sum().item() > 0:
                if (a, b) not in active:
                    active.append((a, b))
        return active

    def _image_slices(self, image_index: Optional[Tensor],
                      num_anchors: int, device) -> List[Tuple[int, Tensor]]:
        if image_index is None:
            return [(0, torch.arange(num_anchors, device=device))]
        image_index = image_index.reshape(-1).to(device=device, dtype=torch.long)
        slices = []
        for img_id in torch.unique(image_index).tolist():
            slices.append((int(img_id),
                           (image_index == img_id).nonzero(
                               as_tuple=False).reshape(-1)))
        return slices

    def _density_weight(self, img_id: int, count: Optional[float],
                        num_labelled_anchors: int) -> float:
        """gamma_m = min(1, N_conf / delta)（论文 3.6.1）."""
        if count is None:
            # 未提供逐图目标统计时退化为 anchor 计数。anchor 数远大于目标数，
            # gamma 会迅速饱和到 1，因此该模式只用于消融/自检。
            count = float(num_labelled_anchors)
        return min(1.0, max(0.0, float(count)) / self.density_delta)

    # ------------------------------------------------------------------ #
    # forward
    # ------------------------------------------------------------------ #
    def forward(self,
                logits: Tensor,
                labels: Tensor,
                pairs: Optional[Sequence[Pair]] = None,
                image_index: Optional[Tensor] = None,
                image_confusion_counts: Optional[Sequence] = None,
                image_scores: Optional[Sequence[Tensor]] = None,
                return_metric: bool = False):
        """Compute the density-adaptive M-SCA loss.

        Args:
            logits (Tensor): ``[N, C]`` anchor classification scores.
            labels (Tensor): ``[N]`` anchor labels (``< 0`` for bg/ignore).
            pairs (Sequence[tuple[int, int]], optional): Active confusion pairs.
            image_index (Tensor, optional): ``[N]`` image id of each anchor.
                Defaults to a single image.
            image_confusion_counts (Sequence, optional): :math:`N^{conf}` per
                image, i.e. the number of ground-truth objects belonging to the
                active confusion pairs.  **Required for the paper-faithful
                density weight.**
            image_scores (Sequence[Tensor], optional): Per-image dense scores
                used by the reported M-SCA metric when ``return_metric=True``.
            return_metric (bool): Also return the M-SCA value.

        Returns:
            Tensor | tuple: The weighted loss, optionally with the M-SCA metric.
        """
        if logits.ndim != 2 or labels.ndim != 1:
            raise ValueError('MSCALoss expects logits [N,C] and labels [N]')
        if logits.size(0) != labels.numel():
            raise ValueError('logits and labels must have the same length')
        labels = labels.to(device=logits.device, dtype=torch.long)
        zero = logits.sum() * 0.
        active = self._filter_pairs(pairs or [], labels, logits.size(1))
        if not active:
            self.last_stats = dict(num_pairs=0, gamma_mean=0., gamma_min=0.,
                                   gamma_max=0., active_pairs=[], proxy=0.,
                                   align=0.)
            if return_metric:
                return zero, logits.new_tensor(0.)
            return zero
        coefs = (conflict_coefficients(active) if self.use_conflict_weight
                 else [1.] * len(active))
        slices = self._image_slices(image_index, logits.size(0), logits.device)

        acc_proxy, acc_align, acc_weight = 0., 0., 0.
        gammas: List[float] = []
        for img_id, idx in slices:
            if idx.numel() == 0:
                continue
            img_logits, img_labels = logits[idx], labels[idx]
            if image_confusion_counts is not None and img_id < len(
                    image_confusion_counts):
                count = float(image_confusion_counts[img_id])
            else:
                count = None
            # A pair may be absent from an image.
            img_pairs = [(p, c) for p, c in zip(active, coefs)
                         if ((img_labels == p[0]) | (img_labels == p[1])).any()]
            labelled = int(((img_labels >= 0) & (img_labels < logits.size(1))
                            ).sum().item())
            gamma = self._density_weight(img_id, count, labelled)
            if gamma <= 0.:
                continue
            gammas.append(gamma)
            for pair, coef in img_pairs:
                weight = gamma * coef
                acc_proxy = acc_proxy + weight * self._proxy_pair(
                    img_logits, img_labels, pair)
                if self.lambda_align > 0:
                    acc_align = acc_align + weight * self._align_pair(
                        img_logits, img_labels, pair)
                acc_weight += weight
        if acc_weight <= 0.:
            self.last_stats = dict(num_pairs=len(active), gamma_mean=0.,
                                   gamma_min=0., gamma_max=0.,
                                   active_pairs=[list(p) for p in active],
                                   proxy=0., align=0.)
            if return_metric:
                return zero, logits.new_tensor(0.)
            return zero
        proxy = acc_proxy / acc_weight
        align = acc_align / acc_weight
        loss = self.loss_weight * (proxy + self.lambda_align * align)
        self.last_stats = dict(
            num_pairs=len(active),
            gamma_mean=sum(gammas) / len(gammas) if gammas else 0.,
            gamma_min=min(gammas) if gammas else 0.,
            gamma_max=max(gammas) if gammas else 0.,
            active_pairs=[list(p) for p in active],
            proxy=float(proxy.detach()),
            align=float(align.detach()))
        if return_metric:
            if image_scores is None:
                image_scores = [logits[idx].detach() for _, idx in slices]
            metric, _ = calc_msca_metric(image_scores, active,
                                         image_confusion_counts,
                                         topk=self.topk)
            return loss, metric.to(logits.device)
        return loss

__all__ = [
    'ConfusionMatrixMiner', 'MSCALoss', 'active_pairs_from_confusion',
    'conflict_coefficients', 'calc_pair_sca', 'calc_pair_sca_from_anchors',
    'calc_msca_metric'
]
