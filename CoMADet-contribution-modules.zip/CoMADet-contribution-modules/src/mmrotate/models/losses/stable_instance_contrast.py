"""Numerical and batch-sampling helpers for the isolated IC2 candidate.

Supervised contrast follows Khosla et al., NeurIPS 2020. This adds no memory
bank, teacher, ranking objective or inference operation.
"""
import math
from types import SimpleNamespace

import torch


def stable_supcon_loss(embeddings, labels, temperature=.1, num_classes=None,
                       confusion=None, totals=None, confusion_beta=0.0,
                       hard_pairs=None, hard_pair_budget=0.0):
    """FP32 masked logsumexp; exclude anchors missing real positives/negatives.

    Inputs are L2-normalized embeddings. Invalid/background labels never enter
    the denominator. Cross-scale same-instance views can be positives, while
    another class must be present for class-discriminative supervision.

    Two mutually exclusive ways to steer the negatives:

    ``confusion_beta`` (dynamic; **rejected by experiment**)
        Re-weights every negative by the *current* CMM confusion rate. That
        closes a feedback loop -- predictions move the weights, which move the
        predictions -- and it measured -0.0008 at beta=1. Kept only so the
        negative result stays reproducible.

    ``hard_pairs`` (static; the surviving design)
        A fixed ``[C, C]`` boolean mask of class pairs that the *baseline*
        model confused, computed once offline on a calibration split. A
        negative whose (anchor class, negative class) is in the mask gets extra
        weight, and every other negative is down-weighted so the total negative
        weight is unchanged. ``hard_pair_budget`` is the share of the total
        negative weight handed to the hard pairs (0.25 = 25 %), so the overall
        loss scale does not move and only the *relative allocation* between
        class pairs changes. The mask never updates during training, which is
        what keeps the effect attributable.

    Setting both ``confusion_beta > 0`` and ``hard_pairs`` raises: they answer
    the same question in incompatible ways.
    """
    if not math.isfinite(float(temperature)) or temperature <= 0:
        raise ValueError('temperature must be finite and positive')
    if embeddings.ndim != 2 or labels.ndim != 1 or len(labels) != len(embeddings):
        raise ValueError('require embeddings[N,D] and aligned labels[N]')
    labels = labels.to(device=embeddings.device, dtype=torch.long)
    keep = labels >= 0
    if num_classes is not None:
        keep &= labels < int(num_classes)
    z, labels = embeddings[keep].float(), labels[keep]
    zero = embeddings.float().sum() * 0.
    if len(z) < 2:
        return zero
    self_mask = torch.eye(len(z), dtype=torch.bool, device=z.device)
    positives = (labels[:, None] == labels[None, :]) & ~self_mask
    negatives = labels[:, None] != labels[None, :]
    positive_counts = positives.sum(1)
    valid = (positive_counts > 0) & negatives.any(1)
    if not bool(valid.any()):
        return zero
    # .float() alone does not protect matmul from an outer AMP context.
    with torch.autocast(device_type=z.device.type, enabled=False):
        scores = z @ z.t() / float(temperature)
        weighted_scores = scores
        beta = float(confusion_beta)
        if beta > 0.0 and confusion is not None and totals is not None:
            matrix = confusion.detach().to(device=z.device, dtype=torch.float32)
            class_totals = totals.detach().to(device=z.device, dtype=torch.float32)
            if (matrix.ndim != 2 or matrix.size(0) != matrix.size(1)
                    or class_totals.ndim != 1
                    or class_totals.numel() != matrix.size(0)):
                raise ValueError('confusion/totals must have compatible shapes')
            if matrix.size(0) <= int(labels.max().item()):
                raise ValueError('confusion matrix is smaller than labels')
            # CMM stores ground-truth -> predicted counts. Only negative
            # classes receive a weight; positives remain unchanged.
            rates = (matrix / class_totals[:, None].clamp_min(1e-6)).clamp(0., 1.)
            pair_rates = rates[labels][:, labels]
            weights = 1.0 + beta * pair_rates
            weights = torch.where(negatives, weights,
                                  torch.ones_like(weights))
            weighted_scores = scores + torch.log(weights.clamp_min(1e-6))

        budget = float(hard_pair_budget)
        if hard_pairs is not None and budget < 0.0:
            raise ValueError('hard_pair_budget must be >= 0')
        if hard_pairs is not None and budget > 0.0:
            if beta > 0.0:
                raise ValueError(
                    'hard_pairs and confusion_beta are alternative designs; '
                    'enable only one of them')
            if not 0.0 < budget < 1.0:
                raise ValueError('hard_pair_budget must be in (0, 1)')
            mask = hard_pairs.to(device=z.device, dtype=torch.bool)
            if mask.ndim != 2 or mask.size(0) != mask.size(1):
                raise ValueError('hard_pairs must be a square [C, C] mask')
            if mask.size(0) <= int(labels.max().item()):
                raise ValueError('hard_pairs is smaller than the label range')
            is_hard = mask[labels][:, labels] & negatives
            hard_count = is_hard.sum()
            neg_count = negatives.sum()
            if bool(is_hard.any()) and int(hard_count) < int(neg_count):
                # Hand `budget` of the total negative weight to the hard pairs
                # and the rest to the others. Because
                #   f*w_h + (1-f)*w_n = budget + (1-budget) = 1
                # the mean negative weight stays 1, so the loss scale is
                # untouched and only the allocation changes.
                fraction = hard_count.to(scores.dtype) / neg_count.to(scores.dtype)
                w_hard = budget / fraction
                w_other = (1.0 - budget) / (1.0 - fraction)
                weights = torch.where(
                    is_hard, w_hard,
                    torch.where(negatives, w_other, torch.ones_like(scores)))
                weighted_scores = scores + torch.log(weights.clamp_min(1e-6))
        denominator = torch.logsumexp(
            weighted_scores.masked_fill(self_mask, -torch.inf), 1)
        log_probability = scores - denominator[:, None]
        # where avoids 0 * (-inf), unlike multiplying a positive mask.
        selected = torch.where(positives, log_probability,
                               torch.zeros_like(log_probability))
        return -(selected.sum(1)[valid] / positive_counts[valid]).mean()


def cap_gt_batch(samples, max_per_class, num_classes):
    """Sample valid GTs globally across a batch, preserving image/box identity.

    Returns lightweight instance containers for RoI pooling only; it never
    edits the detector's original GT assignment or detection targets.
    """
    if int(max_per_class) <= 0:
        raise ValueError('IC2 requires a positive batch-level class cap')
    resolved, refs = [], []
    for image, sample in enumerate(samples):
        if isinstance(sample, dict):
            sample = sample.get('gt_instances', sample)
        else:
            sample = getattr(sample, 'gt_instances', sample)
        boxes = sample.get('bboxes') if isinstance(sample, dict) else getattr(sample, 'bboxes', None)
        labels = sample.get('labels') if isinstance(sample, dict) else getattr(sample, 'labels', None)
        if boxes is None or labels is None:
            resolved.append(None)
            continue
        boxes = boxes.tensor if hasattr(boxes, 'tensor') else boxes
        labels = labels.to(device=boxes.device, dtype=torch.long)
        if boxes.ndim != 2 or boxes.shape[1] != 5 or len(boxes) != len(labels):
            raise ValueError('IC2 requires aligned rotated GT boxes[N,5]/labels[N]')
        valid = ((labels >= 0) & (labels < int(num_classes))
                 & torch.isfinite(boxes).all(1) & (boxes[:, 2:4] > 0).all(1))
        indices = valid.nonzero(as_tuple=False).flatten()
        resolved.append((boxes, labels))
        if len(indices):
            refs.append(torch.stack([indices.new_full(indices.shape, image),
                                     indices, labels[indices]], 1))
    if not refs:
        return [None for _ in samples]
    refs = torch.cat(refs)
    selected = []
    for label in refs[:, 2].unique():
        rows = (refs[:, 2] == label).nonzero(as_tuple=False).flatten()
        if len(rows) > int(max_per_class):
            rows = rows[torch.randperm(len(rows), device=rows.device)[:int(max_per_class)]]
        selected.append(refs[rows])
    selected = torch.cat(selected)
    result = []
    for image, item in enumerate(resolved):
        if item is None:
            result.append(None)
            continue
        boxes, labels = item
        rows = selected[selected[:, 0] == image, 1]
        result.append(SimpleNamespace(bboxes=boxes[rows], labels=labels[rows]))
    return result


__all__ = ['stable_supcon_loss', 'cap_gt_batch']
