"""MA-SENet detector wrapper compatible with MMRotate 1.x.

The detector deliberately reuses :class:`RefineSingleStageDetector`: this
preserves S2A-Net's initial head, aligned refinement head, rotated box coder
and rotated NMS.  MA-specific state (warm-up epoch and confusion pairs) is
forwarded to heads that expose the optional adapter methods.
"""

from typing import Sequence, Tuple

from mmrotate.registry import MODELS
from .refine_single_stage import RefineSingleStageDetector


@MODELS.register_module()
class MASENet(RefineSingleStageDetector):
    """S2A-Net compatible MA-SENet detector.

    ``loss`` and ``predict`` are inherited unchanged.  MA losses are attached
    by ``MAS2AHead``/``MAS2ARefineHead`` during their standard
    ``loss_by_feat`` calls.
    """

    def set_current_epoch(self, epoch: int) -> None:
        """Propagate the runner epoch to all MA-enabled heads."""
        self.current_epoch = int(epoch)
        for head in (self.bbox_head_init, *self.bbox_head_refine):
            setter = getattr(head, 'set_current_epoch', None)
            if setter is not None:
                setter(self.current_epoch)

    def set_confusion_pairs(self,
                            pairs: Sequence[Tuple[int, int]]) -> None:
        """Update active CMM pairs on every head that supports the adapter."""
        self.confusion_pairs = [tuple(map(int, pair)) for pair in pairs]
        for head in (self.bbox_head_init, *self.bbox_head_refine):
            setter = getattr(head, 'set_confusion_pairs', None)
            if setter is not None:
                setter(self.confusion_pairs)


__all__ = ['MASENet']
