"""Exact fusion of the duplicated 3x3 convolution inside LEM / SFM.

Why this file exists
--------------------
Both edge modules apply the *same* ``conv3x3`` twice with nothing in between::

    # LEM.forward (and SFM.forward, identical shape)
    y1 = self.conv3x3(x)
    y2 = self.conv3x3(self.conv1x1(x))
    y  = y1 + y2 + <edge branch> + x        # then LayerNorm

Because a convolution with bias is affine, ``conv(u) = W*u + b``, so::

    y1 + y2 = (W*x + b) + (W*A*x + b)
            = W*(x + A*x) + 2b
            = conv3x3(x + conv1x1(x)) + b

i.e. the two 3x3 evaluations collapse into one.  That halves the 3x3 cost of
every LEM/SFM at *inference* while keeping the exact same function -- provided
the extra bias ``b`` is added back, which is the only subtlety.

Scope and honest limits
-----------------------
* **No parameter reduction.** The same weights are reused, so this cannot be
  presented as an architecture/parameter innovation; it is an inference
  re-parameterisation (same class of trick as RepVGG-style fusion).
* **Not bitwise identical.** Floating-point addition is not associative, so
  ``conv(x) + conv(Ax)`` and ``conv(x + Ax) + b`` differ at the ulp level. The
  contract asserted here is ``allclose`` at fp32 with a tight tolerance, plus no
  measurable change in detection mAP.
* Training is unaffected: the fused path is only installed by an explicit call
  and is a pure function of the same parameters, so gradients (if any were
  taken) still flow to the original weights.

Usage
-----
``fuse_edge_modules(neck)`` walks the neck, replaces each LEM/SFM's forward with
the fused one, and returns the number of modules touched.
"""
from __future__ import annotations

import types

import torch

_EDGE_CLASSES = ('LEM', 'SFM')


def _fused_forward_factory(module):
    """Build a forward that evaluates the duplicated 3x3 only once."""
    conv3x3 = module.conv3x3
    conv1x1 = module.conv1x1
    has_bias = conv3x3.bias is not None
    bias = conv3x3.bias

    def forward(self, x):
        # y1 + y2 merged into a single 3x3 evaluation.
        merged = conv3x3(x + conv1x1(x))
        if has_bias:
            # conv(u) adds b once; the two original calls added it twice.
            merged = merged + bias.view(1, -1, 1, 1)

        if self.__class__.__name__ == 'LEM':
            y = merged + self.edge_l(x) + x
            y = y.permute(0, 2, 3, 1)
            y = self.post_enhance_norm(y)
            return y.permute(0, 3, 1, 2).contiguous()

        # SFM
        edge = torch.cat([self.edge_x(x), self.edge_y(x)], dim=1)
        edge = self.edge_conv(edge)
        y = merged + edge + x
        y = y.permute(0, 2, 3, 1)
        y = self.post_aggre_norm(y)
        return y.permute(0, 3, 1, 2).contiguous()

    return forward


def fuse_edge_modules(neck, verbose: bool = False) -> int:
    """Install the fused forward on every LEM/SFM inside ``neck``.

    Idempotent: calling twice does not double-fuse (guarded by ``_edge_fused``).
    """
    fused = 0
    for name, child in neck.named_modules():
        if type(child).__name__ not in _EDGE_CLASSES:
            continue
        if getattr(child, '_edge_fused', False):
            continue
        child.forward = types.MethodType(_fused_forward_factory(child), child)
        child._edge_fused = True
        fused += 1
        if verbose:
            print('        fused %s (%s)' % (name, type(child).__name__))
    return fused


def count_edge_modules(neck) -> int:
    return sum(1 for _, m in neck.named_modules()
               if type(m).__name__ in _EDGE_CLASSES)


__all__ = ['fuse_edge_modules', 'count_edge_modules']
