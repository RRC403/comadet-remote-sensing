"""Isolated CPD-inspired rotated-GT prototype branch.

This file is deliberately outside the MMRotate package and registry. It is a
research prototype, not an enabled model component. The branch pools one
rotated GT RoI from a single selected feature level, projects it into an
embedding, and contrasts it against detached class prototypes built from
earlier training batches.

The class bank is updated only after the current loss has been formed. It has
no cross-batch autograd graph, is checkpointed through registered buffers,
and skips queries until both their own prototype and at least one negative
class prototype are established.
"""

import math
from typing import Optional

import torch
from torch import nn
from torch.nn import functional as F


class ClassPrototypeMemoryLoss(nn.Module):
    """Contrast current embeddings against reliable historical class means.

    Args:
        num_classes: Number of foreground categories.
        embedding_dim: Width of normalized input embeddings.
        temperature: Softmax temperature, strictly positive.
        loss_weight: Scalar multiplier. Zero is a strict no-op, including no
            prototype updates.
        momentum: EMA coefficient for an established class prototype.
        min_observations: A class prototype is usable only after at least this
            many GT embeddings have contributed to it.
        max_age_steps: If set, a prototype older than this many calls is
            excluded. When the class appears again, its stale prototype and
            count are reset rather than blended with a different feature space.
            ``None`` disables age expiration while still recording ages.
    """

    def __init__(self,
                 num_classes: int,
                 embedding_dim: int,
                 temperature: float = 0.1,
                 loss_weight: float = 0.05,
                 margin: float = 0.0,
                 momentum: float = 0.9,
                 min_observations: int = 8,
                 max_age_steps: Optional[int] = 10000) -> None:
        super().__init__()
        if int(num_classes) <= 1:
            raise ValueError('num_classes must be greater than one')
        if int(embedding_dim) <= 0:
            raise ValueError('embedding_dim must be positive')
        if not math.isfinite(float(temperature)) or not 0.0 < float(temperature):
            raise ValueError('temperature must be positive')
        if not math.isfinite(float(loss_weight)) or not 0.0 <= float(loss_weight):
            raise ValueError('loss_weight must be non-negative')
        if not math.isfinite(float(margin)) or float(margin) < 0.0:
            raise ValueError('margin must be finite and non-negative')
        if not math.isfinite(float(momentum)) or not 0.0 <= float(momentum) < 1.0:
            raise ValueError('momentum must be in [0, 1)')
        if int(min_observations) <= 0:
            raise ValueError('min_observations must be positive')
        if max_age_steps is not None and int(max_age_steps) <= 0:
            raise ValueError('max_age_steps must be positive or None')

        self.num_classes = int(num_classes)
        self.embedding_dim = int(embedding_dim)
        self.temperature = float(temperature)
        self.loss_weight = float(loss_weight)
        # CosFace-style subtractive margin on the target logit.  Plain InfoNCE
        # decays to ~0 once the bank is memorised (measured 0.069 -> 0.0046 over
        # 12 epochs), making the term inert exactly when it should regularise.
        # A positive margin holds the target logit below the max, so the loss
        # floor becomes ~margin/temperature instead of zero.
        self.margin = float(margin)
        self.momentum = float(momentum)
        self.min_observations = int(min_observations)
        self.max_age_steps = (None if max_age_steps is None
                              else int(max_age_steps))
        self.prototype_eps = 1e-6

        # Keep memory state in FP32 under normal autocast training. These
        # buffers follow the module device and are included in state_dict().
        self.register_buffer(
            'prototypes', torch.zeros(self.num_classes, self.embedding_dim,
                                      dtype=torch.float32))
        self.register_buffer('observations',
                             torch.zeros(self.num_classes, dtype=torch.long))
        self.register_buffer('prototype_updates',
                             torch.zeros(self.num_classes, dtype=torch.long))
        self.register_buffer('last_seen_step',
                             torch.full((self.num_classes,), -1,
                                        dtype=torch.long))
        self.register_buffer('num_steps', torch.zeros((), dtype=torch.long))
        self.last_stats = {}

    def _active_bank(self, step: int):
        active = self.observations >= self.min_observations
        active = active & (self.last_seen_step >= 0)
        ages = torch.where(self.last_seen_step >= 0,
                           step - self.last_seen_step,
                           torch.full_like(self.last_seen_step, -1))
        if self.max_age_steps is not None:
            active = active & (ages <= self.max_age_steps)
        bank_norm = torch.linalg.vector_norm(self.prototypes.float(), dim=1)
        bank_finite = torch.isfinite(self.prototypes).all(dim=1)
        active = (active & bank_finite & torch.isfinite(bank_norm)
                  & (bank_norm > self.prototype_eps))
        return active, ages

    def _record_stats(self, step: int, active: torch.Tensor,
                      ages: torch.Tensor, used_queries: int,
                      raw_loss: torch.Tensor) -> None:
        self.last_stats = dict(
            step=int(step),
            observations_after_update=self.observations.detach().cpu().tolist(),
            prototype_updates=self.prototype_updates.detach().cpu().tolist(),
            prototype_ages_for_loss=ages.detach().cpu().tolist(),
            valid_prototypes_for_loss=int(active.sum().item()),
            used_queries=int(used_queries),
            loss_raw=float(raw_loss.detach().float().cpu()),
            loss_weight=self.loss_weight,
            zero_loss=bool(used_queries == 0),
        )

    def forward(self, embeddings: torch.Tensor,
                labels: torch.Tensor) -> torch.Tensor:
        """Return a graph-connected loss and then update memory from this batch.

        ``embeddings`` is ``[N, D]`` and ``labels`` is ``[N]``. Labels outside
        ``[0, num_classes)`` and rows containing non-finite values are ignored.
        Evaluation mode and zero loss weight both return a no-op and do not
        mutate the memory.
        """
        if embeddings.ndim != 2 or embeddings.size(1) != self.embedding_dim:
            raise ValueError('embeddings must have shape [N, embedding_dim]')
        if labels.ndim != 1 or labels.numel() != embeddings.size(0):
            raise ValueError('labels must have shape [N] aligned with embeddings')

        # An empty view preserves a graph connection without summing NaN/Inf
        # or overflowing on very large but finite values.
        zero = embeddings.reshape(-1)[:0].float().sum()
        if not self.training or self.loss_weight == 0.0:
            self.last_stats = dict(disabled=True, used_queries=0,
                                   loss_raw=0.0, loss_weight=self.loss_weight)
            return zero

        step = int(self.num_steps.item())
        labels = labels.to(device=embeddings.device, dtype=torch.long)
        finite_embeddings = embeddings.float()
        input_norm = torch.linalg.vector_norm(finite_embeddings, dim=1)
        finite_rows = (torch.isfinite(finite_embeddings).all(dim=1)
                       & torch.isfinite(input_norm)
                       & (input_norm > self.prototype_eps))
        keep = ((labels >= 0) & (labels < self.num_classes) & finite_rows)

        # Clone the bank before loss construction: the in-place EMA update
        # later in this call must not invalidate tensors saved for backward.
        with torch.autocast(device_type=embeddings.device.type, enabled=False):
            z = F.normalize(embeddings[keep].float(), dim=1, eps=1e-12)
            y = labels[keep]
            active, ages = self._active_bank(step)
            raw_bank = self.prototypes.detach().float().clone()
            safe_bank = torch.where(
                active.to(raw_bank.device).unsqueeze(1), raw_bank,
                torch.zeros_like(raw_bank))
            bank = F.normalize(safe_bank, dim=1, eps=1e-12)
            valid_query = torch.zeros_like(y, dtype=torch.bool)
            if int(active.sum().item()) >= 2 and y.numel() > 0:
                valid_query = active.to(y.device)[y]
            used = int(valid_query.sum().item())
            if used:
                logits = (z[valid_query] @ bank.to(z.device).t()) / self.temperature
                logits = logits.masked_fill(
                    ~active.to(z.device).unsqueeze(0), -torch.inf)
                target = y[valid_query]
                if self.margin > 0.0:
                    _tgt = target.unsqueeze(1)
                    logits = logits.scatter(
                        1, _tgt, logits.gather(1, _tgt) - self.margin)
                raw_loss = (torch.logsumexp(logits, dim=1)
                            - logits.gather(1, target.unsqueeze(1)).squeeze(1)).mean()
                loss = raw_loss * self.loss_weight
            else:
                raw_loss = z.sum() * 0.0
                loss = zero

        self._update_bank(z.detach(), y.detach(), step)
        self._record_stats(step, active, ages, used, raw_loss)
        self.num_steps.add_(1)
        return loss

    @torch.no_grad()
    def _update_bank(self, embeddings: torch.Tensor, labels: torch.Tensor,
                     step: int) -> None:
        if embeddings.numel() == 0:
            return
        for cls in labels.unique().tolist():
            cls = int(cls)
            rows = embeddings[labels == cls]
            if rows.numel() == 0:
                continue
            mean = rows.mean(dim=0)
            mean_norm = torch.linalg.vector_norm(mean)
            if (not bool(torch.isfinite(mean_norm))
                    or float(mean_norm) <= self.prototype_eps):
                continue
            batch_mean = mean / mean_norm
            prior_seen = int(self.last_seen_step[cls].item())
            stale = (self.max_age_steps is not None and prior_seen >= 0
                     and step - prior_seen > self.max_age_steps)
            old = self.prototypes[cls].float()
            old_norm = torch.linalg.vector_norm(old)
            old_valid = (bool(torch.isfinite(old).all())
                         and bool(torch.isfinite(old_norm))
                         and float(old_norm) > self.prototype_eps
                         and prior_seen >= 0)
            rebuild = (int(self.observations[cls].item()) == 0
                       or stale or not old_valid)
            if rebuild:
                self.prototypes[cls].copy_(batch_mean)
                self.observations[cls] = 0
                self.prototype_updates[cls] = 0
            else:
                merged = self.momentum * old + (1.0 - self.momentum) * batch_mean
                merged_norm = torch.linalg.vector_norm(merged)
                if (not bool(torch.isfinite(merged_norm))
                        or float(merged_norm) <= self.prototype_eps):
                    continue
                self.prototypes[cls].copy_(merged / merged_norm)
            self.observations[cls] += int(rows.size(0))
            self.prototype_updates[cls] += 1
            self.last_seen_step[cls] = int(step)


class RotatedGTPrototypeBranch(nn.Module):
    """Single-scale rotated-GT RoI adapter for the prototype loss.

    This is an isolated branch, not registered with MMRotate and not wired
    into MAS2ARefineHead. A future integration should cache the selected FPN
    feature only during training and pass the actual batch GT instances here.
    """

    def __init__(self,
                 in_channels: int,
                 num_classes: int,
                 level_stride: int = 8,
                 roi_out_size: int = 7,
                 embedding_dim: int = 128,
                 hidden_dim: int = 256,
                 temperature: float = 0.1,
                 loss_weight: float = 0.05,
                 margin: float = 0.0,
                 momentum: float = 0.9,
                 min_observations: int = 8,
                 max_age_steps: Optional[int] = 10000,
                 max_per_class: int = 32) -> None:
        super().__init__()
        if int(max_per_class) <= 0:
            raise ValueError('max_per_class must be positive')
        self.num_classes = int(num_classes)
        self.roi_out_size = int(roi_out_size)
        self.max_per_class = int(max_per_class)

        # Lazy import keeps the loss usable in CPU-only analysis without
        # importing MMCV rotated CUDA operators.
        from mmrotate.models.roi_heads.roi_extractors import RotatedSingleRoIExtractor
        self.roi_extractor = RotatedSingleRoIExtractor(
            roi_layer=dict(type='RoIAlignRotated',
                           out_size=self.roi_out_size,
                           sampling_ratio=2,
                           clockwise=True),
            out_channels=int(in_channels),
            featmap_strides=[int(level_stride)])
        flat_dim = int(in_channels) * self.roi_out_size * self.roi_out_size
        self.projector = nn.Sequential(
            nn.Linear(flat_dim, int(hidden_dim)),
            nn.LayerNorm(int(hidden_dim)),
            nn.ReLU(inplace=True),
            nn.Linear(int(hidden_dim), int(embedding_dim)),
        )
        self.prototype_loss = ClassPrototypeMemoryLoss(
            num_classes=num_classes,
            embedding_dim=embedding_dim,
            temperature=temperature,
            loss_weight=loss_weight,
            margin=margin,
            momentum=momentum,
            min_observations=min_observations,
            max_age_steps=max_age_steps)
        self.last_stats = {}

    @staticmethod
    def _gt_fields(sample):
        if isinstance(sample, dict):
            sample = sample.get('gt_instances', sample)
            boxes = sample.get('bboxes')
            labels = sample.get('labels')
        else:
            sample = getattr(sample, 'gt_instances', sample)
            boxes = getattr(sample, 'bboxes', None)
            labels = getattr(sample, 'labels', None)
        if boxes is not None and hasattr(boxes, 'tensor'):
            boxes = boxes.tensor
        return boxes, labels

    def forward(self, feats, batch_gt_instances, level: int = 0):
        if level < 0 or level >= len(feats):
            raise ValueError('configured CPD feature level is absent')
        feature = feats[level]
        if not self.training or self.prototype_loss.loss_weight == 0.0:
            self.last_stats = dict(disabled=True, objects=0, used_queries=0,
                                   loss_raw=0.0,
                                   loss_weight=self.prototype_loss.loss_weight)
            return feature.reshape(-1)[:0].float().sum()
        roi_rows, label_rows = [], []
        for image_index, sample in enumerate(batch_gt_instances):
            boxes, labels = self._gt_fields(sample)
            if boxes is None or labels is None:
                continue
            # Keep rotated coordinates in FP32. Casting GT box coordinates to
            # BF16 before RoIAlignRotated can perturb small boxes and angles.
            boxes = boxes.to(device=feature.device, dtype=torch.float32)
            labels = labels.to(device=feature.device, dtype=torch.long)
            if boxes.ndim != 2 or boxes.size(1) != 5 or len(boxes) != len(labels):
                raise ValueError('CPD expects aligned rotated boxes[N,5]/labels[N]')
            keep = ((labels >= 0) & (labels < self.num_classes)
                    & torch.isfinite(boxes).all(dim=1)
                    & (boxes[:, 2:4] > 0).all(dim=1))
            indices = keep.nonzero(as_tuple=False).flatten()
            if not indices.numel():
                continue
            selected_boxes = boxes[indices]
            batch_column = selected_boxes.new_full(
                (selected_boxes.size(0), 1), float(image_index))
            roi_rows.append(torch.cat([batch_column, selected_boxes], dim=1))
            label_rows.append(labels[indices])

        if not roi_rows:
            zero = feature.reshape(-1)[:0].float().sum()
            empty_embeddings = torch.zeros(
                (0, self.prototype_loss.embedding_dim),
                device=feature.device, dtype=torch.float32) + zero
            empty_labels = torch.empty(
                (0,), dtype=torch.long, device=feature.device)
            loss = self.prototype_loss(empty_embeddings, empty_labels)
            self.last_stats = dict(objects=0, skipped='no_valid_gt',
                                   **self.prototype_loss.last_stats)
            return loss

        rois = torch.cat(roi_rows, dim=0)
        labels = torch.cat(label_rows, dim=0)
        selected = []
        for cls in labels.unique().tolist():
            rows = (labels == int(cls)).nonzero(as_tuple=False).flatten()
            if rows.numel() > self.max_per_class:
                order = torch.randperm(rows.numel(), device=rows.device)
                rows = rows[order[:self.max_per_class]]
            selected.append(rows)
        selected = torch.cat(selected)
        rois, labels = rois[selected], labels[selected]
        # RotatedSingleRoIExtractor may cast rois to the feature dtype. Feed
        # FP32 features and FP32 RoIs with autocast disabled so both the box
        # geometry and rotated pooling stay in FP32 under BF16/FP16 training.
        with torch.autocast(device_type=feature.device.type, enabled=False):
            pooled = self.roi_extractor([feature.float()], rois.float())
            embeddings = self.projector(pooled.flatten(1).float())
            loss = self.prototype_loss(embeddings, labels)
        self.last_stats = dict(
            objects=int(labels.numel()),
            batch_classes=int(labels.unique().numel()),
            **self.prototype_loss.last_stats)
        return loss


__all__ = ['ClassPrototypeMemoryLoss', 'RotatedGTPrototypeBranch']
