"""CPD refine head: MAS2ARefineHead + a class-prototype branch (for problem ⑤).

Why this file exists
--------------------
``.probes/cpd_prototype/cpd_prototype.py`` is a standalone, registry-free draft.
Its ``ClassPrototypeMemoryLoss`` has since passed 25/25 CPU runtime checks
(``.probes/cpd_prototype/test_cpd_runtime.py``), including the behaviour that
motivates the whole idea: a batch containing only ONE class still gets a
non-zero loss when prototypes of *other* classes exist from earlier steps.

This module wires that draft into a real refine head without touching any
historical head class:

* ``MAS2ACPDRefineHead`` subclasses ``MAS2ARefineHead`` and adds an opt-in
  ``cpd_cfg``.  With ``cpd_cfg.enabled=False`` (the default) the head is the
  plain parent head and the branch is never even constructed, so a paired
  baseline can share the exact same class and E0 tensors.
* The FPN feature list is cached in ``feature_refine`` -- the only hook the
  detector gives us that sees both the shared pyramid and the rois -- and
  consumed in ``loss_by_feat``.  This mirrors the established pattern in
  ``ma_contrast_head.py`` / ``ma_cross_scale_contrast_v2_head.py``.
* The cache is only populated while ``self.training``; inference never calls
  ``loss_by_feat``, so caching there would leak (a real bug that was found and
  fixed in the IC1 head by CUDA preflight -- do not reintroduce it).

Honest scope
------------
This is a CPD-*inspired adaptation*, not an SFDNet reproduction.  The prototype
bank stores one mean per class in the current projection space, so pose/scale
modes inside a class can collapse.  A prototype passing unit tests is NOT
evidence of an mAP gain; that needs a same-host, same-E0, single-variable E12
comparison.  One mean per class can also be wrong while still being "valid".
"""
from __future__ import annotations

import os
from typing import Optional, Sequence, Tuple

import torch
from mmrotate.registry import MODELS

from .ma_s2a_head import MAS2ARefineHead

def _load_prototype_branch():
    """Locate ``RotatedGTPrototypeBranch`` from the isolated draft.

    The draft is deliberately *not* a package module yet, so it is searched by
    path.  Candidates cover every layout seen in this project (cwd = project
    root, cwd = repo root, and a copy dropped straight into the package), so a
    deployment cannot silently depend on which directory training was started
    from.
    """
    import importlib.util

    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        # co-located copy inside the package (self-contained deployment)
        os.path.join(here, 'cpd_prototype.py'),
        # cwd = <...>/mmrotate (the usual training cwd)
        os.path.join(os.getcwd(), '.probes', 'cpd_prototype', 'cpd_prototype.py'),
        # module at <repo>/mmrotate/models/dense_heads -> <repo>/.probes/...
        os.path.join(here, '..', '..', '..', '.probes', 'cpd_prototype',
                     'cpd_prototype.py'),
        os.path.join(here, '..', '..', '..', '..', '.probes', 'cpd_prototype',
                     'cpd_prototype.py'),
    ]
    for path in candidates:
        path = os.path.normpath(path)
        if not os.path.isfile(path):
            continue
        spec = importlib.util.spec_from_file_location('_cpd_prototype', path)
        if spec is None or spec.loader is None:
            continue
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.RotatedGTPrototypeBranch
    raise ImportError(
        'RotatedGTPrototypeBranch not found. Looked in: %s' % candidates)


RotatedGTPrototypeBranch = _load_prototype_branch()


@MODELS.register_module()
class MAS2ACPDRefineHead(MAS2ARefineHead):
    """Refine head plus an opt-in class-prototype (CPD-inspired) term.

    Args:
        cpd_cfg (dict | None): ``enabled`` toggles the branch.  Remaining keys
            are forwarded to :class:`RotatedGTPrototypeBranch`
            (``level``, ``roi_out_size``, ``embedding_dim``, ``hidden_dim``,
            ``temperature``, ``loss_weight``, ``momentum``,
            ``min_observations``, ``max_age_steps``, ``max_per_class``).
    """

    def __init__(self, *args, cpd_cfg: Optional[dict] = None, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        cfg = dict(cpd_cfg or {})
        self.cpd_enabled = bool(cfg.get('enabled', False))
        self.cpd_cfg = cfg
        self.cpd_branch = None
        self._cpd_feats = None
        if self.cpd_enabled:
            level = int(cfg.get('level', 0))
            strides = self._cpd_level_strides(cfg)
            if level >= len(strides):
                raise ValueError(
                    'cpd_cfg.level %d has no matching stride (got %s)'
                    % (level, list(strides)))
            self.cpd_branch = RotatedGTPrototypeBranch(
                in_channels=int(self.feat_channels),
                num_classes=int(self.cls_out_channels),
                level_stride=int(strides[level]),
                roi_out_size=int(cfg.get('roi_out_size', 7)),
                embedding_dim=int(cfg.get('embedding_dim', 128)),
                hidden_dim=int(cfg.get('hidden_dim', 256)),
                temperature=float(cfg.get('temperature', 0.1)),
                loss_weight=float(cfg.get('loss_weight', 0.05)),

                margin=float(cfg.get('margin', 0.0)),
                momentum=float(cfg.get('momentum', 0.9)),
                min_observations=int(cfg.get('min_observations', 8)),
                max_age_steps=(None if cfg.get('max_age_steps', 10000) is None
                               else int(cfg.get('max_age_steps', 10000))),
                max_per_class=int(cfg.get('max_per_class', 32)),
            )
            self._cpd_level = level

    # ------------------------------------------------------------------ #
    def _cpd_level_strides(self, cfg: dict) -> Tuple[int, ...]:
        """Real FPN strides; never guess the RoIAlign spatial_scale.

        Priority: explicit ``level_strides`` in ``cpd_cfg``, else the head's own
        ``anchor_generator.strides`` (which the detector already uses, so it
        cannot disagree with the FPN), else the 8*2**level ladder.
        """
        explicit = cfg.get('level_strides')
        if explicit:
            return tuple(int(s) for s in explicit)
        gen = getattr(self, 'anchor_generator', None)
        strides = getattr(gen, 'strides', None)
        if not strides:
            return tuple(8 * 2 ** i for i in range(5))
        out = []
        for s in strides:
            if isinstance(s, (tuple, list)):
                if not s:
                    continue
                s = s[0]
            try:
                out.append(int(s))
            except (TypeError, ValueError):
                continue
        return tuple(out) or tuple(8 * 2 ** i for i in range(5))

    # ------------------------------------------------------------------ #
    def feature_refine(self, x, rois):
        """Cache the shared pyramid for the prototype branch (training only)."""
        if self.cpd_enabled and self.cpd_branch is not None:
            # Training-only, for the same reason as the IC1 fix: predict() never
            # calls loss_by_feat, so an unconditional cache leaks per call.
            self._cpd_feats = list(x) if self.training else None
        return super().feature_refine(x, rois)

    def loss_by_feat(self, cls_scores, bbox_preds, batch_gt_instances,
                     batch_img_metas, batch_gt_instances_ignore=None,
                     rois=None, **kwargs) -> dict:
        """Parent loss plus the class-prototype term."""
        feats = getattr(self, '_cpd_feats', None)
        self._cpd_feats = None
        losses = super().loss_by_feat(
            cls_scores, bbox_preds, batch_gt_instances, batch_img_metas,
            batch_gt_instances_ignore, rois=rois)
        if not self.cpd_enabled or self.cpd_branch is None:
            return losses
        if not feats:
            return losses
        level = int(getattr(self, '_cpd_level', 0))
        if level >= len(feats):
            raise ValueError('cpd_cfg.level %d absent from the feature list'
                             % level)
        term = self.cpd_branch(feats, batch_gt_instances, level=level)
        if term is not None:
            losses['loss_cpd_refine'] = term
        return losses

    # ------------------------------------------------------------------ #
    def cpd_epoch_summary(self) -> dict:
        """Coverage diagnostics, so a run can show whether the bank was usable.

        A non-zero loss is not enough: the point of CPD is that absent classes
        still find a reference.  These counters say whether that ever happened.
        """
        if not self.cpd_enabled or self.cpd_branch is None:
            return {}
        stats = dict(getattr(self.cpd_branch, 'last_stats', {}) or {})
        bank = getattr(self.cpd_branch, 'prototype_loss', None)
        if bank is not None:
            stats['bank_observations'] = bank.observations.tolist()
            stats['bank_classes_ready'] = int(
                (bank.observations >= bank.min_observations).sum().item())
            stats['bank_steps'] = int(bank.num_steps.item())
        return stats


__all__ = ['MAS2ACPDRefineHead']
