"""IC2 (stable cross-scale contrast) + CPD (class-prototype) in ONE refine head.

Why this file exists
--------------------
IC2 ships as ``MAS2AStableCrossScaleContrastRefineHead`` and CPD ships as
``MAS2ACPDRefineHead``.  Both subclass ``MAS2ARefineHead``, so they are *sibling*
classes: a model can instantiate one or the other, never both.  The cumulative
ablation ladder (recipe -> IC2 -> CPD -> Light) needs a head that carries BOTH
branches, otherwise its last rung -- the full model -- cannot be built at all.

Design constraints (deliberate, do not "simplify" them away)
------------------------------------------------------------
* **No multiple inheritance.**  The base is the IC2 head actually used in
  production, ``MAS2AStableCrossScaleContrastRefineHead``; the CPD prototype
  branch is *attached* to it exactly the way ``ma_cpd_head.py`` attaches it to
  the plain head.  MRO games across two sibling heads would silently pick one
  ``loss_by_feat`` and drop the other's term.
* **No changes to historical classes.**  ``ma_cpd_head.py``,
  ``ma_cross_scale_contrast_head.py`` and ``ma_cross_scale_contrast_v2_head.py``
  are untouched.  This file only adds a class and its registry entry, so every
  result already produced by those heads stays reproducible from unmodified code.
* **Each branch owns its cache.**  ``_contrast_feats`` belongs to the IC2 base,
  ``_cpd_feats`` belongs to this class.  Neither reads the other's attribute.
* **The parent ``loss_by_feat`` runs exactly once.**  The CPD term is appended to
  the dict the parent returned; the parent is never called a second time.
* **Caches are cleared on every exit path**, including exceptions, for both
  ``feature_refine`` and ``loss_by_feat``.  A leaked cache would silently pair
  the current batch's losses with a previous batch's features.

No-op contract (what ``cpd_cfg.enabled`` / ``loss_weight`` must guarantee)
--------------------------------------------------------------------------
``cpd_cfg.enabled=False`` (default)
    The prototype branch is **never constructed**.  Parameters, ``state_dict``
    and forward output must be bit-identical to the plain IC2 head, and the
    returned loss dict must not contain ``loss_cpd_refine``.
``cpd_cfg.enabled=True, loss_weight=0``
    The branch exists (so R3/R2 share one class and one E0), the returned CPD
    term is a zero tensor, and every CPD parameter receives **no** gradient.
``cpd_cfg.enabled=True, loss_weight>0``
    The CPD term is finite and the prototype branch's parameters receive a
    non-zero gradient.

Scope note
----------
Passing these checks is a statement about *wiring*, not about mAP.  Whether the
merged term helps is a separate same-host, same-E0, single-variable E12 question.
"""
from __future__ import annotations

from typing import Optional, Tuple

import torch

from mmrotate.registry import MODELS

from .ma_cpd_head import RotatedGTPrototypeBranch
from .ma_cross_scale_contrast_v2_head import (
    MAS2AStableCrossScaleContrastRefineHead)


@MODELS.register_module()
class MAS2AStableContrastCPDRefineHead(
        MAS2AStableCrossScaleContrastRefineHead):
    """IC2 stable cross-scale contrast head + opt-in CPD prototype term.

    Args:
        contrast_cfg (dict | None): forwarded unchanged to the IC2 base.
        cpd_cfg (dict | None): ``enabled`` toggles the prototype branch.  The
            remaining keys are forwarded to
            :class:`RotatedGTPrototypeBranch` (``level``, ``level_strides``,
            ``roi_out_size``, ``embedding_dim``, ``hidden_dim``,
            ``temperature``, ``loss_weight``, ``momentum``,
            ``min_observations``, ``max_age_steps``, ``max_per_class``).
    """

    def __init__(self, *args, contrast_cfg: Optional[dict] = None,
                 cpd_cfg: Optional[dict] = None, **kwargs) -> None:
        super().__init__(*args, contrast_cfg=contrast_cfg, **kwargs)
        cfg = dict(cpd_cfg or {})
        self.cpd_enabled = bool(cfg.get('enabled', False))
        self.cpd_cfg = cfg
        self.cpd_branch = None
        self._cpd_feats = None
        if not self.cpd_enabled:
            # Strict no-op: no branch object, therefore no extra parameters and
            # an unchanged state_dict relative to the IC2-only baseline.
            return
        level = int(cfg.get('level', 0))
        strides = self._cpd_level_strides(cfg)
        if level >= len(strides):
            raise ValueError(
                'cpd_cfg.level %d has no matching stride (got %s)'
                % (level, list(strides)))
        self.cpd_branch = RotatedGTPrototypeBranch(
            in_channels=int(self.feat_channels),
            num_classes=int(self.cls_out_channels),
            level_stride=int(strides[level]),
            roi_out_size=int(cfg.get('roi_out_size', 7)),
            embedding_dim=int(cfg.get('embedding_dim', 128)),
            hidden_dim=int(cfg.get('hidden_dim', 256)),
            temperature=float(cfg.get('temperature', 0.1)),
            loss_weight=float(cfg.get('loss_weight', 0.05)),

            margin=float(cfg.get('margin', 0.0)),
            momentum=float(cfg.get('momentum', 0.9)),
            min_observations=int(cfg.get('min_observations', 8)),
            max_age_steps=(None if cfg.get('max_age_steps', 10000) is None
                           else int(cfg.get('max_age_steps', 10000))),
            max_per_class=int(cfg.get('max_per_class', 32)),
        )
        self._cpd_level = level
        self._apply_fusion_switches(cfg)

    # ------------------------------------------------------------------ #
    # Fusion switches (both default OFF -> bitwise identical to the old head)
    # ------------------------------------------------------------------ #
    def _apply_fusion_switches(self, cfg: dict) -> None:
        """Wire the two structural fixes identified by the gradient audit.

        Problem measured on the pre-fix head
        ------------------------------------
        Every auxiliary loss pooled its RoI features from ``list(x)`` -- the raw
        FPN output, i.e. the *input* of ``feat_refine_module``.  The classifier
        is ``retina_cls(cls_convs(or_conv(x_refine)))``, so no parameter of that
        path ever received auxiliary gradient; 100% of the auxiliary gradient
        authority landed on two 3.24M projection heads that are **discarded at
        inference**.  That is a structural disconnection, not a hyper-parameter
        issue (IC2's term is already ~17% of the total loss).

        Fix A -- ``pool_from_cls_feat``
            Pool from ``cls_feat`` (the input of ``retina_cls``) instead.  Same
            channel count and same spatial size, so the RoI extractors keep their
            strides; but the gradient now flows through ``cls_convs`` and
            ``or_conv`` -- 838,913 inference-retained parameters.

        Fix B -- ``share_projector``
            IC2's ``proj`` and CPD's ``projector`` are both
            ``Linear(flat->hidden) -> LayerNorm -> ReLU -> Linear(hidden->dim)``
            with identical default widths (256 -> 128).  Sharing one instance
            cuts 3.24M parameters and, more importantly, forces the two losses to
            constrain the *same* embedding space -- the prerequisite for the two
            modules to reinforce each other instead of being redundant.
        """
        self.pool_from_cls_feat = bool(cfg.get('pool_from_cls_feat', False))
        self._cls_feats = None
        if self.pool_from_cls_feat:
            # ``retina_cls`` sees ``cls_feat`` as its only input; a pre-hook keeps
            # the tensor differentiable (verified: requires_grad=True).
            self.retina_cls.register_forward_pre_hook(self._capture_cls_feat)

        self.projector_shared = False
        if bool(cfg.get('share_projector', False)):
            if not (self.contrast_enabled and self.cpd_branch is not None):
                raise ValueError(
                    'share_projector needs both contrast_cfg.enabled and '
                    'cpd_cfg.enabled')
            ic2_proj = getattr(self.contrast_branch, 'proj', None)
            cpd_proj = getattr(self.cpd_branch, 'projector', None)
            if ic2_proj is None or cpd_proj is None:
                raise ValueError('one of the two branches has no projection')
            ic2_out = ic2_proj[-1].out_features
            cpd_out = cpd_proj[-1].out_features
            if ic2_out != cpd_out:
                raise ValueError(
                    'share_projector needs equal output dims, got %d vs %d '
                    '(set contrast_cfg.proj_dim == cpd_cfg.embedding_dim)'
                    % (ic2_out, cpd_out))
            # One shared instance: CPD now reuses IC2's module object, so both
            # losses backprop into the same weights and parameter count drops.
            self.cpd_branch.projector = self.contrast_branch.proj
            self.projector_shared = True

    def _capture_cls_feat(self, module, inputs) -> None:
        """Forward-pre-hook on ``retina_cls``: stash ``cls_feat`` for the losses."""
        if not self.training:
            return
        if isinstance(inputs, (tuple, list)) and inputs:
            feats = inputs[0]
        else:
            feats = inputs
        if torch.is_tensor(feats):
            if self._cls_feats is None:
                self._cls_feats = []
            self._cls_feats.append(feats)

    # ------------------------------------------------------------------ #
    def _cpd_level_strides(self, cfg: dict) -> Tuple[int, ...]:
        """Real FPN strides; never guess the RoIAlign spatial_scale.

        Priority: explicit ``level_strides`` in ``cpd_cfg``, else the head's own
        ``anchor_generator.strides`` (which the detector already uses, so it
        cannot disagree with the FPN), else the 8*2**level ladder.  Kept
        identical to ``MAS2ACPDRefineHead`` on purpose: a stride mismatch between
        the two heads would make their CPD terms incomparable.
        """
        explicit = cfg.get('level_strides')
        if explicit:
            return tuple(int(s) for s in explicit)
        gen = getattr(self, 'anchor_generator', None)
        strides = getattr(gen, 'strides', None)
        if not strides:
            return tuple(8 * 2 ** i for i in range(5))
        out = []
        for s in strides:
            if isinstance(s, (tuple, list)):
                if not s:
                    continue
                s = s[0]
            try:
                out.append(int(s))
            except (TypeError, ValueError):
                continue
        return tuple(out) or tuple(8 * 2 ** i for i in range(5))

    # ------------------------------------------------------------------ #
    def feature_refine(self, x, rois):
        """Cache the pyramid for the prototype branch (training only).

        Only training, for the same reason as the IC1/IC2 fix: ``predict()``
        never calls ``loss_by_feat``, so an unconditional cache would leak once
        per inference call.  The IC2 base sets/clears its own
        ``_contrast_feats`` in its own override; this method touches only
        ``_cpd_feats`` and then delegates.
        """
        # Reset per stage: the detector calls feature_refine() once per refinement
        # stage, then runs the forward that fills ``_cls_feats`` through the
        # ``retina_cls`` pre-hook.
        self._cls_feats = None
        if self.cpd_enabled and self.cpd_branch is not None:
            self._cpd_feats = list(x) if self.training else None
        else:
            self._cpd_feats = None
        try:
            return super().feature_refine(x, rois)
        except Exception:
            self._cpd_feats = None
            raise

    def loss_by_feat(self, cls_scores, bbox_preds, batch_gt_instances,
                     batch_img_metas, batch_gt_instances_ignore=None,
                     rois=None, **kwargs) -> dict:
        """Parent loss (IC2 included) plus the class-prototype term."""
        # ``pool_from_cls_feat``: replace the raw-FPN caches with the classifier's
        # own features.  ``_contrast_feats`` is read by the IC2 base inside the
        # super() call below, so overriding it here is what actually moves the
        # contrast gradient onto ``cls_convs`` / ``or_conv``.
        if self.pool_from_cls_feat and self._cls_feats:
            self._contrast_feats = list(self._cls_feats)
            self._cpd_feats = list(self._cls_feats)
        self._cls_feats = None
        feats = getattr(self, '_cpd_feats', None)
        self._cpd_feats = None
        try:
            # Exactly one parent call: it adds the IC2 term and clears
            # ``_contrast_feats`` in its own finally block.
            losses = super().loss_by_feat(
                cls_scores, bbox_preds, batch_gt_instances, batch_img_metas,
                batch_gt_instances_ignore, rois=rois)
        except Exception:
            self._cpd_feats = None
            raise
        if not self.cpd_enabled or self.cpd_branch is None or not feats:
            return losses
        level = int(getattr(self, '_cpd_level', 0))
        if level >= len(feats):
            raise ValueError('cpd_cfg.level %d absent from the feature list'
                             % level)
        term = self.cpd_branch(feats, batch_gt_instances, level=level)
        if term is not None:
            losses['loss_cpd_refine'] = term
        return losses

    # ------------------------------------------------------------------ #
    def cpd_epoch_summary(self) -> dict:
        """Coverage diagnostics for the prototype bank (empty when disabled)."""
        if not self.cpd_enabled or self.cpd_branch is None:
            return {}
        stats = dict(getattr(self.cpd_branch, 'last_stats', {}) or {})
        bank = getattr(self.cpd_branch, 'prototype_loss', None)
        if bank is not None:
            stats['bank_observations'] = bank.observations.tolist()
            stats['bank_classes_ready'] = int(
                (bank.observations >= bank.min_observations).sum().item())
            stats['bank_steps'] = int(bank.num_steps.item())
        return stats


__all__ = ['MAS2AStableContrastCPDRefineHead']
