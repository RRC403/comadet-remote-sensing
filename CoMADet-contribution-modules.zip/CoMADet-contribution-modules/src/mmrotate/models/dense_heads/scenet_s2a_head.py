"""Initial S2A head with only SCENet's original SCA training loss."""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from mmrotate.registry import MODELS
from .s2a_head import S2AHead


class SCENetSCALoss(nn.Module):
    """Official SCENet SCA loss with an explicit dataset-specific class pair."""

    def __init__(self, loss_weight=1.0, class_pair=(3, 5)):
        super().__init__()
        self.loss_weight = float(loss_weight)
        self.class_pair = tuple(int(index) for index in class_pair)
        if len(self.class_pair) != 2 or self.class_pair[0] == self.class_pair[1]:
            raise ValueError('class_pair must contain two distinct class indices')

    def forward(self, feature, target, weight=None):
        if not isinstance(feature, Tensor):
            return torch.tensor(0.0)
        target = target.type_as(feature)
        num_classes = feature.size(2)
        num_instances = feature.size(1)
        class_a, class_b = self.class_pair
        if min(class_a, class_b) < 0 or max(class_a, class_b) >= num_classes:
            raise ValueError(
                f'class_pair={self.class_pair} is invalid for '
                f'{num_classes} foreground classes')
        target = F.one_hot(
            target.to(torch.int64), num_classes=num_classes + 1).float()
        score_a = feature[:, :, class_a]
        score_b = feature[:, :, class_b]
        target_a = target[:, :, class_a]
        target_b = target[:, :, class_b]
        score_vector = torch.stack([score_a, score_b], dim=-1)
        target_vector = torch.stack([target_a, target_b], dim=-1)
        cosine = F.cosine_similarity(score_vector, target_vector, dim=-1)
        magnitude = torch.sqrt(score_a**2 + score_b**2)
        all_other_classes = torch.all(target_vector == 0, dim=-1)
        row_weight = torch.where(
            all_other_classes,
            torch.full_like(all_other_classes, 0.1, dtype=feature.dtype),
            torch.full_like(all_other_classes, 0.9, dtype=feature.dtype))
        loss = (1 - cosine) * (1 - magnitude)
        loss_angle = (row_weight * loss).sum() / num_instances
        if weight is not None:
            loss_angle = loss_angle * weight
        return self.loss_weight * loss_angle


@MODELS.register_module()
class SCENetS2AHead(S2AHead):
    """S2A initial head plus the original single-level SCA loss.

    Unlike the project's MA-SENet heads this class adds no MID, CMM, or
    M-SCA modules/parameters. The SCA loss reads sigmoid classification scores
    from feature level 0 and is summed with the ordinary focal loss.
    """

    def __init__(self,
                 *args,
                 sca_loss_weight=1.0,
                 sca_class_pair=(3, 5),
                 **kwargs):
        super().__init__(*args, **kwargs)
        self.sca_loss = SCENetSCALoss(
            loss_weight=float(sca_loss_weight), class_pair=sca_class_pair)
        self._sca_level_calls = 0
        self._sca_cls_score = None
        self._sca_labels = None

    def loss_by_feat(self, *args, **kwargs):
        self._sca_level_calls = 0
        self._sca_cls_score = None
        self._sca_labels = None
        try:
            losses = super().loss_by_feat(*args, **kwargs)
            if self._sca_cls_score is not None:
                cls_score = self._sca_cls_score
                scores = cls_score.permute(0, 2, 3, 1).reshape(
                    1, -1, self.cls_out_channels).sigmoid()
                labels = self._sca_labels.reshape(1, -1).to(
                    device=scores.device, dtype=torch.long)
                losses['loss_scanet_sca'] = self.sca_loss(scores, labels)
            return losses
        finally:
            self._sca_level_calls = 0
            self._sca_cls_score = None
            self._sca_labels = None

    def loss_by_feat_single(self, *args, **kwargs):
        cls_score, labels = args[0], args[3]
        result = super().loss_by_feat_single(*args, **kwargs)
        if self._sca_level_calls == 0:
            self._sca_cls_score = cls_score
            self._sca_labels = labels
        self._sca_level_calls += 1
        return result
