"""Instance-aligned cross-scale contrastive supervision (training only).

Each GT rotated box is pooled independently from the selected FPN levels using
the same image-space box.  A shared projection maps aligned instance features
to one embedding space; supervised contrast learns class separation, while a
small explicit cosine term aligns the same instance across scales.  This is
not the paper's rejected operation of feeding several dense feature maps into
the original SCA loss.
"""
from typing import Optional
import torch
from torch import nn
from torch.nn import functional as F
from mmrotate.registry import MODELS
from .ma_contrast_head import (MAS2AContrastiveRefineHead,
                               InstanceContrastiveBranch, supcon_loss)


class CrossScaleInstanceBranch(InstanceContrastiveBranch):
    def __init__(self, *args, scale_align_weight=0.25, confusion_beta=0.0,
                 **kwargs):
        super().__init__(*args, **kwargs)
        if len(self.levels) < 2:
            raise ValueError('cross-scale contrast requires at least two levels')
        flat = self.in_channels * self.roi_out_size * self.roi_out_size
        hidden_dim = int(kwargs.get('hidden_dim', 256))
        proj_dim = int(kwargs.get('proj_dim', 128))
        # LayerNorm supports a single-object batch; BatchNorm1d would fail on
        # cold/sparse minibatches and updates running stats three times per
        # minibatch because each level is projected separately.
        self.proj = nn.Sequential(
            nn.Linear(flat, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, proj_dim),
        )
        from mmrotate.models.roi_heads.roi_extractors import RotatedSingleRoIExtractor
        self.scale_align_weight = float(scale_align_weight)
        self.confusion_beta = float(confusion_beta)
        self._confusion_snapshot = None
        self._totals_snapshot = None
        self.roi_extractors = nn.ModuleList()
        for level in self.levels:
            stride = self._stride_of(level)
            self.roi_extractors.append(RotatedSingleRoIExtractor(
                roi_layer=dict(type='RoIAlignRotated',
                               out_size=self.roi_out_size,
                               sampling_ratio=2, clockwise=True),
                out_channels=self.in_channels,
                featmap_strides=[stride]))
        # Parent head uses this only to decide whether to lazily create an
        # extractor. The per-level extractors above are already registered.
        self.roi_extractor = nn.Identity()

    @torch.no_grad()
    def set_confusion_snapshot(self, confusion, totals):
        """Copy CMM state for the next loss call without registering it."""
        if self.confusion_beta <= 0.0 or confusion is None or totals is None:
            self._confusion_snapshot = None
            self._totals_snapshot = None
            return
        self._confusion_snapshot = confusion.detach().clone()
        self._totals_snapshot = totals.detach().clone()

    def clear_confusion_snapshot(self):
        self._confusion_snapshot = None
        self._totals_snapshot = None

    def forward(self, feats, batch_gt_instances):
        available = [(level, extractor) for level, extractor in
                     zip(self.levels, self.roi_extractors) if level < len(feats)]
        if len(available) < 2:
            raise ValueError('at least two configured feature levels must exist')
        spatial = [tuple(feats[level].shape[-2:]) for level, _ in available]
        if len(set(spatial)) != len(spatial):
            raise ValueError('selected FPN levels must have distinct resolutions')
        rois_all, labels_all = [], []
        for batch_index, sample in enumerate(batch_gt_instances):
            boxes, labels = self._gt_of(sample)
            if boxes is None or boxes.numel() == 0:
                continue
            labels = labels.to(dtype=torch.long)
            keep = self._sample_indices(labels)
            if keep.numel() == 0:
                continue
            boxes, labels = boxes[keep], labels[keep]
            batch_col = boxes.new_full((boxes.size(0), 1), float(batch_index))
            rois_all.append(torch.cat([batch_col, boxes], dim=1))
            labels_all.append(labels)
        if not rois_all:
            self.last_stats = dict(objects=0, scales=len(available),
                                   class_loss=0., scale_align=0.)
            return None

        rois, labels = torch.cat(rois_all), torch.cat(labels_all)
        scale_embeddings = []
        for level, extractor in available:
            pooled = extractor([feats[level]], rois)
            z = F.normalize(self.proj(pooled.flatten(1)), dim=1)
            scale_embeddings.append(z)
        # [objects, scales, dim], same row across scales refers to the exact
        # same GT identity, not merely two objects with the same category.
        z_all = torch.stack(scale_embeddings, dim=1)
        flat_z = z_all.reshape(-1, z_all.size(-1))
        flat_labels = labels.repeat_interleave(z_all.size(1))
        cls_loss = supcon_loss(flat_z, flat_labels, self.temperature,
                               num_classes=self.num_classes)
        align = (1. - (z_all[:, :, None, :] * z_all[:, None, :, :]).sum(-1))
        upper = torch.triu(torch.ones(z_all.size(1), z_all.size(1),
                                      device=z_all.device, dtype=torch.bool), 1)
        scale_loss = align[:, upper].mean() if bool(upper.any()) else cls_loss * 0.
        loss = self.loss_weight * (cls_loss + self.scale_align_weight * scale_loss)
        counts = torch.bincount(labels, minlength=self.num_classes)
        self.last_stats = dict(objects=int(labels.numel()),
                               classes=int(labels.unique().numel()),
                               scale_count=len(available),
                               class_loss=float(cls_loss.detach()),
                               scale_align=float(scale_loss.detach()),
                               usable=int(counts[counts >= 2].sum()))
        return loss


@MODELS.register_module()
class MAS2ACrossScaleContrastRefineHead(MAS2AContrastiveRefineHead):
    """MA-SENet refine head with GT-aligned cross-scale contrast."""
    def __init__(self, *args, contrast_cfg: Optional[dict] = None, **kwargs):
        cfg = dict(contrast_cfg or {})
        super().__init__(*args, contrast_cfg=cfg, **kwargs)
        if self.contrast_enabled:
            self.contrast_branch = CrossScaleInstanceBranch(
                in_channels=self.feat_channels,
                num_classes=self.cls_out_channels,
                levels=tuple(cfg.get('levels', (0, 1, 2))),
                roi_out_size=int(cfg.get('roi_out_size', 7)),
                proj_dim=int(cfg.get('proj_dim', 128)),
                hidden_dim=int(cfg.get('hidden_dim', 256)),
                temperature=float(cfg.get('temperature', 0.1)),
                loss_weight=float(cfg.get('loss_weight', 0.1)),
                max_per_class=int(cfg.get('max_per_class', 32)),
                level_strides=self._resolve_level_strides(cfg),
                scale_align_weight=float(cfg.get('scale_align_weight', 0.25)))


__all__ = ['MAS2ACrossScaleContrastRefineHead']
