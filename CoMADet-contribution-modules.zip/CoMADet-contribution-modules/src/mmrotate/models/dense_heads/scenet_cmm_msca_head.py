"""SCENet initial head with an optional CMM-to-M-SCA training path.

The original SCENet SCA term is preserved verbatim through
``SCENetS2AHead``.  This adapter adds the SODA-A-tested CMM/M-SCA path as a
separate auxiliary loss; it does not replace or alter native SCENet SCA.

Both ablation arms instantiate this same class, miner, and loss.  The B0 arm
sets ``cmm_msca_enabled=False`` and must be functionally equivalent to the
original SCENet head.  The CMM arm enables online window mining and M-SCA.
"""

from collections import Counter
from typing import Optional, Sequence, Tuple

import torch
from torch import Tensor

from mmrotate.registry import MODELS
from ..losses.msca_loss import ConfusionMatrixMiner, MSCALoss
from .scenet_s2a_head import SCENetS2AHead


@MODELS.register_module()
class SCENetCMMMSCAS2AHead(SCENetS2AHead):
    """SCENet S2A head with a switchable online-CMM + M-SCA loss.

    ``cmm_msca_enabled`` is the only intended arm-level difference.  Miner and
    loss modules are constructed in both arms, so the common E0 checkpoint has
    identical state-dict keys and shapes.  These modules contain no trainable
    parameters; the miner contributes only fixed-shape buffers.
    """

    def __init__(self,
                 *args,
                 cmm_msca_enabled: bool = False,
                 confusion_miner=None,
                 msca_loss=None,
                 msca_levels: Sequence[int] = (0,),
                 **kwargs):
        super().__init__(*args, **kwargs)
        self.cmm_msca_enabled = bool(cmm_msca_enabled)
        self.confusion_miner = self._build_optional(
            confusion_miner, ConfusionMatrixMiner)
        self.msca_loss = self._build_optional(msca_loss, MSCALoss)
        self.msca_levels = tuple(int(level) for level in msca_levels)
        if self.cmm_msca_enabled and (
                self.confusion_miner is None or self.msca_loss is None):
            raise ValueError(
                'The CMM arm requires both confusion_miner and msca_loss')
        if (self.confusion_miner is None
                or getattr(self.confusion_miner, 'mode', None) != 'window'):
            raise ValueError(
                'SCENet CMM adapter requires the production window miner')
        num_classes = int(self.confusion_miner.num_classes)
        window_size = int(self.confusion_miner.window_size)
        self.register_buffer(
            '_cmm_window_snapshot',
            torch.zeros(window_size, num_classes, num_classes))
        self.register_buffer('_cmm_window_count', torch.zeros((), dtype=torch.long))
        self._cmm_logits = []
        self._cmm_labels = []
        self._cmm_level_calls = 0
        self.last_cmm_stats = {}
        self._cmm_epoch_counts = Counter()
        self._cmm_epoch_pairs = Counter()
        self._cmm_epoch_loss_sum = 0.0
        self._cmm_epoch_loss_nonzero = 0

    @torch.no_grad()
    def _sync_window_snapshot_from_miner(self):
        """Mirror the miner's Python window into ordinary checkpoint buffers."""
        queue = getattr(self.confusion_miner, '_queue', None)
        if queue is None:
            raise RuntimeError('The configured window miner has no queue state')
        if len(queue) > self._cmm_window_snapshot.size(0):
            raise RuntimeError('CMM queue exceeds configured window size')
        self._cmm_window_snapshot.zero_()
        for index, counts in enumerate(queue):
            self._cmm_window_snapshot[index].copy_(counts)
        self._cmm_window_count.fill_(len(queue))

    @torch.no_grad()
    def _restore_window_snapshot_to_miner(self):
        """Restore a checkpointed window into the miner's Python queue."""
        queue_count = int(self._cmm_window_count.item())
        capacity = self._cmm_window_snapshot.size(0)
        if not 0 <= queue_count <= capacity:
            raise RuntimeError(f'Invalid saved CMM window length {queue_count}')
        device = self.confusion_miner.confusion.device
        self.confusion_miner._queue = [
            self._cmm_window_snapshot[index].to(device=device).clone()
            for index in range(queue_count)
        ]

    @staticmethod
    def _build_optional(module_or_cfg, module_type):
        if module_or_cfg is None:
            return None
        if isinstance(module_or_cfg, dict):
            return MODELS.build(module_or_cfg)
        if isinstance(module_or_cfg, module_type):
            return module_or_cfg
        raise TypeError(
            f'Expected {module_type.__name__} or config, got '
            f'{type(module_or_cfg).__name__}')

    def set_current_epoch(self, epoch: int) -> None:
        """Optional epoch interface for the existing MA-SENet epoch hook."""
        self.current_epoch = int(epoch)
        if self.confusion_miner is not None:
            self.confusion_miner.set_epoch(epoch)
            self._restore_window_snapshot_to_miner()

    def loss_by_feat_single(self, cls_score: Tensor, bbox_pred: Tensor,
                            anchors: Tensor, labels: Tensor,
                            label_weights: Tensor, bbox_targets: Tensor,
                            bbox_weights: Tensor, avg_factor: int) -> tuple:
        result = super().loss_by_feat_single(
            cls_score, bbox_pred, anchors, labels, label_weights,
            bbox_targets, bbox_weights, avg_factor)
        level = self._cmm_level_calls
        self._cmm_level_calls += 1
        if not self.cmm_msca_enabled or level not in self.msca_levels:
            return result

        num_imgs, _, height, width = cls_score.shape
        num_priors = int(getattr(self, 'num_base_priors', 1))
        logits = cls_score.permute(0, 2, 3, 1).reshape(
            num_imgs, height * width, num_priors,
            self.cls_out_channels).reshape(-1, self.cls_out_channels)
        flat_labels = labels.reshape(-1).to(
            device=logits.device, dtype=torch.long)
        if flat_labels.numel() != logits.size(0):
            raise RuntimeError(
                'SCENet CMM anchor/logit alignment mismatch: '
                f'{flat_labels.numel()} labels vs {logits.size(0)} logits')
        # Retina-style background is num_classes; the CMM/M-SCA API uses -1.
        flat_labels = flat_labels.masked_fill(
            flat_labels >= self.cls_out_channels, -1)
        self._cmm_logits.append(logits)
        self._cmm_labels.append(flat_labels)
        return result

    @staticmethod
    def _image_confusion_counts(batch_gt_instances, pairs):
        confusing_classes = sorted({int(cls) for pair in pairs for cls in pair})
        counts = []
        for instances in batch_gt_instances:
            labels = getattr(instances, 'labels', None)
            if labels is None or labels.numel() == 0 or not confusing_classes:
                counts.append(0)
                continue
            wanted = torch.as_tensor(
                confusing_classes, device=labels.device, dtype=labels.dtype)
            counts.append(int(torch.isin(labels.reshape(-1), wanted).sum().item()))
        return counts

    def _finish_cmm_msca(self, losses, batch_gt_instances):
        if not self.cmm_msca_enabled or not self._cmm_logits:
            return losses

        # The same selected (level-0) logits feed the online miner and loss.
        for logits, labels in zip(self._cmm_logits, self._cmm_labels):
            self.confusion_miner.update(logits, labels)
        self._sync_window_snapshot_from_miner()
        pairs = list(self.confusion_miner.active_pairs())
        self._cmm_epoch_counts['steps'] += 1
        self._cmm_epoch_counts['active_steps'] += int(bool(pairs))
        self._cmm_epoch_counts['empty_steps'] += int(not pairs)
        self._cmm_epoch_counts['window_pair_hits'] += len(pairs)
        for pair in pairs:
            self._cmm_epoch_pairs[tuple(pair)] += 1

        self.last_cmm_stats = {
            'pairs': [list(pair) for pair in pairs],
            # M4's miner does not expose current-vs-history labels. Report the
            # actual provenance granularity: the rolling window, not a guessed
            # per-batch source split.
            'pair_source': 'window' if pairs else 'empty_window',
        }
        if not pairs:
            return losses

        if batch_gt_instances is None:
            raise RuntimeError(
                'CMM-M-SCA needs batch_gt_instances for per-image density')
        image_counts = self._image_confusion_counts(batch_gt_instances, pairs)
        terms = []
        for logits, labels in zip(self._cmm_logits, self._cmm_labels):
            num_imgs = len(batch_gt_instances)
            anchors_per_img = logits.size(0) // max(num_imgs, 1)
            image_index = torch.arange(
                num_imgs, device=logits.device, dtype=torch.long
            ).repeat_interleave(anchors_per_img)
            if image_index.numel() != logits.size(0):
                raise RuntimeError('CMM-M-SCA image/anchor mapping mismatch')
            terms.append(self.msca_loss(
                logits, labels, pairs=pairs, image_index=image_index,
                image_confusion_counts=image_counts))
        term = torch.stack(terms).mean()
        losses['loss_cmm_msca'] = term
        value = float(term.detach().float().cpu())
        self._cmm_epoch_loss_sum += value
        self._cmm_epoch_loss_nonzero += int(value != 0.0)
        self.last_cmm_stats.update({
            'loss': value,
            'loss_proxy': float(getattr(
                self.msca_loss, 'last_stats', {}).get('proxy', 0.0)),
            'loss_align': float(getattr(
                self.msca_loss, 'last_stats', {}).get('align', 0.0)),
            'gamma_mean': float(getattr(
                self.msca_loss, 'last_stats', {}).get('gamma_mean', 0.0)),
            'image_confusion_counts': image_counts,
        })
        return losses

    def loss_by_feat(self, *args, **kwargs):
        self._cmm_logits = []
        self._cmm_labels = []
        self._cmm_level_calls = 0
        batch_gt_instances = kwargs.get('batch_gt_instances')
        if batch_gt_instances is None and len(args) >= 3:
            batch_gt_instances = args[2]
        try:
            losses = super().loss_by_feat(*args, **kwargs)
            return self._finish_cmm_msca(losses, batch_gt_instances)
        finally:
            self._cmm_logits = []
            self._cmm_labels = []
            self._cmm_level_calls = 0

    def cmm_epoch_summary(self):
        steps = int(self._cmm_epoch_counts['steps'])
        result = {
            'steps': steps,
            'active_steps': int(self._cmm_epoch_counts['active_steps']),
            'empty_steps': int(self._cmm_epoch_counts['empty_steps']),
            'window_pair_hits': int(
                self._cmm_epoch_counts['window_pair_hits']),
            'loss_nonzero_steps': self._cmm_epoch_loss_nonzero,
            'loss_mean_nonzero_only': (
                self._cmm_epoch_loss_sum /
                max(self._cmm_epoch_loss_nonzero, 1)),
            'pair_hits': {f'{a}-{b}': count
                          for (a, b), count in sorted(
                              self._cmm_epoch_pairs.items())},
        }
        self._cmm_epoch_counts.clear()
        self._cmm_epoch_pairs.clear()
        self._cmm_epoch_loss_sum = 0.0
        self._cmm_epoch_loss_nonzero = 0
        return result


__all__ = ['SCENetCMMMSCAS2AHead']
