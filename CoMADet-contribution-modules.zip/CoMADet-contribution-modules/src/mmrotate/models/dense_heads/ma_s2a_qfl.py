"""Refine-head adapters for detached rotated-IoU quality focal supervision."""

import torch
from mmcv.ops import box_iou_rotated
from mmdet.structures.bbox import get_box_tensor
from mmrotate.registry import MODELS

from .ma_cross_scale_contrast_v2_head import (
    MAS2AStableCrossScaleContrastRefineHead)


class _QualityFocalRefineMixin:
    """Replace only refine classification targets with detached rotated IoU.

    The predicted boxes are detached before IoU calculation.  Background and
    ignored anchors receive zero quality, and the inherited M-SCA collection
    receives the original NCHW logits and integer labels unchanged.
    """

    def loss_by_feat_single(self, cls_score, bbox_pred, anchors, labels,
                            label_weights, bbox_targets, bbox_weights,
                            avg_factor):
        labels = labels.reshape(-1)
        label_weights = label_weights.reshape(-1)
        cls_score_nchw = cls_score
        cls_score = cls_score.permute(0, 2, 3, 1).reshape(
            -1, self.cls_out_channels)
        target_dim = bbox_targets.size(-1)
        bbox_targets = bbox_targets.reshape(-1, target_dim)
        bbox_weights = bbox_weights.reshape(-1, target_dim)
        bbox_pred = bbox_pred.permute(0, 2, 3, 1).reshape(
            -1, self.bbox_coder.encode_size)

        if not self.reg_decoded_bbox:
            raise ValueError('Quality targets require decoded bbox targets.')
        anchors = anchors.reshape(-1, anchors.size(-1))
        decoded_pred = self.bbox_coder.decode(anchors, bbox_pred)
        decoded_pred = get_box_tensor(decoded_pred)

        positive = (labels >= 0) & (labels < self.num_classes)
        quality = cls_score.new_zeros(labels.shape)
        if bool(positive.any()):
            iou = box_iou_rotated(
                decoded_pred[positive].detach().float(),
                bbox_targets[positive].float(),
                aligned=True,
                clockwise=True)
            quality[positive] = iou.to(dtype=quality.dtype).clamp(0.0, 1.0)

        loss_cls = self.loss_cls(
            cls_score, (labels, quality), label_weights,
            avg_factor=avg_factor)

        # Preserve the exact decoded regression path used by RotatedRetinaHead.
        if self.loss_bbox_type != 'kfiou':
            bbox_pred = decoded_pred
        if self.loss_bbox_type == 'normal':
            loss_bbox = self.loss_bbox(
                bbox_pred, bbox_targets, bbox_weights,
                avg_factor=avg_factor)
        elif self.loss_bbox_type == 'kfiou':
            bbox_pred_decode = self.bbox_coder.decode(anchors, bbox_pred)
            bbox_pred_decode = get_box_tensor(bbox_pred_decode)
            bbox_targets_decode = self.bbox_coder.decode(
                anchors, bbox_targets)
            bbox_targets_decode = get_box_tensor(bbox_targets_decode)
            loss_bbox = self.loss_bbox(
                bbox_pred, bbox_targets, bbox_weights,
                pred_decode=bbox_pred_decode,
                targets_decode=bbox_targets_decode,
                avg_factor=avg_factor)
        else:
            raise NotImplementedError(self.loss_bbox_type)

        self._collect_msca(cls_score_nchw, labels)
        return loss_cls, loss_bbox


@MODELS.register_module()
class MAS2AStableQualityRefineHead(
        _QualityFocalRefineMixin,
        MAS2AStableCrossScaleContrastRefineHead):
    """IC2-compatible QFL head preserving the stable contrast branch layout."""


__all__ = ['MAS2AStableQualityRefineHead']
