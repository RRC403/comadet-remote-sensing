"""MA-SENet detection heads (MID-Head) built on the tested S2A-Net heads.

论文对应关系
------------
* :class:`_MIDGate`            v1 逐尺度门控（历史实现，保留仅供消融对比）。
* :class:`_MIDGateV2`          v2 逐尺度加性门控（历史实现，保留仅供消融对比）。
* :class:`_MultiScaleDiscHead` **v4 多尺度交互判别头**：跨尺度拼接融合 + 判别头，
                               判别头输出被 M-SCA 损失**直接**监督。
* :class:`_NormGatedMIDHead`   **v5/v6 归一化门控注入**：修正 v4 的
                               "全局标量 gamma + 未归一化注入" 病态
                               （逐尺度 gamma 向量 + 逐尺度 RMS 归一化
                               + 门控前 LayerNorm）。
* :class:`_MIDMixin`           把 CMM（论文 3.3）与密度自适应 M-SCA-Loss（论文 3.6）
                               挂到 MMRotate 旋转 anchor 检测头上。
* :class:`MAS2AHead`           stage-1 initial head，M-SCA 损失默认加在这里。
* :class:`MAS2ARefineHead`     stage-2 refine head（可选开启 M-SCA 做消融）。

MID-Head 三代历史实现与 v4（实测结论，详见 MID_V4_REPORT.md）
------------------------------------------------------------
===============  =================================  ==========================
版本              实际数学形式                        实测结果
===============  =================================  ==========================
v1 ``_MIDGate``   ``x + g*(detail(x)*semantic)``     g == 0.0017（12 轮未动）
                                                     → 空操作（分支梯度恒 0）
v2 ``_MIDGateV2`` ``x + g*(D(x) + (sig(.)-0.5)*x)``   val −0.0149 → 有害
v3b = v1 + g=0.1  同 v1                              分支在学（0.1→0.0952），
                                                     但模块仍有害（val −0.0140）
v4（本文件）       跨尺度拼接融合 → 判别头 → M-SCA    待验证
===============  =================================  ==========================

v1/v2/v3b 的共同根因：它们都是**逐尺度门控**——每个尺度各自被同一个全局通道
注意力调制，尺度之间没有任何信息交换；等价于"给每个 FPN 尺度加一个 CBAM 风格
注意力块并加在自顶向下通路上"，这与论文描述的"多尺度交互判别头"不是一回事。

v4 的两个本质区别见 :class:`_MultiScaleDiscHead` 的 docstring。

实现要点（与原论文 SCENet 的差异，写论文附录时需要说明）
-------------------------------------------------------
1. 原 SCENet 的 SCA-Loss 只作用在**最高分辨率的第一层特征**上；本实现
   ``msca_levels=(0,)`` 与之一致。v4 让最高分辨率层的**判别头**同时融合 P4/P5
   的高层语义（跨尺度拼接），因此判别特征不再是纯边缘细节。
2. 原论文把 SCA-Loss 加在分类分支 focal loss **之前**；本实现把 M-SCA 项与 focal
   loss 并行相加。二者作用于同一个 ``cls_score`` 张量，梯度注入点等价。
   v4 通过 ``mid_cfg.msca_source='disc'`` 把该张量换成判别头输出，见
   :meth:`_MIDMixin.disc_logits_for_msca`。
3. 密度自适应权重 :math:`\\gamma_m` 需要**每张图属于激活混淆对的 GT 目标数**
   （:math:`N^{conf}_m`），:meth:`_MIDMixin._finish_msca` 从 ``batch_gt_instances``
   统计该值，避免退化成 anchor 计数（那会让 :math:`\\gamma_m` 恒等于 1，使
   论文创新点 5 失效）。
4. CMM 的混淆矩阵**始终**统计检测头自己的 ``cls_score``（检测口径不变）；
   判别头输出只替换 M-SCA **损失**的输入，不替换 CMM 的输入。
5. ``mid_cfg.variant`` 派发：``'v1'``（默认，保持冻结基线行为）/ ``'v2'`` /
   ``'v4'``。v1/v2 是逐尺度门控，v4 才是论文描述的跨尺度交互判别头。
"""

from typing import Dict, List, Optional, Sequence, Tuple

import torch
from torch import Tensor, nn
from torch.nn import functional as F
from mmcv.ops import box_iou_rotated
from mmdet.structures.bbox import get_box_tensor

from mmrotate.registry import MODELS
from ..losses.sca_cossim_module_loss import SCACosSimModuleLoss
from ..losses.ugs_loss import UGSLocalizationLoss
from .s2a_head import S2AHead, S2ARefineHead

class _MIDGate(nn.Module):
    """MID-Head multi-scale interaction (论文 3.4).

    A pooled semantic descriptor from the deepest feature level modulates every
    level through a channel gate, while a depthwise 3x3 path keeps local edge
    detail.  ``gamma`` starts at zero, so the block is an exact identity at
    initialisation (safe S2A-Net warm start).
    """

    def __init__(self, channels: int, reduction: int = 4,
                 gamma_init: float = 0.0) -> None:
        super().__init__()
        hidden = max(channels // reduction, 8)
        self.semantic = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=True),
            nn.Sigmoid(),
        )
        self.detail = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels,
                      bias=False),
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.ReLU(inplace=True),
        )
        # gamma_init=0.0 保持"恒等起步"（兼容旧行为）。
        # 但实测 gamma 从 0 出发会被 weight decay 拉回 0、永远打不开，
        # 必须配合"排除权重衰减 + 更大学习率"才能真正激活该模块。
        self.gamma = nn.Parameter(torch.full((1, ), float(gamma_init)))

    def forward(self, feats: Tuple[Tensor, ...]) -> Tuple[Tensor, ...]:
        if len(feats) == 0:
            return feats
        semantic = F.adaptive_avg_pool2d(feats[-1], 1)
        semantic = self.semantic(semantic)
        out = []
        for feat in feats:
            gate = semantic.expand(-1, -1, feat.shape[-2], feat.shape[-1])
            out.append(feat + self.gamma * (self.detail(feat) * gate))
        return tuple(out)

class _MIDGateV2(nn.Module):
    """修正版 MID-Head 多尺度交互（论文 3.4 的可用实现）。

    与原 :class:`_MIDGate` 的区别（原版保留不动，便于消融对比）：

    ============  ==============================  ==============================
    项目           原版 _MIDGate                    修正版 _MIDGateV2
    ============  ==============================  ==============================
    gamma 初值     0.0（恒等，但梯度为 0）          1.0（梯度立即流通）
    恒等起步靠     把 gamma 置零                    分支末层零初始化
    分支末层       带 ReLU（只能输出非负修正）      去掉 ReLU（可正可负）
    语义分支形式   乘性门控 detail*gate             加性 (sigmoid-0.5)*x
    初始化梯度     全部为 0                        全部非零
    ============  ==============================  ==============================

    数学形式::

        y = x + gamma * [ D(x) + ( sigmoid(S(GAP(x))) - 0.5 ) * x ]

    其中 ``D`` 的末层与 ``S`` 的末层均零初始化，故初始化时 ``y = x`` 严格成立，
    但 ``dy/dtheta`` 不为零，模块从第 1 步起就能学习。
    """

    def __init__(self, channels: int, reduction: int = 4,
                 gamma_init: float = 1.0) -> None:
        super().__init__()
        hidden = max(channels // reduction, 8)
        self.semantic = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=True),
            nn.Sigmoid(),
        )
        # 末层不带 ReLU，允许正负两个方向的修正
        self.detail = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels,
                      bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 1, bias=False),
        )
        # 关键：用"分支零初始化"实现恒等起步，而不是把 gamma 置零
        nn.init.zeros_(self.detail[-1].weight)
        nn.init.zeros_(self.semantic[-2].weight)
        nn.init.zeros_(self.semantic[-2].bias)
        self.gamma = nn.Parameter(torch.full((1, ), float(gamma_init)))

    def forward(self, feats: Tuple[Tensor, ...]) -> Tuple[Tensor, ...]:
        if len(feats) == 0:
            return feats
        semantic = F.adaptive_avg_pool2d(feats[-1], 1)
        semantic = self.semantic(semantic) - 0.5
        out = []
        for feat in feats:
            gate = semantic.expand(-1, -1, feat.shape[-2], feat.shape[-1])
            correction = self.detail(feat) + gate * feat
            out.append(feat + self.gamma * correction)
        return tuple(out)


class _MultiScaleDiscHead(nn.Module):
    """MID-Head **v4**：多尺度交互判别头（论文 3.4 的忠实实现）。

    与 v1 :class:`_MIDGate` / v2 :class:`_MIDGateV2` 的**本质**区别
    -------------------------------------------------------------
    1. **跨尺度拼接融合，而不是逐尺度门控。**
       ``fuse_levels``（默认 P3/P4/P5）先统一到同一分辨率（双线性上采样），
       再沿**通道维拼接**，由一个 1×1 卷积融合成单张判别特征 ``F``。
       不同尺度的信息因此在 ``F`` 里真正发生了交互。
       v1/v2 里每个尺度只被**同一个**全局通道门各自调制一次，
       尺度之间没有任何信息交换 —— 那不是"多尺度交互"。
    2. **判别头输出被 M-SCA 损失直接监督。**
       ``F`` 经判别头得到 ``[N, num_classes, H0, W0]`` 分数图，作为
       :class:`MSCALoss` 的 ``logits`` 输入（``mid_cfg.msca_source='disc'``），
       梯度经判别头 → 融合层 → P3/P4/P5 回流。
       v1/v2 的判别分支只受主检测损失**间接**影响，且 ``gamma_init=0`` 时
       两分支梯度**恒等于 0**（实测 γ 12 轮停在 0.0017）。
    3. **γ 是"注入强度"而不是"开关"，且从近似恒等起步。**
       v1 用 ``gamma_init=0`` 换取恒等起步 → 分支永久死掉（实测）。
       v3b 用 ``gamma_init=0.1`` → 一上来就扰动 10%，模块有害。
       本实现 ``gamma_init=0.01``：初始扰动只有 1% 量级（**近似**恒等），
       但 γ 与融合层/判别头的梯度**都非零**，模块从第 1 步起就在学。

    结构::

        P3(浅层,细节)   P4        P5(深层,语义)
             |          |            |
             +---- 统一分辨率 --------+        F.interpolate(bilinear)
                        |
              concat(dim=1)  ->  [N, sum(C), H0, W0]
                        |
                  1x1 Conv -> ReLU              跨尺度融合 = F
                        |
             +----------+-----------+
             |                      |
        判别头 disc_head        逐层回注 proj_l(F)
             |                      |
      [N, C, H0, W0]            feats[l] + gamma * proj_l(F)
             |
      * MSCALoss(logits=disc, labels=P3 anchor labels) *

    Args:
        in_channels (int): 每个输入尺度的通道数（S2A 头是单一 int）。
        num_classes (int): 判别头输出的类别数；必须等于检测头的
            ``cls_out_channels``，否则无法与 anchor 标签对齐。
        fuse_levels (Sequence[int]): 参与跨尺度拼接的尺度下标（默认 P3/P4/P5）。
            下标 0 的分辨率作为融合分辨率 ``H0 x W0``，其余尺度上采样到它。
        fuse_channels (int): 融合后的通道数。
        disc (bool): 是否构造/使用判别头。``False`` 时 M-SCA 回退到 anchor 分数。
        disc_convs (int): 判别头里 3x3 卷积的层数（0 = 单层 1x1，最省算力）。
        inject (bool): 是否把融合特征按 γ 回注到 ``inject_levels``。
        inject_levels (Sequence[int] | None): 回注的尺度下标；默认 = ``fuse_levels``。
        gamma_init (float): γ 初值，默认 0.01（近似恒等起步 + 梯度非零）。
        proj_zero_init (bool): 回注投影层零初始化（默认 False）。置 True 时
            回注在 step 0 严格为零，因此可与 ``gamma_init=1.0`` 组合成
            "严格恒等起步 + 非零梯度" 的 LayerScale 配方，且把 "回注强度"
            这件事从 γ 这个标量上解耦出去。
        gamma_freeze (bool): γ 不参与优化（默认 False）。值仍写入 state_dict，
            但 ``requires_grad=False``，因此优化器与梯度都不会再改它 ——
            用于检验 "γ 被 M-SCA 的梯度推大" 这一风险假设。
        upsample_mode (str): 统一分辨率用的插值方式。

    Note:
        ``disc`` 与 ``inject`` **不能同时为 False** —— 那样模块就是纯空操作，
        这正是 v1 的失败模式，因此在这里直接报错而不是静默接受。
    """

    def __init__(self,
                 in_channels: int,
                 num_classes: int = 9,
                 fuse_levels: Sequence[int] = (0, 1, 2),
                 fuse_channels: int = 256,
                 disc: bool = True,
                 disc_convs: int = 0,
                 inject: bool = True,
                 inject_levels: Optional[Sequence[int]] = None,
                 gamma_init: float = 0.01,
                 upsample_mode: str = 'bilinear',
                 proj_zero_init: bool = False,
                 gamma_freeze: bool = False) -> None:
        super().__init__()
        in_channels = int(in_channels)
        self.in_channels = in_channels
        self.num_classes = int(num_classes)
        self.fuse_levels = tuple(int(i) for i in fuse_levels)
        if not self.fuse_levels:
            raise ValueError('fuse_levels must not be empty')
        self.fuse_channels = int(fuse_channels)
        self.disc_enabled = bool(disc)
        self.inject_enabled = bool(inject)
        if not self.disc_enabled and not self.inject_enabled:
            raise ValueError(
                '_MultiScaleDiscHead: disc=False 且 inject=False 会让整个 '
                'MID-Head 变成空操作（v1 的失败模式）。至少要开一个。')
        self.inject_levels = (tuple(int(i) for i in inject_levels)
                              if inject_levels is not None
                              else self.fuse_levels)
        self.upsample_mode = str(upsample_mode)
        #: 回注投影层零初始化（ControlNet / LayerScale 配方）：proj==0 时
        #: 回注严格为零，因此 gamma 可以取 1.0 而不产生任何初始扰动。
        self.proj_zero_init = bool(proj_zero_init)
        #: gamma 不参与优化（值仍进 state_dict，便于日志与 checkpoint 对齐）。
        self.gamma_freeze = bool(gamma_freeze)

        # ---- 跨尺度拼接融合：concat(C*n_levels) --1x1--> fuse_channels ----
        self.fuse = nn.Conv2d(in_channels * len(self.fuse_levels),
                              self.fuse_channels, 1, bias=True)
        self.fuse_act = nn.ReLU(inplace=True)

        # ---- 判别头：fuse_channels --(可选 3x3)--1x1--> num_classes ----
        if self.disc_enabled:
            layers: List[nn.Module] = []
            for _ in range(max(0, int(disc_convs))):
                layers += [
                    nn.Conv2d(self.fuse_channels, self.fuse_channels, 3,
                              padding=1, bias=True),
                    nn.ReLU(inplace=True),
                ]
            layers.append(
                nn.Conv2d(self.fuse_channels, self.num_classes, 1, bias=True))
            self.disc_head = nn.Sequential(*layers)
        else:
            self.disc_head = None

        # ---- 逐层回注 ----
        if self.inject_enabled:
            self.proj = nn.ModuleList([
                nn.Conv2d(self.fuse_channels, in_channels, 1, bias=True)
                for _ in self.inject_levels
            ])
            if self.proj_zero_init:
                # 严格恒等起步：out = feat + gamma * 0 = feat（与 gamma 无关）。
                for conv in self.proj:
                    nn.init.zeros_(conv.weight)
                    nn.init.zeros_(conv.bias)
            self.gamma = nn.Parameter(torch.full((1, ), float(gamma_init)),
                                      requires_grad=not self.gamma_freeze)
        else:
            self.proj = None
            # 占位参数：即使不回注也保留 gamma，便于日志/消融口径统一，
            # 并保证 state_dict 形状在不同 inject 取值下可比对。
            self.gamma = nn.Parameter(torch.full((1, ), float(gamma_init)),
                                      requires_grad=not self.gamma_freeze)

        #: 最近一次 forward 的中间结果（不参与 state_dict，训练用）
        self._mid_fused: Optional[Tensor] = None
        self._mid_disc_logits: Optional[Tensor] = None

    # ------------------------------------------------------------------ #
    def _resize(self, feat: Tensor, size) -> Tensor:
        if tuple(feat.shape[-2:]) == tuple(size):
            return feat
        if self.upsample_mode == 'nearest':
            return F.interpolate(feat, size=size, mode='nearest')
        return F.interpolate(feat, size=size, mode='bilinear',
                             align_corners=False)

    def forward(self, feats):
        """Args: feats (Sequence[Tensor]) 升序排列的多尺度特征。

        Returns:
            tuple[Tensor]: 与输入同长度、同形状的多尺度特征（回注后）。
            判别头输出存在 ``self._mid_disc_logits`` 上供损失使用。
        """
        feats = tuple(feats)
        if not feats:
            return feats
        num_levels = len(feats)
        for lvl in set(self.fuse_levels) | set(self.inject_levels):
            if lvl < 0 or lvl >= num_levels:
                raise ValueError(
                    f'MID-Head v4: level {lvl} out of range, '
                    f'got {num_levels} feature levels')

        ref_size = feats[self.fuse_levels[0]].shape[-2:]
        parts = [self._resize(feats[lvl], ref_size) for lvl in self.fuse_levels]
        fused = self.fuse_act(self.fuse(torch.cat(parts, dim=1)))
        self._mid_fused = fused
        self._mid_disc_logits = (self.disc_head(fused)
                                 if self.disc_enabled else None)

        if not self.inject_enabled:
            return feats

        out = list(feats)
        for slot, lvl in enumerate(self.inject_levels):
            target = out[lvl]
            corr = self._resize(self.proj[slot](fused), target.shape[-2:])
            out[lvl] = target + self.gamma * corr
        return tuple(out)

    def clear_cache(self) -> None:
        """Drop the references to the last forward's tensors."""
        self._mid_fused = None
        self._mid_disc_logits = None


class _NormGatedMIDHead(nn.Module):
    r"""MID-Head **v5 / v6**：归一化门控注入（Norm-Gated Injection）。

    为什么需要这一代（v4 的实测证伪）
    ---------------------------------
    v4 的回注是 ``feats[l] += gamma * proj_l(F)``，``gamma`` 是**一个全局标量**
    （1 个参数），``proj_l(F)`` 是**未归一化**的原始卷积输出。实测后果：

    * ``dL/dgamma = sum_l <dL/d out_l, proj_l(F)>`` —— 这个梯度是
      **3 x 256 x H x W = 12.6M 个元素的内积**，天然是全部 11 个 ``mid_gate``
      参数里量级最大的一个（实测 ``1.034242e+01``，是第二名 ``fuse.weight``
      的 3.1 倍、是判别头权重的 32 倍）。见 MID_V4_REPORT.md 专项 1。
    * 于是 "回注强度" 这件事被压缩到一个**病态的一维汇总读数**上：
      γ 要么不动，要么被 M-SCA 的梯度一把推大，没有中间状态。
    * ``proj_l`` 的尺度和 ``gamma`` 的尺度**互相耦合**：把 ``proj_l`` 整体
      放大 10 倍、把 ``gamma`` 缩小 10 倍，前向完全一样，但梯度分配完全不同。
      这使优化器无法独立地控制 "注入强度" 与 "注入内容"。

    本代的三个结构性修正（每一个都对应上面的一个病态）
    ---------------------------------------------------
    1. **标量 gamma -> 逐尺度向量 gamma (shape ``[L]``)。**
       每层的梯度只由该层自己的修正张量决定，不再是 3 层求和，
       量级天然除以 L，且各层可以独立地学 "该注入多少"。
    2. **注入张量归一化（``rms_norm``）。** 注入前把修正张量按
       **逐样本、逐尺度的 RMS** 归一化：

       .. math::  u_{l,e} = \frac{c_{l,e}}{\sqrt{\frac{1}{CHW}\sum_{c,h,w} c_{l,c,h,w}^2} + \epsilon}

       于是第 (3) 步的梯度变成

       .. math::  \frac{\partial L}{\partial \gamma_l}
                  = \sum_e \frac{\partial L}{\partial z_{l,e}} u_{l,e},
                  \qquad \|u_l\|_{\mathrm{rms}} = 1

       右边是**归一化向量**与梯度的内积 —— 量级只由 ``dL/dz`` 决定，
       **与修正张量自己的尺度完全解耦**。这正是 v4 缺的那一步。
       同时 ``\|\gamma_l u_l\|_{\mathrm{rms}} = |\gamma_l|``：
       **注入强度被 gamma 直接、线性地控制**，训练中不会失控。
    3. **门控前的归一化（``gate='layernorm'``）。** 融合特征先过
       ``GroupNorm(1, C)`` 再送入门控与判别头。跨尺度特征的通道尺度本来就
       不齐（不同 level 的双线性上采样 + 拼接），LayerNorm 把门控的输入
       条件数压到 O(1)，使 1x1 门控权重可以用**小随机初始化**而不是
       依赖于外层标量的尺度。

    前向形式
    --------
    ::

        # 1) 跨尺度融合（与 v4 相同：统一分辨率 -> concat -> 1x1 -> ReLU）
        F = ReLU(W_f * LN_gate(concat_l resize(feats[l])))
        # 2) 残差分支（v5: 单 1x1；v6: StarNet 式逐元素乘性门）
        r = C(F)                                     # v5: out C ; v6: 2C -> 门
        # 3) 逐尺度 RMS 归一化 + 逐尺度可学习缩放
        u_l = r / rms(r)                             # 逐样本逐尺度
        z_l = gamma_l * u_l                          # gamma: [L] 可学习
        # 4) 回注（gamma 初值 0.01 -> 近似恒等起步）
        out[l] = feats[l] + resize(z_l, feats[l].shape[-2:])

    恒等起步与梯度（三项要求的机械保证）
    ------------------------------------
    * **近似恒等**：``gamma`` 初值 0.01、``\|u_l\|_{\mathrm{rms}} = 1``，
      故 ``\|z_l\|_{\mathrm{rms}} = 0.01`` —— 初值扰动恒为 **1% 量级**，
      与 ``proj_l`` 的初始化尺度无关（这一点也是归一化给的）。
    * **分支非零梯度**：残差分支权重用**小随机**初始化
      （``std=0.02``，**不是**零初始化），故 ``u_l`` 不为零且逐通道不同，
      门控/判别头/融合层的梯度全部非零；``gamma`` 的梯度
      ``sum_e (dL/dz) u`` 也非零。
      零初始化（LayerScale / ControlNet 配方）在**这个结构下不是好选择**：
      ``c = 0`` 会让 ``u = 0/eps``，判别头不再影响注入分支，
      而 ``gamma`` 又会把 ``dL/dc`` 整体乘成 0（``gamma_init > 0`` 时
      仅 gamma 自己拿到梯度）。
    * **不会重蹈 v1**：v1 的失效是 "``feat + gamma * (...)``，``gamma = 0``"，
      乘法把整条分支的梯度**恒等于 0**。这里 ``gamma`` 初值 0.01 而非 0，
      且梯度通路不经过任何零因子。

    Args:
        in_channels (int): 每个输入尺度的通道数（S2A 头是单一 int）。
        num_classes (int): 判别头输出的类别数，须等于 ``cls_out_channels``。
        fuse_levels (Sequence[int]): 参与跨尺度描述子与拼接的尺度下标。
        fuse_channels (int): 融合后的通道数。
        disc (bool): 是否构造判别头（其输出可被 M-SCA 直接监督）。
        disc_convs (int): 判别头里 3x3 卷积的层数（0 = 单层 1x1）。
        inject (bool): 是否回注。
        inject_levels (Sequence[int] | None): 回注的尺度下标。
        gamma_init (float): ``gamma`` 向量初值，默认 0.01（≈1% 扰动）。
        upsample_mode (str): 统一分辨率用的插值方式。
        gate (str): ``'layernorm'``（默认）或 ``'none'``。
            ``'none'`` **只**用于专项验证 2 的对照臂 —— 其余一切相同，
            用于实证 "归一化门控真的改变了输出"。
        rms_norm (bool): 是否对注入张量做逐尺度 RMS 归一化（默认 True）。
            False = 退化成 v4 式的 "原始尺度注入"，仅用于对照。
        residual_variant (str): ``'v5'``（单 1x1）或 ``'v6'``（StarNet 门）。
        star (bool): 是否启用 v6 的逐元素乘性门（显式覆盖 residual_variant）。
        gate_eps (float): 门控归一化与 RMS 归一化的数值下限。
        inject_weight_std (float): 回注投影层的初始化标准差（小随机）。

    Note:
        ``disc`` 与 ``inject`` **不能同时为 False** —— 那样模块是纯空操作，
        这正是 v1 的失败模式，因此直接报错而不是静默接受。
    """

    def __init__(self,
                 in_channels: int,
                 num_classes: int = 9,
                 fuse_levels: Sequence[int] = (0, 1, 2),
                 fuse_channels: int = 256,
                 disc: bool = True,
                 disc_convs: int = 0,
                 inject: bool = True,
                 inject_levels: Optional[Sequence[int]] = None,
                 gamma_init: float = 0.01,
                 upsample_mode: str = 'bilinear',
                 gate: str = 'layernorm',
                 rms_norm: bool = True,
                 residual_variant: str = 'v5',
                 star: bool = False,
                 gate_eps: float = 1e-6,
                 inject_weight_std: float = 0.02,
                 gamma_max: float = 0.0) -> None:
        super().__init__()
        in_channels = int(in_channels)
        self.in_channels = in_channels
        self.num_classes = int(num_classes)
        #: gamma 的硬上界。0.0 = 不做约束（保持旧行为）。
        #: 实测旧行为下 gamma 会跑到 -0.36 等（注入变成"减特征"），
        #: 设成 0.02~0.05 可把注入强度限制在设计承诺的量级。
        self.gamma_max = float(gamma_max)
        #: 反解后的 gamma 初值。因为 gamma_eff = gamma_max*tanh(gamma)，
        #: 若直接把 gamma 初始化成 gamma_init，则 gamma_eff(0) = gamma_max*tanh(gamma_init)
        #: 会远小于 gamma_init（如 0.05*tanh(0.01)=0.0005，小 20 倍），
        #: 破坏"近似恒等起步（1% 扰动）"的设计承诺。
        #: 故反解 gamma0 = atanh(gamma_init/gamma_max)，使 gamma_eff(0) == gamma_init。
        #: gamma_max <= 0 时 gamma0 = gamma_init（逐位保持旧行为）。
        if self.gamma_max > 0.0:
            _ratio = min(abs(float(gamma_init)) / self.gamma_max, 1.0 - 1e-6)
            self.gamma_init_resolved = float(
                __import__('math').copysign(
                    __import__('math').atanh(_ratio), float(gamma_init)))
        else:
            self.gamma_init_resolved = float(gamma_init)
        self.fuse_levels = tuple(int(i) for i in fuse_levels)
        if not self.fuse_levels:
            raise ValueError('fuse_levels must not be empty')
        self.fuse_channels = int(fuse_channels)
        self.disc_enabled = bool(disc)
        self.inject_enabled = bool(inject)
        if not self.disc_enabled and not self.inject_enabled:
            raise ValueError(
                '_NormGatedMIDHead: disc=False 且 inject=False 会让整个 '
                'MID-Head 变成空操作（v1 的失败模式）。至少要开一个。')
        self.inject_levels = (tuple(int(i) for i in inject_levels)
                              if inject_levels is not None
                              else self.fuse_levels)
        self.upsample_mode = str(upsample_mode)
        self.gate_kind = str(gate).lower()
        if self.gate_kind not in ('layernorm', 'none'):
            raise ValueError(
                f"gate must be 'layernorm' or 'none', got {gate!r}")
        self.rms_norm = bool(rms_norm)
        self.star = bool(star) or str(residual_variant).lower() in ('v6',
                                                                   'mid_v6')
        self.gate_eps = float(gate_eps)
        self.inject_weight_std = float(inject_weight_std)

        # ---- 门控前的归一化（LayerNorm 等价实现，避免 batch 统计） ----
        if self.gate_kind == 'layernorm':
            # GroupNorm(1, C) == 逐样本 LayerNorm(C,H,W)，但不引入 batch 统计
            self.gate_norm = nn.GroupNorm(1, self.fuse_channels)
        else:
            self.gate_norm = None

        # ---- 注入张量的逐尺度 RMS 归一化（可学习仿射，初值=恒等） ----
        if self.rms_norm:
            self.rms_scale = nn.Parameter(torch.ones(1, in_channels, 1, 1))
            self.rms_bias = nn.Parameter(torch.zeros(1, in_channels, 1, 1))
        else:
            self.rms_scale = None
            self.rms_bias = None

        # ---- 跨尺度拼接融合：concat(C*n_levels) --1x1--> fuse_channels ----
        self.fuse = nn.Conv2d(in_channels * len(self.fuse_levels),
                              self.fuse_channels, 1, bias=True)
        self.fuse_act = nn.ReLU(inplace=True)

        # ---- 判别头：fuse_channels --(可选 3x3)--1x1--> num_classes ----
        if self.disc_enabled:
            layers: List[nn.Module] = []
            for _ in range(max(0, int(disc_convs))):
                layers += [
                    nn.Conv2d(self.fuse_channels, self.fuse_channels, 3,
                              padding=1, bias=True),
                    nn.ReLU(inplace=True),
                ]
            layers.append(
                nn.Conv2d(self.fuse_channels, self.num_classes, 1, bias=True))
            self.disc_head = nn.Sequential(*layers)
        else:
            self.disc_head = None

        # ---- 残差分支（注入内容的产生器） ----
        if self.inject_enabled:
            if self.star:
                # v6：StarNet 式 "高维逐元素乘性门"
                #   1x1: C -> 2C, 拆成 (a, b)，b 过 ReLU 后与 a 逐元素相乘
                #   再用 1x1 收回 C。纯 1x1，无 3x3、无 BN，算力可忽略。
                self.star_expand = nn.Conv2d(self.fuse_channels,
                                             2 * self.fuse_channels, 1,
                                             bias=True)
                self.star_gate = nn.Conv2d(self.fuse_channels, self.in_channels,
                                           1, bias=True)
            else:
                self.star_expand = None
                self.star_gate = None
            self.proj = nn.Conv2d(self.fuse_channels, self.in_channels, 1,
                                  bias=True)
        else:
            self.star_expand = None
            self.star_gate = None
            self.proj = None

        # ---- 逐尺度可学习缩放：shape [L]，不是 v4 的 [1] ----
        n_scale = len(self.inject_levels) if self.inject_enabled else 0
        # 注意：用反解后的 gamma_init_resolved（gamma_max>0 时它使
        # gamma_eff(0) == gamma_init，保住"1% 近似恒等起步"）。
        self.gamma = nn.Parameter(
            torch.full((max(n_scale, 1), ), self.gamma_init_resolved))
        self.gamma_per_level = bool(self.inject_enabled)

        self._init_residual_weights()

        #: 最近一次 forward 的中间结果（不参与 state_dict，训练用）
        self._mid_fused: Optional[Tensor] = None
        self._mid_disc_logits: Optional[Tensor] = None

    # ------------------------------------------------------------------ #
    def _init_residual_weights(self) -> None:
        """小随机初始化回注分支（**不是**零初始化，见类 docstring）。"""
        if not self.inject_enabled or self.proj is None:
            return
        for conv in (self.proj, self.star_gate):
            if conv is not None:
                nn.init.normal_(conv.weight, mean=0.0,
                                std=self.inject_weight_std)
                if conv.bias is not None:
                    # 偏置置零：偏置在空间上是常数，会退化成 "全局特征平移"，
                    # 既不能表达空间门控，又会在 RMS 归一化后与权重梯度对冲。
                    nn.init.zeros_(conv.bias)
        if self.star_expand is not None:
            nn.init.normal_(self.star_expand.weight, mean=0.0,
                            std=self.inject_weight_std)
            if self.star_expand.bias is not None:
                nn.init.zeros_(self.star_expand.bias)

    def _resize(self, feat: Tensor, size) -> Tensor:
        if tuple(feat.shape[-2:]) == tuple(size):
            return feat
        if self.upsample_mode == 'nearest':
            return F.interpolate(feat, size=size, mode='nearest')
        return F.interpolate(feat, size=size, mode='bilinear',
                             align_corners=False)

    def _gamma_eff(self) -> Tensor:
        """返回有界化后的逐尺度缩放系数。

        ``gamma_max <= 0`` 时原样返回 ``self.gamma``（旧行为，逐位兼容）；
        否则返回 ``gamma_max * tanh(gamma)``，把注入强度硬限制在
        ``(-gamma_max, +gamma_max)`` 内。
        """
        if self.gamma_max <= 0.0:
            return self.gamma
        return self.gamma_max * torch.tanh(self.gamma)

    def _rms_unit(self, corr: Tensor) -> Tensor:
        """逐样本逐尺度 RMS 归一化（+ 可学习仿射，初值 = 恒等）。

        ``||u||_rms == 1`` 对每个 (样本, 尺度) 成立 —— 这是 "注入强度由
        gamma 线性控制、且与 proj 尺度解耦" 的机械保证。
        """
        if not self.rms_norm:
            return corr
        rms = corr.pow(2).mean(dim=(1, 2, 3), keepdim=True).add(
            self.gate_eps).sqrt()
        unit = corr / rms
        return unit * self.rms_scale + self.rms_bias

    def _forward_impl(self, feats) -> Tuple[Tuple[Tensor, ...], Optional[Tensor]]:
        """真正的计算（供矩阵探针包装 forward 使用）。"""
        feats = tuple(feats)
        if not feats:
            return feats, None
        num_levels = len(feats)
        for lvl in set(self.fuse_levels) | set(self.inject_levels):
            if lvl < 0 or lvl >= num_levels:
                raise ValueError(
                    f'MID-Head v5/v6: level {lvl} out of range, '
                    f'got {num_levels} feature levels')

        ref_size = feats[self.fuse_levels[0]].shape[-2:]
        parts = [self._resize(feats[lvl], ref_size) for lvl in self.fuse_levels]
        fused = self.fuse_act(self.fuse(torch.cat(parts, dim=1)))
        if self.gate_norm is not None:
            fused = self.gate_norm(fused)
        self._mid_fused = fused
        self._mid_disc_logits = (self.disc_head(fused)
                                 if self.disc_enabled else None)

        if not self.inject_enabled:
            return feats, self._mid_disc_logits

        if self.star:
            a, b = self.star_expand(fused).chunk(2, dim=1)
            corr = self.star_gate(a * F.relu(b))
        else:
            corr = self.proj(fused)
        unit = self._rms_unit(corr)

        out = list(feats)
        for slot, lvl in enumerate(self.inject_levels):
            target = out[lvl]
            z = self._gamma_eff()[slot] * unit
            out[lvl] = target + self._resize(z, target.shape[-2:])
        return tuple(out), self._mid_disc_logits

    def forward(self, feats):
        """Args: feats (Sequence[Tensor]) 升序排列的多尺度特征。

        Returns:
            tuple[Tensor]: 与输入同长度、同形状的多尺度特征（回注后）。
            判别头输出存在 ``self._mid_disc_logits`` 上供损失使用。
        """
        out, _ = self._forward_impl(feats)
        return out

    def clear_cache(self) -> None:
        """Drop the references to the last forward's tensors."""
        self._mid_fused = None
        self._mid_disc_logits = None


class _MIDMixin:
    """Attaches the MID gate, the CMM and the M-SCA loss to an S2A head.

    ``AnchorHead.loss_by_feat`` calls ``loss_by_feat_single`` once per feature
    level through ``multi_apply``, in ascending level order.  The mixin counts
    those calls to know which level it is looking at, which is how
    ``msca_levels`` selects "highest-resolution feature only" (原 SCENet 设定).
    """

    # ------------------------------------------------------------------ #
    # construction
    # ------------------------------------------------------------------ #
    def _init_mid(self, mid_cfg=None) -> None:
        """Build the MID gate; ``variant`` selects the implementation.

        ``variant='v4'`` 构造 :class:`_MultiScaleDiscHead`（多尺度交互判别头），
        其余取值保持历史行为（``'v2'`` → :class:`_MIDGateV2`，否则
        :class:`_MIDGate`），以便冻结基线 ``configs/BASE_verified_12e.py``
        逐字不变。

        v4 额外支持：
            ``fuse_levels`` / ``fuse_channels`` / ``disc`` / ``disc_convs`` /
            ``inject`` / ``inject_levels`` / ``gamma_init`` /
            ``disc_num_classes`` / ``msca_source``
        """
        mid_cfg = dict(mid_cfg or {})
        self.mid_enabled = bool(mid_cfg.get('enabled', True))
        reduction = int(mid_cfg.get('reduction', 4))
        gamma_init = float(mid_cfg.get('gamma_init', 0.0))
        variant = str(mid_cfg.get('variant', 'v1')).lower()
        self.mid_variant = variant
        #: M-SCA 损失的输入来源：'cls' = 检测头 anchor 分数（历史口径）；
        #: 'disc' = 多尺度判别头输出（v4；判别头不存在时自动回退到 'cls'）
        self.mid_msca_source = str(mid_cfg.get('msca_source', 'cls')).lower()
        #: 诊断开关：置 True 时把判别头输出整体置零再送入 M-SCA，
        #: 用于实证"判别头输出真的被 M-SCA 用到了"（专项验证 2）。
        self.mid_disc_ablate = bool(mid_cfg.get('disc_ablate', False))
        self._mid_disc_mismatch: Optional[str] = None
        in_ch = self.in_channels
        if isinstance(in_ch, (list, tuple)):
            in_ch = int(in_ch[0])
        in_ch = int(in_ch)

        if variant in ('v5', 'mid_v5', 'v6', 'mid_v6'):
            cls_out = int(getattr(self, 'cls_out_channels',
                                  getattr(self, 'num_classes', 9)))
            self.mid_gate = _NormGatedMIDHead(
                in_channels=in_ch,
                num_classes=int(mid_cfg.get('disc_num_classes', cls_out)),
                fuse_levels=tuple(mid_cfg.get('fuse_levels', (0, 1, 2))),
                fuse_channels=int(mid_cfg.get('fuse_channels', in_ch)),
                disc=bool(mid_cfg.get('disc', True)),
                disc_convs=int(mid_cfg.get('disc_convs', 0)),
                inject=bool(mid_cfg.get('inject', True)),
                inject_levels=mid_cfg.get('inject_levels', None),
                gamma_init=float(mid_cfg.get('gamma_init', 0.01)),
                upsample_mode=str(mid_cfg.get('upsample_mode', 'bilinear')),
                # ---- v5/v6 专有：修正被 v4 实测证伪的 "全局标量 gamma" 结构 ----
                # gate=('layernorm'|'none') 对应专项验证 2 的 (a)/(b) 对照臂
                gate=str(mid_cfg.get('gate', 'layernorm')),
                rms_norm=bool(mid_cfg.get('rms_norm', True)),
                residual_variant=str(mid_cfg.get('residual_variant',
                                                 'v5')).lower(),
                star=bool(mid_cfg.get('star',
                                      variant in ('v6', 'mid_v6'))),
                gate_eps=float(mid_cfg.get('gate_eps', 1e-6)),
                inject_weight_std=float(
                    mid_cfg.get('inject_weight_std', 0.02)),
                # ---- gamma 有界化（默认 0.0 = 旧行为）----
                # 实测 gamma 无界会跑到 -0.36 ⇒ 注入变成"减特征"
                gamma_max=float(mid_cfg.get('gamma_max', 0.0)),
            )
        elif variant in ('v4', 'mid_v4'):
            cls_out = int(getattr(self, 'cls_out_channels',
                                  getattr(self, 'num_classes', 9)))
            self.mid_gate = _MultiScaleDiscHead(
                in_channels=in_ch,
                num_classes=int(mid_cfg.get('disc_num_classes', cls_out)),
                fuse_levels=tuple(mid_cfg.get('fuse_levels', (0, 1, 2))),
                fuse_channels=int(mid_cfg.get('fuse_channels', in_ch)),
                disc=bool(mid_cfg.get('disc', True)),
                disc_convs=int(mid_cfg.get('disc_convs', 0)),
                inject=bool(mid_cfg.get('inject', True)),
                inject_levels=mid_cfg.get('inject_levels', None),
                # v4 的关键：默认 0.01，**不是** v1 的 0.0（会让分支梯度恒为 0）
                gamma_init=float(mid_cfg.get('gamma_init', 0.01)),
                proj_zero_init=bool(mid_cfg.get('proj_zero_init', False)),
                gamma_freeze=bool(mid_cfg.get('gamma_freeze', False)),
                upsample_mode=str(mid_cfg.get('upsample_mode', 'bilinear')),
            )
        elif variant == 'v2':
            # 修正版：gamma 默认 1.0，恒等起步由分支零初始化保证
            gamma_init = float(mid_cfg.get('gamma_init', 1.0))
            self.mid_gate = _MIDGateV2(self.in_channels, reduction, gamma_init)
        else:
            self.mid_gate = _MIDGate(self.in_channels, reduction, gamma_init)

    def _init_msca(self,
                   msca_loss=None,
                   scanet_sca_loss_weight: Optional[float] = None,
                   confusion_pairs: Optional[Sequence[Tuple[int, int]]] = None,
                   msca_start_epoch: int = 0,
                   confusion_miner=None,
                   msca_levels: Sequence[int] = (0, ),
                   msca_log_metric: bool = False,
                   msca_log_interval: int = 50) -> None:
        """Initialise the M-SCA adapter, the CMM and pair bookkeeping.

        Args:
            msca_loss (dict | nn.Module, optional): :class:`MSCALoss` config.
            confusion_pairs (Sequence[tuple[int, int]], optional): Human priors.
                Combined with the CMM output ("人工先验 + 自动挖掘" 混合模式).
            msca_start_epoch (int): Warm-up; the loss is off before this epoch.
            confusion_miner (dict | nn.Module, optional):
                :class:`ConfusionMatrixMiner`.
            msca_levels (Sequence[int]): Feature levels feeding the M-SCA loss.
                ``(0,)`` matches the original SCENet (highest resolution only).
            msca_log_metric (bool): Also evaluate the (non-differentiable) M-SCA
                metric every ``msca_log_interval`` iterations (training-time
                monitoring; costs one metric pass, no gradient).
            msca_log_interval (int): Iteration interval for ``msca_log_metric``.
        """
        self.msca_loss = None
        if msca_loss is not None:
            self.msca_loss = (MODELS.build(msca_loss)
                              if isinstance(msca_loss, dict) else msca_loss)
        self.scanet_sca_loss = (
            None if scanet_sca_loss_weight is None else
            SCACosSimModuleLoss(loss_weight=float(scanet_sca_loss_weight)))
        self.confusion_pairs = [tuple(int(c) for c in p)
                                for p in (confusion_pairs or [])]
        self.confusion_miner = (MODELS.build(confusion_miner)
                                if isinstance(confusion_miner, dict)
                                else confusion_miner)
        self.msca_start_epoch = int(msca_start_epoch)
        self.msca_levels = tuple(int(i) for i in msca_levels)
        self.msca_log_metric = bool(msca_log_metric)
        self.msca_log_interval = max(1, int(msca_log_interval))
        self.current_epoch = 0
        self.iter = 0
        self._batch_gt_instances = None
        self.last_msca_metric: Optional[Tensor] = None
        self.last_msca_stats: Dict = {}
        self._reset_msca_buffers()

    # ------------------------------------------------------------------ #
    # epoch / pair state
    # ------------------------------------------------------------------ #
    def set_current_epoch(self, epoch: int) -> None:
        """Set the epoch used by the warm-up gates."""
        self.current_epoch = int(epoch)
        if self.confusion_miner is not None:
            self.confusion_miner.set_epoch(epoch)

    def set_confusion_pairs(self,
                            pairs: Sequence[Tuple[int, int]]) -> None:
        """Override the active pairs (normally the CMM drives them)."""
        self.confusion_pairs = [tuple(int(c) for c in p) for p in pairs]

    def active_msca_pairs(self) -> List[Tuple[int, int]]:
        """Prior pairs + CMM-mined pairs, de-duplicated, order stable."""
        pairs: List[Tuple[int, int]] = []
        for pair in self.confusion_pairs:
            if pair not in pairs:
                pairs.append(pair)
        if self.confusion_miner is not None:
            for pair in self.confusion_miner.active_pairs():
                if pair not in pairs:
                    pairs.append(pair)
        return pairs

    def msca_enabled(self) -> bool:
        """Whether the M-SCA term is active in the current epoch."""
        return (self.msca_loss is not None
                and self.current_epoch >= self.msca_start_epoch)

    # ------------------------------------------------------------------ #
    # per-image statistics
    # ------------------------------------------------------------------ #
    @staticmethod
    def image_confusion_counts(batch_gt_instances,
                               pairs: Sequence[Tuple[int, int]]
                               ) -> List[int]:
        """:math:`N^{conf}_m` (论文 3.6.1): 每张图属于激活混淆对的 GT 目标数.

        Falls back to the total GT object count when no pair is active, so the
        density weight never collapses to zero by accident.
        """
        classes = sorted({int(c) for pair in pairs for c in pair})
        counts: List[int] = []
        for gt in batch_gt_instances:
            labels = getattr(gt, 'labels', None)
            if labels is None or labels.numel() == 0:
                counts.append(0)
                continue
            labels = labels.reshape(-1)
            if classes:
                wanted = torch.tensor(classes, device=labels.device,
                                      dtype=labels.dtype)
                counts.append(int(torch.isin(labels, wanted).sum().item()))
            else:
                counts.append(int(labels.numel()))
        return counts

    # ------------------------------------------------------------------ #
    # M-SCA accumulation / reduction
    # ------------------------------------------------------------------ #
    def _reset_msca_buffers(self) -> None:
        """Clear the per-forward accumulation buffers.

        ``last_msca_metric``/``last_msca_stats`` intentionally survive so that a
        logging hook can read the most recent values.
        """
        self._msca_terms: List[Tensor] = []
        self._msca_level_calls = 0
        self._msca_logits: List[Tensor] = []
        #: CMM 专用：**始终**是检测头自己的 anchor 分数（检测口径不变）
        self._msca_cmm_logits: List[Tensor] = []
        self._msca_labels: List[Tensor] = []
        self._msca_meta: List[Tuple[int, int]] = []  # (num_imgs, anchors/img)
        self._msca_source_used: List[str] = []
        self._scanet_sca_logits: List[Tensor] = []
        self._scanet_sca_labels: List[Tensor] = []
        self._scanet_sca_meta: List[Tuple[int, int]] = []

    def disc_logits_for_msca(self, num_imgs: int, num_priors: int,
                             anchors_per_img: int):
        """MID-Head v4：把判别头输出拉平成 ``[N*H*W*priors, C]`` 供 M-SCA 使用。

        判别头输出 ``[N, C, H0, W0]`` 与最高分辨率尺度的 anchor 网格
        （``num_imgs x anchors_per_img`` 行，行序为 (h, w, prior)）逐位置对齐，
        因此可以直接沿用该尺度的 anchor 标签作为 M-SCA 的监督标签。

        Returns:
            Tensor | None: 对齐成功时返回展平后的判别头分数；下列任一情况返回
            ``None``（并写入 ``self._mid_disc_mismatch`` 供日志）：
            没有 v4 判别头 / ``msca_source != 'disc'`` / 通道数不等于
            ``cls_out_channels`` / 行数与 anchor 数不一致。
        """
        gate = getattr(self, 'mid_gate', None)
        disc = getattr(gate, '_mid_disc_logits', None) if gate is not None else None
        if disc is None or self.mid_msca_source != 'disc':
            return None
        if disc.dim() != 4 or int(disc.size(0)) != int(num_imgs):
            self._mid_disc_mismatch = (
                f'disc shape {tuple(disc.shape)} vs num_imgs {num_imgs}')
            return None
        if int(disc.size(1)) != int(self.cls_out_channels):
            self._mid_disc_mismatch = (
                f'disc channels {int(disc.size(1))} != cls_out_channels '
                f'{int(self.cls_out_channels)}')
            return None
        if self.mid_disc_ablate:
            # 专项验证 2 的对照臂 (b)：判别头输出整体置零
            disc = torch.zeros_like(disc)
        flat = disc.permute(0, 2, 3, 1).reshape(-1, int(disc.size(1)))
        if int(num_priors) > 1:
            flat = flat.repeat_interleave(int(num_priors), dim=0)
        if flat.size(0) != int(num_imgs) * int(anchors_per_img):
            self._mid_disc_mismatch = (
                f'disc positions {flat.size(0)} != anchors '
                f'{int(num_imgs) * int(anchors_per_img)} '
                f'(disc HW vs level-0 HW mismatch)')
            return None
        self._mid_disc_mismatch = None
        return flat

    def _collect_msca(self, cls_score: Tensor, labels: Tensor) -> None:
        """Accumulate one feature level's anchor scores and target labels."""
        level = self._msca_level_calls
        self._msca_level_calls += 1
        if self.msca_loss is None and self.scanet_sca_loss is None:
            return
        if (self.msca_loss is not None and self.msca_levels
                and level not in self.msca_levels):
            return
        num_imgs = int(cls_score.size(0))
        num_priors = int(getattr(self, 'num_base_priors', 1))
        # Retina-style outputs are laid out as
        # [N, num_priors * num_classes, H, W].  S2A uses one prior, but keeping
        # the prior dimension explicit prevents silent image/anchor misalignment
        # when a custom config supplies more than one prior.
        logits = cls_score.permute(0, 2, 3, 1).reshape(
            num_imgs, cls_score.size(2) * cls_score.size(3), num_priors,
            self.cls_out_channels).reshape(-1, self.cls_out_channels)
        anchors_per_img = int(logits.size(0) // max(num_imgs, 1))
        labels = labels.reshape(-1).to(device=logits.device, dtype=torch.long)
        original_labels = labels
        # Retina-style heads use ``num_classes`` as the background label;
        # MSCALoss treats negative and out-of-range labels as background.
        msca_labels = labels.masked_fill(labels >= self.cls_out_channels, -1)
        if logits.size(0) != labels.numel() or num_imgs == 0:
            return
        # >>> MID-Head v4: 用多尺度判别头输出替换 M-SCA 的输入（若启用且对齐）<<<
        disc_logits = self.disc_logits_for_msca(num_imgs, num_priors,
                                                anchors_per_img)
        if self.msca_loss is not None:
            self._msca_cmm_logits.append(logits)
            if disc_logits is not None:
                # 只改设备，不改 dtype：AMP autocast 下判别头输出与 cls_score
                # 同 dtype，强行 cast 反而会在 bf16 下丢精度。
                self._msca_logits.append(disc_logits.to(device=logits.device))
                self._msca_source_used.append('disc')
            else:
                self._msca_logits.append(logits)
                self._msca_source_used.append('cls')
            self._msca_labels.append(msca_labels)
            self._msca_meta.append((num_imgs, anchors_per_img))
        if self.scanet_sca_loss is not None and level == 0:
            self._scanet_sca_logits.append(logits)
            self._scanet_sca_labels.append(original_labels)
            self._scanet_sca_meta.append((num_imgs, anchors_per_img))

    def _finish_msca(self, losses: dict) -> dict:
        """Mine pairs, reduce the collected terms and emit ``loss_msca``."""
        try:
            if self.msca_loss is not None and self._msca_logits:
                pairs = self.active_msca_pairs()
                # The CMM consumes the **detector's own** anchor scores, never the
                # auxiliary discriminative head: the confusion matrix is a
                # detection-statistics object (论文 3.3).  The ``update`` call is
                # a no-op outside training.
                if self.confusion_miner is not None:
                    for logits, labels in zip(self._msca_cmm_logits,
                                              self._msca_labels):
                        self.confusion_miner.update(logits, labels)
                    pairs = self.active_msca_pairs()
                self.last_msca_stats = dict(pairs=[list(p) for p in pairs])
                if self._msca_source_used:
                    self.last_msca_stats['msca_source_used'] = (
                        self._msca_source_used[0])
                if self._mid_disc_mismatch is not None:
                    self.last_msca_stats['mid_disc_mismatch'] = (
                        self._mid_disc_mismatch)
                counts = (None if self._batch_gt_instances is None else
                          self.image_confusion_counts(
                              self._batch_gt_instances, pairs))
                if counts is not None:
                    self.last_msca_stats['image_confusion_counts'] = counts
                if self._batch_gt_instances is None:
                    # 消融模式提示：未提供真实目标数时 gamma 会饱和。
                    self.last_msca_stats['warning'] = (
                        'no batch_gt_instances: gamma_m falls back to anchor '
                        'counts and saturates at 1')
                if self.msca_enabled() and pairs:
                    for logits, labels, (num_imgs, apx) in zip(
                            self._msca_logits, self._msca_labels,
                            self._msca_meta):
                        image_index = torch.arange(
                            num_imgs, device=logits.device,
                            dtype=torch.long).repeat_interleave(apx)
                        if image_index.numel() != logits.size(0):
                            continue
                        want_metric = (self.msca_log_metric
                                       and self.iter % self.msca_log_interval
                                       == 0)
                        out = self.msca_loss(
                            logits, labels, pairs=pairs,
                            image_index=image_index,
                            image_confusion_counts=counts,
                            return_metric=want_metric)
                        if want_metric:
                            term, metric = out
                            self.last_msca_metric = metric.detach()
                        else:
                            term = out
                        if torch.is_tensor(term):
                            self._msca_terms.append(term)
                    if self._msca_terms:
                        loss = torch.stack(self._msca_terms).mean()
                        losses['loss_msca'] = loss
                        self.last_msca_stats['loss_msca'] = float(
                            loss.detach())
                        self.last_msca_stats.update(
                            dict(getattr(self.msca_loss, 'last_stats', {})))
                        if self.last_msca_metric is not None:
                            self.last_msca_stats['msca_metric'] = float(
                                self.last_msca_metric)
            self.iter += 1
        finally:
            self._reset_msca_buffers()
            gate = getattr(self, 'mid_gate', None)
            if gate is not None and hasattr(gate, 'clear_cache'):
                # v4 only: drop the last forward's tensor references so the
                # autograd graph is not kept alive by the module.
                gate.clear_cache()
        return losses

    # ------------------------------------------------------------------ #
    # forward
    # ------------------------------------------------------------------ #
    def forward(self, feats):
        if getattr(self, 'mid_enabled', False):
            feats = self.mid_gate(tuple(feats))
        return super().forward(feats)

class _MSCAHeadMixin(_MIDMixin):
    """Shared ``loss_by_feat`` wrapper for both MA-SENet heads."""

    def loss_by_feat(self, *args, **kwargs) -> dict:
        # ``RefineSingleStageDetector`` passes loss inputs positionally for the
        # initial head and with ``rois=`` for the refine head.
        batch_gt_instances = kwargs.get('batch_gt_instances')
        if batch_gt_instances is None and len(args) >= 3:
            batch_gt_instances = args[2]
        self._batch_gt_instances = batch_gt_instances
        self._reset_msca_buffers()
        losses = super().loss_by_feat(*args, **kwargs)
        if self.scanet_sca_loss is not None and self._scanet_sca_logits:
            # Original SCENet SCA loss uses the large-vehicle/container scores.
            logits = self._scanet_sca_logits[0]
            labels = self._scanet_sca_labels[0]
            num_imgs, anchors_per_img = self._scanet_sca_meta[0]
            scores = logits.sigmoid().reshape(
                1, num_imgs * anchors_per_img, self.cls_out_channels)
            batch_labels = labels.reshape(1, num_imgs * anchors_per_img)
            losses['loss_scanet_sca'] = self.scanet_sca_loss(
                scores, batch_labels)
        return self._finish_msca(losses)

    def loss_by_feat_single(self, cls_score, bbox_pred, anchors, labels,
                            label_weights, bbox_targets, bbox_weights,
                            avg_factor):
        result = super().loss_by_feat_single(
            cls_score, bbox_pred, anchors, labels, label_weights,
            bbox_targets, bbox_weights, avg_factor)
        self._collect_msca(cls_score, labels)
        return result

@MODELS.register_module()
class MAS2AHead(_MSCAHeadMixin, S2AHead):
    """Initial MA-SENet head; the M-SCA loss is attached here by default."""

    def __init__(self,
                 *args,
                 mid_cfg: Optional[dict] = None,
                 msca_loss=None,
                 scanet_sca_loss_weight: Optional[float] = None,
                 confusion_pairs=None,
                 msca_start_epoch: int = 0,
                 confusion_miner=None,
                 msca_levels: Sequence[int] = (0, ),
                 msca_log_metric: bool = False,
                 msca_log_interval: int = 50,
                 **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._init_mid(mid_cfg)
        self._init_msca(msca_loss, scanet_sca_loss_weight,
                        confusion_pairs, msca_start_epoch,
                        confusion_miner, msca_levels, msca_log_metric,
                        msca_log_interval)



# --------------------------------------------------------------------------- #
# UGS (ICCV 2025) support for the refine head -- classification-based
# localization. Everything here is additive; ugs_cfg=None disables it fully.
# --------------------------------------------------------------------------- #
class _UGSMixin:
    """Mixin providing UGS hooks. See .probes/ugs_head.py for the rationale."""

    def _init_ugs(self, ugs_cfg=None) -> None:
        cfg = dict(ugs_cfg or {})
        self.ugs_enabled = bool(cfg.get('enabled', False))
        self.ugs_cfg = cfg
        if not self.ugs_enabled:
            self.ugs_loss = None
            self.ugs_nb1 = 1
            return
        self.ugs_loss = UGSLocalizationLoss(
            n_bins=int(cfg.get('n_bins', 8)),
            alpha=float(cfg.get('alpha', 1.0)),
            beta=float(cfg.get('beta', 1.0)),
            alpha_angle=float(cfg.get('alpha_angle', 0.7853981633974483)),
            angle_dims=tuple(cfg.get('angle_dims', (4, ))),
            reduction='none',
            loss_weight=float(cfg.get('loss_weight', 5.0)),
        )
        self.ugs_nb1 = self.ugs_loss.n_bins + 1
        self.ugs_warmup_epochs = int(cfg.get('warmup_epochs', 0))
        self.ugs_current_epoch = 0

    def rebuild_reg_branch_for_ugs(self) -> None:
        """Widen retina_reg to emit (n_bins+1) logits per encoded dimension."""
        if not getattr(self, 'ugs_enabled', False):
            return
        nb1 = self.ugs_nb1
        reg_dim = self.bbox_coder.encode_size
        self.ugs_encode_size = reg_dim
        old = getattr(self, 'retina_reg', None)
        new = nn.Conv2d(self.feat_channels,
                        self.num_base_priors * reg_dim * nb1, 3, padding=1)
        # Initialisation: put the ORIGINAL filters into the MIDDLE bin and zero
        # the others.
        #   * copying into bin 0 pins the initial expectation at the left edge
        #     of [-alpha, alpha] -> the softmax is immediately one-hot -> the
        #     cross-entropy sits at its uniform value (~5*ln(9)=10.99) and does
        #     NOT descend (measured: 11.6 flat over 60 iterations).
        #   * zero-filling the other bins keeps the initial distribution uniform
        #     in the LOGIT domain, so the expectation starts at 0.0 -- i.e. the
        #     baseline's initial prediction -- and gradient signal exists from
        #     the first step.
        if old is not None:
            with torch.no_grad():
                w, b = old.weight.data, old.bias.data
                p = self.num_base_priors
                mid = nb1 // 2
                new.weight.data.zero_()
                new.bias.data.zero_()
                for d in range(reg_dim):
                    for k in range(p):
                        s = d * p + k
                        t = (d * nb1 + mid) * p + k   # MIDDLE bin of dim d
                        if t < new.weight.shape[0] and s < w.shape[0]:
                            new.weight.data[t] = w[s]
                            new.bias.data[t] = b[s]
        self.retina_reg = new

    def set_current_epoch(self, epoch: int) -> None:
        self.ugs_current_epoch = int(epoch)

    def ugs_localization_loss(self, bbox_pred, bbox_targets,
                              bbox_weights=None, avg_factor=None):
        """Return (loss, decoded_offsets). bbox_pred is the raw conv output."""
        nb1 = self.ugs_nb1
        N = bbox_pred.shape[0]
        flat = bbox_pred.reshape(N, self.ugs_encode_size * nb1)
        # decode() accepts the flat [N, 5*(n_bins+1)] tensor directly.
        # Passing an already-reshaped [N, 5, nb1] used to be mis-parsed as
        # [N, D] with D = 5 // nb1 = 0 -> "shape [400, 0, 9] is invalid".
        decoded = self.ugs_loss.decode(flat)
        tgt = bbox_targets.reshape(N, self.ugs_encode_size)
        per_anchor = self.ugs_loss(flat, tgt)
        if bbox_weights is not None:
            # [N, D] -> [N] : one weight per anchor (positives have weight 1)
            w = bbox_weights.reshape(-1, self.ugs_encode_size).mean(dim=1)
            w = w.reshape(-1)
            if w.numel() != per_anchor.numel():
                # defensive: reshape may have changed the leading dim
                w = torch.ones_like(per_anchor)
            denom = w.sum().clamp_min(1e-6)
            loss = (per_anchor * w).sum() / denom
        else:
            loss = per_anchor.mean()
        return loss, decoded


@MODELS.register_module()
class MAS2ARefineHead(_MSCAHeadMixin, _UGSMixin, S2ARefineHead):
    """Refinement MA-SENet head.

    The M-SCA term lives on the initial head by default; enable it here with
    ``msca_loss=dict(...)`` for ablation studies.
    """

    def __init__(self,
                 *args,
                 mid_cfg: Optional[dict] = None,
                 msca_loss=None,
                 scanet_sca_loss_weight: Optional[float] = None,
                 confusion_pairs=None,
                 msca_start_epoch: int = 0,
                 confusion_miner=None,
                 msca_levels: Sequence[int] = (0, ),
                 msca_log_metric: bool = False,
                 msca_log_interval: int = 50,
                 ugs_cfg: Optional[dict] = None,
                 **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._init_mid(mid_cfg)
        self._init_msca(msca_loss, scanet_sca_loss_weight,
                        confusion_pairs, msca_start_epoch,
                        confusion_miner, msca_levels, msca_log_metric,
                        msca_log_interval)
        # UGS stage 1: classification-based localization on the regression
        # branch. ugs_cfg=None => ugs_enabled=False => retina_reg untouched,
        # so every pre-existing config stays bit-identical.
        self._init_ugs(ugs_cfg)
        self.rebuild_reg_branch_for_ugs()

@MODELS.register_module()
class MAS2AQualityRefineHead(MAS2ARefineHead):
    """Refine head using matched-box IoU as the QFL classification target."""

    def loss_by_feat_single(self, cls_score, bbox_pred, anchors, labels,
                            label_weights, bbox_targets, bbox_weights,
                            avg_factor):
        labels = labels.reshape(-1)
        label_weights = label_weights.reshape(-1)
        cls_score = cls_score.permute(0, 2, 3, 1).reshape(
            -1, self.cls_out_channels)
        target_dim = bbox_targets.size(-1)
        bbox_targets = bbox_targets.reshape(-1, target_dim)
        bbox_weights = bbox_weights.reshape(-1, target_dim)
        bbox_pred = bbox_pred.permute(0, 2, 3, 1).reshape(
            -1, self.bbox_coder.encode_size)

        if not self.reg_decoded_bbox:
            raise ValueError('Quality targets require decoded bbox targets.')
        anchors = anchors.reshape(-1, anchors.size(-1))
        decoded_pred = self.bbox_coder.decode(anchors, bbox_pred)
        decoded_pred = get_box_tensor(decoded_pred)
        positive = (labels >= 0) & (labels < self.num_classes)
        quality = cls_score.new_zeros(labels.shape)
        if positive.any():
            quality[positive] = box_iou_rotated(
                decoded_pred[positive].detach().float(),
                bbox_targets[positive].float(),
                aligned=True,
                clockwise=True).to(dtype=quality.dtype)
        loss_cls = self.loss_cls(
            cls_score, (labels, quality), label_weights,
            avg_factor=avg_factor)

        if self.reg_decoded_bbox and self.loss_bbox_type != 'kfiou':
            bbox_pred = decoded_pred
        if self.loss_bbox_type == 'normal':
            loss_bbox = self.loss_bbox(
                bbox_pred, bbox_targets, bbox_weights,
                avg_factor=avg_factor)
        elif self.loss_bbox_type == 'kfiou':
            bbox_pred_decode = self.bbox_coder.decode(anchors, bbox_pred)
            bbox_pred_decode = get_box_tensor(bbox_pred_decode)
            bbox_targets_decode = self.bbox_coder.decode(
                anchors, bbox_targets)
            bbox_targets_decode = get_box_tensor(bbox_targets_decode)
            loss_bbox = self.loss_bbox(
                bbox_pred, bbox_targets, bbox_weights,
                pred_decode=bbox_pred_decode,
                targets_decode=bbox_targets_decode,
                avg_factor=avg_factor)
        else:
            raise NotImplementedError(self.loss_bbox_type)
        return loss_cls, loss_bbox

#: 论文项目结构中的 ``MIDHead`` 别名。
MIDHead = MAS2AHead

__all__ = [
    'MIDHead', 'MAS2AHead', 'MAS2ARefineHead', 'MAS2AQualityRefineHead',
    '_MIDGate', '_MIDGateV2', '_MultiScaleDiscHead', '_NormGatedMIDHead',
    '_MIDMixin',
    '_MSCAHeadMixin']


@MODELS.register_module()
class MAS2AUGSRefineHead(MAS2ARefineHead):
    """Refine head with UGS stage-1 localization (classification-based).

    Config: ``ugs_cfg=dict(enabled=True, n_bins=8, beta=1.0, loss_weight=5.0)``.
    Everything except the regression term is inherited unchanged.
    """

    def loss_by_feat_single(self, cls_score, bbox_pred, anchors, labels,
                            label_weights, bbox_targets, bbox_weights,
                            avg_factor):
        if not getattr(self, 'ugs_enabled', False):
            return super().loss_by_feat_single(
                cls_score, bbox_pred, anchors, labels, label_weights,
                bbox_targets, bbox_weights, avg_factor)

        labels_f = labels.reshape(-1)
        label_weights_f = label_weights.reshape(-1)
        cls_score_f = cls_score.permute(0, 2, 3, 1).reshape(
            -1, self.cls_out_channels)
        td = bbox_targets.size(-1)
        bbox_targets_f = bbox_targets.reshape(-1, td)
        bbox_weights_f = bbox_weights.reshape(-1, td)
        # keep the raw (wide) regression output: [N, 5*(n_bins+1)]
        bbox_pred_f = bbox_pred.permute(0, 2, 3, 1).reshape(
            -1, self.ugs_encode_size * self.ugs_nb1)

        loss_cls = self.loss_cls(
            cls_score_f, labels_f, label_weights_f, avg_factor=avg_factor)
        loss_bbox, _ = self.ugs_localization_loss(
            bbox_pred_f, bbox_targets_f, bbox_weights_f, avg_factor)

        # MUST return a 2-tuple: AnchorHead.loss_by_feat calls
        # loss_by_feat_single via multi_apply -> zip(*results), and only then
        # assembles {'loss_cls': [...], 'loss_bbox': [...]}.
        # Returning a dict here raises
        #   ValueError: not enough values to unpack / TypeError in the detector.
        # Verified against the baseline: MAS2ARefineHead.loss_by_feat_single
        # returns tuple(len=2) of Tensors.
        return loss_cls, loss_bbox


