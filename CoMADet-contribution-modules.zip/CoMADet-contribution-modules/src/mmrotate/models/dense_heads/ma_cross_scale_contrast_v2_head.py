"""IC2: stable, batch-capped version of the existing cross-scale IC1.

This is a separate candidate, with no changes to any historical head class.
Native CUDA rotated pooling/prediction preflight is required before training.
"""
import torch
from torch.nn import functional as F
from mmrotate.registry import MODELS
from ..losses.stable_instance_contrast import cap_gt_batch, stable_supcon_loss
from .ma_s2a_head import MAS2ARefineHead
from .ma_cross_scale_contrast_head import (
    CrossScaleInstanceBranch, MAS2ACrossScaleContrastRefineHead)


class StableCrossScaleInstanceBranch(CrossScaleInstanceBranch):
    def forward(self, feats, batch_gt_instances):
        if any(level >= len(feats) for level in self.levels):
            raise ValueError('a configured IC2 feature level is absent')
        samples = cap_gt_batch(batch_gt_instances, self.max_per_class,
                               self.num_classes)
        rois, labels = [], []
        for image, sample in enumerate(samples):
            if sample is None or len(sample.labels) == 0:
                continue
            b = sample.bboxes
            rois.append(torch.cat([b.new_full((len(b), 1), image), b], 1))
            labels.append(sample.labels)
        if not rois:
            self.last_stats = dict(objects=0, class_loss=0., scale_align=0.)
            return None
        rois, labels = torch.cat(rois), torch.cat(labels)
        embeddings = []
        for level, extractor in zip(self.levels, self.roi_extractors):
            pooled = extractor([feats[level]], rois)
            embeddings.append(F.normalize(self.proj(pooled.flatten(1)).float(), dim=1))
        z = torch.stack(embeddings, 1)
        class_loss = stable_supcon_loss(
            z.flatten(0, 1), labels.repeat_interleave(len(embeddings)),
            self.temperature, self.num_classes,
            confusion=self._confusion_snapshot,
            totals=self._totals_snapshot,
            confusion_beta=self.confusion_beta)
        pairs = torch.triu(torch.ones(len(embeddings), len(embeddings),
                                      dtype=torch.bool, device=z.device), 1)
        scale_loss = (1. - (z[:, :, None, :] * z[:, None, :, :]).sum(-1))[:, pairs].mean()
        self.last_stats = dict(
            objects=len(labels), classes=int(labels.unique().numel()),
            embedding_rows=len(labels) * len(embeddings),
            batch_cap_per_class=self.max_per_class,
            class_loss=float(class_loss.detach()),
            scale_align=float(scale_loss.detach()),
            class_discrimination_active=bool(labels.unique().numel() >= 2),
            confusion_weighted=bool(self.confusion_beta > 0.0
                                    and self._confusion_snapshot is not None),
            confusion_beta=self.confusion_beta)
        self.clear_confusion_snapshot()
        return self.loss_weight * (class_loss + self.scale_align_weight * scale_loss)


@MODELS.register_module()
class MAS2AStableCrossScaleContrastRefineHead(MAS2ACrossScaleContrastRefineHead):
    def __init__(self, *args, contrast_cfg=None, **kwargs):
        cfg = dict(contrast_cfg or {})
        super().__init__(*args, contrast_cfg=cfg, **kwargs)
        if self.contrast_enabled:
            self.contrast_branch = StableCrossScaleInstanceBranch(
                in_channels=self.feat_channels, num_classes=self.cls_out_channels,
                levels=tuple(cfg.get('levels', (0, 1, 2))),
                roi_out_size=int(cfg.get('roi_out_size', 7)),
                proj_dim=int(cfg.get('proj_dim', 128)),
                hidden_dim=int(cfg.get('hidden_dim', 256)),
                temperature=float(cfg.get('temperature', .1)),
                loss_weight=float(cfg.get('loss_weight', .1)),
                max_per_class=int(cfg.get('max_per_class', 32)),
                level_strides=self._resolve_level_strides(cfg),
                scale_align_weight=float(cfg.get('scale_align_weight', .25)),
                confusion_beta=float(cfg.get('confusion_beta', 0.0)))

    @torch.no_grad()
    def set_confusion_snapshot(self, confusion, totals):
        if self.contrast_branch is not None:
            self.contrast_branch.set_confusion_snapshot(confusion, totals)

    def feature_refine(self, x, rois):
        self._contrast_feats = list(x) if self.training and self.contrast_enabled else None
        try:
            return MAS2ARefineHead.feature_refine(self, x, rois)
        except Exception:
            self._contrast_feats = None
            raise

    def loss_by_feat(self, *args, **kwargs):
        try:
            return super().loss_by_feat(*args, **kwargs)
        finally:
            self._contrast_feats = None


__all__ = ['MAS2AStableCrossScaleContrastRefineHead']
