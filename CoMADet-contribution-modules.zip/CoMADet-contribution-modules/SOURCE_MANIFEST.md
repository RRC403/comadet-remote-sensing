# Source manifest

The src/mmrotate files are copied from the local MMRotate working tree used for the CoMADet experiments. The cma files are copied from the local post-processing implementation used for confusion-mined arbitration.

This repository is a modules-only release. The upstream detector framework is not copied here.
